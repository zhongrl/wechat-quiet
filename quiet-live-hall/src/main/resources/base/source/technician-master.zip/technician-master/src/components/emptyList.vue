<template>
  <view class="empty-list">
    <text>暂无数据</text>
  </view>
</template>

<script>
export default {}
</script>

<style>
.empty-list {
  text-align: center;
  padding: 100rpx;
  font-size: 28rpx;
  color: #9b9b9b;
}
</style>
