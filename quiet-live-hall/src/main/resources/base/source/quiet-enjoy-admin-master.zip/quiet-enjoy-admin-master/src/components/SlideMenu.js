import React, { useContext, useEffect, useState } from 'react'
import { Layout, Menu, Icon } from 'antd'
import { Link } from 'react-router-dom'
import { context } from '@components/Provider'

const { SubMenu } = Menu
const { Sider } = Layout

export default function SlideMenu(props) {
  const [key, setKey] = useState(['2'])
  const { collapsed } = props
  const { history, $menus } = useContext(context)

  const setMenuKey = () => {
    const { pathname } = history.location
    $menus.forEach(({ path, children }, index) => {
      if (Array.isArray(children)) {
        children.forEach(({ path: childPath }, subIndex) => {
          if (childPath === pathname) {
            setKey([`${index}`, `${subIndex}`])
          }
        })
      } else {
        if (pathname === path) {
          setKey([`${index}`])
        }
      }
    })
  }

  useEffect(() => {
    history.listen(info => {
      setMenuKey()
    })
    setMenuKey()
  }, [])

  return (
    <Sider trigger={null} collapsible collapsed={collapsed}>
      <Menu theme="dark" mode="inline" defaultSelectedKeys={key}>
        {$menus.map((item, index) =>
          item.children ? (
            <SubMenu
              key={`${index}`}
              title={
                <span>
                  <Icon type={item.type} />
                  <span>{item.text}</span>
                </span>
              }
            >
              {item.children.map((subItem, subIndex) => (
                <Menu.Item key={`${index}-${subIndex}`}>
                  <Link to={subItem.path}>
                    <Icon type={subItem.type} />
                    <span>{subItem.text}</span>
                  </Link>
                </Menu.Item>
              ))}
            </SubMenu>
          ) : (
            <Menu.Item key={index}>
              <Link to={item.path}>
                <Icon type={item.type} />
                <span>{item.text}</span>
              </Link>
            </Menu.Item>
          )
        )}
      </Menu>
    </Sider>
  )
}
