import React, { useContext, useEffect, useState } from 'react'
import CommForm from '@components/commForm/CommForm'
import { context } from '@components/Provider'
import { message, Layout } from 'antd'

const { Content } = Layout

const deafultList = [
  {
    type: 'input',
    label: '服务名称',
    field: 'serviceName',
    rules: ['required']
  },
  {
    type: 'input',
    label: '服务时长',
    field: 'serviceTime'
  }
  // {
  //   type: 'date',
  //   label: '创建时间',
  //   field: 'updateTime'
  // }
]

export default function EditServices() {
  const { $fetch, history, $utils } = useContext(context)
  const [initValue, setInitValue] = useState({})
  const [list, setList] = useState(deafultList)
  const id = $utils.getQuery('id')

  useEffect(() => {
    async function getDetail() {
      const res = await $fetch('bi/jService/findXcxService', { id })
      const info = res[0] || {}
      setInitValue(info)
      setList(
        list.map(item =>
          info[item.field] ? { ...item, value: info[item.field] } : item
        )
      )
    }
    if (id) {
      getDetail()
    }
  }, [id])

  async function toEdit(values) {
    await $fetch('bi/jService/save', { ...initValue, ...values })
    message.success('操作成功', 2).then(() => {
      history.replace('/page/services')
    })
  }

  const submit = values => {
    toEdit(values)
  }

  return (
    <Content style={{ padding: '100px', backgroundColor: '#fff' }}>
      <CommForm list={list} layout="vertical" submit={submit} buttonText="提交"></CommForm>
    </Content>
  )
}
