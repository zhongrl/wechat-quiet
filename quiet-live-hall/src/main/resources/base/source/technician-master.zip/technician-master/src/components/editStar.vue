<template>
  <view>
    <image class="starItem" @click="$emit('handleClick', [i, id])" v-for="i in 5" :src="i <= num ? star : grayStar" :key="i" />
  </view>
</template>

<script>
import star from '@/assets/big_star.png'
import grayStar from '@/assets/big_star_gray.png'
export default {
  props: {
    num: {
      type: Number,
      default: 0
    },
    id: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      star,
      grayStar
    }
  }
}
</script>

<style>
.starItem {
  width: 50rpx;
  height: 50rpx;
  margin-right: 30rpx;
}

.starItem:last-child {
  margin: 0;
}
</style>
