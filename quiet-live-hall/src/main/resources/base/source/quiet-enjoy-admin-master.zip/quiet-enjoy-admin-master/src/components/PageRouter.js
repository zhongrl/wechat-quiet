import React, { lazy, Suspense, useContext } from 'react'
import { Route, Switch, Redirect  } from 'react-router-dom'
import Loading from '@components/loading/Loading'
import { context } from '@components/Provider'

const LoginPage = lazy(() => import('@views/login/Login'))
const Page = lazy(() => import('@components/Page'))

export default function PageRouter() {
  const { state, history } = useContext(context)
  if(!localStorage.getItem('token')) history.push('/login')
  return (
    <div>
      <Suspense fallback={<Loading isLoading={true}></Loading>}>
        <Switch>
          <Route path="/" exact component={Page} />
          <Route path="/page" component={Page} />
          <Route path="/login" component={LoginPage} />
          <Redirect from="/" to="/page"></Redirect>
        </Switch>
      </Suspense>
      <Loading isLoading={state.isLoading}></Loading>
    </div>
  )
}
