import Taro, { useState, useEffect } from '@tarojs/taro'
import { View, Button, Icon, Image } from '@tarojs/components'
import loginLogin from '@/assets/login_logo.jpeg'
import './auth.less'

export default function Auth(props) {
  const [show, setShow] = useState(true)
  const { callback } = props

  useEffect(() => {
    async function getAuthSetting() {
      const { authSetting } = await Taro.getSetting()
      if (authSetting['scope.userInfo']) {
        // 已授权
        const userInfo = await Taro.getUserInfo()
        callback(userInfo)
      } else {
        setShow(true)
      }
    }
    getAuthSetting()
  }, [])

  const getUserInfo = async info => {
    const { detail = {} } = info
    const { encryptedData } = detail
    if (typeof encryptedData !== 'undefined') {
      setShow(false)
      callback(detail)
    }
  }

  return show ? (
    <View class="authView">
      <View className="authPhoto">
        {/* <Icon type="info" size={60}></Icon> */}
        <Image src={loginLogin} className="loginLogo"></Image>
      </View>
      <View className="authTopTex">申请获取以下权限</View>
      <View className="authInfo">获得你的公开信息(昵称，头像等)</View>
      <View className="authBottom">
        <Button
          class="authButton"
          type="primary"
          openType="getUserInfo"
          onGetUserInfo={getUserInfo}
        >
          授权登录
        </Button>
      </View>
    </View>
  ) : null
}
