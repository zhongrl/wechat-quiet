# 技师端开发框架说明

## 框架概述

该项目为公众号h5项目，基于[uni-app](https://uniapp.dcloud.io/)开发，使用yarn进行依赖包管理

## 开发说明

1. 安装依赖

   `yarn`

2. 运行项目

   `yarn run serve`

## 打包说明（打包生成文件目录为：dist/build/h5）

    `yarn run build`

## [入口及域名](https://www.jingxiang2019.com/technician/pages/login/login)
