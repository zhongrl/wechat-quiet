<template>
  <view class="sharePage">
    <view class="shareMain">
      <view class="shareLogoItem">
        <image class="shareLogo" :src="shareLogo" />
      </view>
      <view class="shareEmailItem">
        <image :src="email" class="shareEmail" />
      </view>
      <view class="shareText">
        <view class="shareTextRow">
          <text>好友为你送上</text>
          <text class="shareTextBold">20元</text>
          <text>抵扣券</text>
        </view>
        <view class="shareTextTip">
          <text>首次消费后</text>
        </view>
        <view class="shareTextRow">
          <text>可直接抵扣</text>
          <text class="shareTextBold">20元</text>
        </view>
      </view>
      <view class="shareButtonRow">
        <button class="shareButton" @click="toUse">去使用</button>
      </view>
      <view class="shareBottomText">
        <text>邀请越多 奖励越多</text>
      </view>
      <view class="shareCompText">
        <text>静享生活体验馆</text>
      </view>
    </view>
  </view>
</template>

<script>
import http from '@/utils/http'
import shareLogo from '@/assets/share_logo.png'
import email from '@/assets/email.png'

export default {
  data() {
    return {
      shareLogo,
      email,
      code: '',
      couponId: '',
      giveOpenid: '',
      isWxWp: '',
      couponId: ''
    }
  },
  onLoad(option) {
    const { code, couponId, giveOpenid, isWxWp, unionid } = option
    this.code = code
    this.couponId = couponId
    this.giveOpenid = giveOpenid
    this.isWxWp = isWxWp
    this.unionid = unionid
    uni.showToast({
      title: unionid || 'no',
      icon: 'none',
      duration: 2000
    })
    this.getCard()
  },
  methods: {
    async getCard() {
      const { code, couponId, giveOpenid, isWxWp, unionid } = this
      await http('custom/shareUserJCouponDetail', {
        giveOpenid,
        couponId,
        isWxWp,
        code,
        unionid
      })
    },
    toUse() {
      if (WeixinJSBridge) {
        WeixinJSBridge.call('closeWindow')
      } else {
        // uni.showToast({
        //   title: 'no',
        //   icon: 'none',
        //   duration: 2000
        // })
      }
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
  background-image: linear-gradient(-132deg, #d8cdbb 0%, #b09e85 100%);
}
.sharePage {
  padding: 70rpx 0 20rpx 0;
}

.shareMain {
  background: #ffffff;
  border-radius: 10rpx;
  margin: 0 45rpx 0 45rpx;
  padding: 181rpx 0 89rpx 0;
  text-align: center;
  font-size: 20rpx;
  color: #9b9b9b;
}

.shareEmailItem {
  padding: 121rpx 0 10rpx 0;
}

.shareTextBold {
  font-size: 42rpx;
  color: #000000;
}

.shareText {
  font-size: 36rpx;
  color: #000000;
}

.shareTextTip {
  font-size: 24rpx;
}

.shareTextRow {
  margin-bottom: 10rpx;
}

.shareLogo {
  width: 332rpx;
  height: 116rpx;
}

.shareEmail {
  width: 74rpx;
  height: 58rpx;
}

.shareButtonRow {
  margin: 120rpx 0 20rpx 0;
}

.shareButton {
  background: #b09e85;
  border-radius: 40rpx;
  font-size: 32rpx;
  color: #ffffff;
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
}

.shareBottomText {
  font-size: 24rpx;
  color: #9b9b9b;
  line-height: 33rpx;
}

.shareCompText {
  font-size: 20rpx;
  color: #9b9b9b;
  letter-spacing: 20rpx;
  margin-top: 60rpx;
}
</style>
