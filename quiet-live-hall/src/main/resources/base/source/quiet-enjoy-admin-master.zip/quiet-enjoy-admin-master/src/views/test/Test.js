import React from 'react'
import doc from '@assets/doc.jpg'


export default function Test(props) {
  return <img src={doc} alt="test"></img>
}
