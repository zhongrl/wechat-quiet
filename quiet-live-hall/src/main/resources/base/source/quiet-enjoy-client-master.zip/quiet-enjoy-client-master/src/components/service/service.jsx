import Taro from '@tarojs/taro'
import { View, Text, Button, Image } from '@tarojs/components'
import head from '@/assets/head.png'
import shoulder from '@/assets/shoulder.png'
import back from '@/assets/back.png'
import leg from '@/assets/leg.png'
import tea from '@/assets/tea.png'
import aromatherapy from '@/assets/aromatherapy.png'
import book from '@/assets/book.png'
import adviser from '@/assets/adviser.png'


import './service.less'

export default function Service(props) {
  // const { list = [], changeTab } = props
  return (
    <View className="service">
      <View className="serviceItem">
        <View className="serviceTitle">
          <Text>现代理疗全身推拿 45分钟</Text>
        </View>
        <View className="serviceList">
          <View className="serviceListRow">
            <View className="serviceListSpan">
              <Image src={head} className="serviceImg"></Image>
              <Text>头部按摩5分钟</Text>
            </View>
            <View className="serviceListSpan">
              <Image src={shoulder} className="serviceImg"></Image>
              <Text>肩颈按摩20分钟</Text>
            </View>
          </View>
          <View className="serviceListRow">
            <View className="serviceListSpan">
              <Image src={back} className="serviceImg"></Image>
              <Text>背部按摩10分钟</Text>
            </View>
            <View className="serviceListSpan">
              <Image src={leg} className="serviceImg"></Image>
              <Text>腿部按摩10分钟</Text>
            </View>
          </View>
          <View className="serviceListDesc">
            <Text>以上服务可根据身体情况调整局部服务时长哦！</Text>
          </View>
        </View>
      </View>

      <View className="serviceItem">
        <View className="serviceTitle">
          <Text>其它福利</Text>
        </View>
        <View className="serviceList">
          <View className="serviceListRow">
            <View className="serviceListSpan">
              <Image src={tea} className="serviceImg"></Image>
              <Text>奉茶</Text>
            </View>
            <View className="serviceListSpan">
              <Image src={aromatherapy} className="serviceImg"></Image>
              <Text>助眠香薰</Text>
            </View>
          </View>
          <View className="serviceListRow">
            <View className="serviceListSpan">
              <Image src={book} className="serviceImg"></Image>
              <Text>图书</Text>
            </View>
            <View className="serviceListSpan">
              <Image src={adviser} className="serviceImg"></Image>
              <Text>健康顾问</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  )
}
