import React, { useContext } from 'react'
import { context } from '@components/Provider'
import { Layout, Icon } from 'antd'
import { Link } from 'react-router-dom'
import logo from '../assets/logo.png'

const { Header } = Layout

export default function SlideMenu(props) {
  const { history } = useContext(context)
  const { collapsed, setCollapsed } = props
  const logout = () => {
    localStorage.removeItem('token')
    history.push('/login')
  }
  return (
    <Header
      style={{
        background: '#fff',
        padding: 0,
        boxShadow: '0 0 10px #ccc',
        marginBottom: '10px'
      }}
    >
      <div className="page-header">
        <p>
          <Icon
            className="trigger"
            type={collapsed ? 'menu-unfold' : 'menu-fold'}
            onClick={() => setCollapsed(!collapsed)}
          />
        </p>
        <p className="header-logo">
          <Link to="/">
            <img src={logo} alt="" />
          </Link>
          <Icon className="trigger" type="logout" onClick={() => logout()} />
        </p>
      </div>
    </Header>
  )
}
