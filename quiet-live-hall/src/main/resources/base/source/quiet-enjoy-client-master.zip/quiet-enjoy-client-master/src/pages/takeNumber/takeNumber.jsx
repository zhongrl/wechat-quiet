import Taro, { Component } from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import TechnicianInfo from '@/components/technicianInfo/technicianInfo'
import Price from '@/components/price/price'
import http from '../../utils/http'
import './takeNumber.less'

export default class TakeNumber extends Component {
  config = {
    navigationBarTitleText: '取号',
    // enablePullDownRefresh: true //全局
  }

  constructor(props) {
    const { id, storeId } = this.$router.params
    this.state = {
      id,
      storeId,
      info: {}
    }
  }

  componentDidMount() {
    this.getDetail()
  }

  async getDetail() {
    const { id } = this.state
    const info = await http('custom/findJsSelectById', {
      id
    })
    this.setState({
      info
    })
  }

  // constructor() {
  //   this.state = {
  //     price: 118,
  //     time: 45
  //   }
  // }

  onPullDownRefresh() {
    Taro.showNavigationBarLoading()
  }

  onReachBottom() {
  }

  async handleClick() {
    const { id, storeId, info } = this.state
    const res = await http('custom/oneKeyUpOrder', {
      jsUserId: id,
      serviceId: info.serviceId,
      storeId
    })
    Taro.navigateTo({
      url: `/pages/takeSucc/takeSucc?id=${id}&storeId=${storeId}&orderId=${res}`
    })
  }

  render() {
    return (
      <View className="takeNumberPage">
        <TechnicianInfo info={this.state.info}></TechnicianInfo>
        <View className="takeNumberServiceName">
          <Text>服务项目</Text>
        </View>
        <View className="takeNumberServiceDesc">
          <View className="takeNumberServiceDetail">
            <Text>{this.state.info.service}</Text>
            <Text className="takeNumberServiceTime">
              {this.state.info.serviceTime}分钟
            </Text>
          </View>
          <View className="takeNumberServiceDot">
            <View className="takeNumberServiceDotInner"></View>
          </View>
        </View>
        <Price
          price={this.state.info.price}
          handleClick={() => this.handleClick()}
          time={this.state.info.serviceTime}
          text="确定取号"
        ></Price>
      </View>
    )
  }

  // enablePullDownRefresh
}
