import Taro, { Component } from '@tarojs/taro'
import { WebView } from '@tarojs/components'

export default class Outer extends Component {
  constructor() {
    this.state = {
      url: this.$router.params.url
    }
  }
  // 地址需要配置才能打开

  render() {
    return <WebView url={this.state.url}></WebView>
  }
}
