import Taro from '@tarojs/taro'
import { View, Text, Button } from '@tarojs/components'
import PhoneButton from '@/components/phoneButton/phoneButton'
import http from '../../utils/http'
import './price.less'

export default function Price(props) {
  const { price = 0, time = 0, text = '取号', handleClick } = props
  const mobile = Taro.getStorageSync('mobile')

  const getPhone = async info => {
    const { mobile: resMobile, token } = await http('minapp/phone', info)
    Taro.setStorageSync('token', token)
    Taro.setStorageSync('mobile', resMobile)
    handleClick()
  }

  return (
    <View class="bottomPrice">
      <View class="bottomPriceInner">
        <View class="bottomPriceNum">
          <Text class="bottomPriceMoney">
            ￥<Text class="bottomPriceMoneyInner">{price}</Text>
          </Text>
          <Text>/{time}分钟</Text>
        </View>
        {mobile ? (
          <PhoneButton callback={info => getPhone(info)}>{text}</PhoneButton>
        ) : (
          <Button onClick={() => handleClick()} className="priceButton">
            {text}
          </Button>
        )}
      </View>
    </View>
  )
}
