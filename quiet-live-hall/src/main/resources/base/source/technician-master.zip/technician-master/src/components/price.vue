<template>
  <view class="bottomPrice">
    <view class="bottomPriceInner">
      <view class="bottomPriceNum">
        <text class="bottomPriceMoney">
          ￥
          <text class="bottomPriceMoneyInner">{{price}}</text>
        </text>
        <text>/{{time}}分钟</text>
      </view>
      <view @click="$emit('handleClick')" class="priceButton">立即支付</view>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    price: {
      type: [Number, String],
      default: ''
    },
    time: {
      type: [Number, String],
      default: ''
    }
  }
}
</script>

<style>
.bottomPrice {
  position: fixed;
  width: 100%;
  left: 0;
  bottom: 0;
  background: #ffffff;
}
.bottomPriceInner {
  padding: 13rpx 30rpx 17rpx 40rpx;
  font-size: 24rpx;
  color: #4a4a4a;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.bottomPriceMoneyInner {
  font-size: 42rpx;
}

.bottomPriceMoney {
  font-size: 24rpx;
  color: #a80000;
}

.priceButton {
  width: 200rpx;
  height: 70rpx;
  line-height: 70rpx;
  background: #b09e85;
  border-radius: 40rpx;
  font-size: 28rpx;
  color: #ffffff;
  margin: 0;
  text-align: center;
}
</style>
