import Taro, { Component } from '@tarojs/taro'
import { View} from '@tarojs/components'
import Banner from '@/components/banner/banner'
import Stores from '@/components/stores/stores'
import './index.less'

export default class Index extends Component {
  config = {
    navigationStyle: 'custom'
  }

  constructor(props) {
    super(props)
  }

  componentWillMount() {}

  componentWillUnmount() {}

  componentDidShow() {}

  componentDidHide() {}

  render() {
    return (
      <View className="index">
        <View class="BannerIndex">
          <Banner></Banner>
        </View>
        <Stores></Stores>
      </View>
    )
  }
}