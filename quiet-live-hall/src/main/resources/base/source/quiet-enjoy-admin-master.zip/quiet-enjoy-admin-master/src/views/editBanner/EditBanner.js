import React, { useContext, useEffect, useState } from 'react'
import CommForm from '@components/commForm/CommForm'
import { context } from '@components/Provider'
import { message, Layout, Upload, Icon } from 'antd'

const { Content } = Layout

const deafultList = [
  // {
  //   type: 'input',
  //   label: '上传图片',
  //   field: 'imgUrl',
  //   rules: ['required']
  // },
  {
    type: 'input',
    label: '名字',
    field: 'name'
  },
  {
    type: 'input',
    label: '跳转链接',
    field: 'url'
  },
  {
    type: 'select',
    label: '是否有效',
    field: 'delFlag',
    options: [{ value: '0', text: '无效' }, { value: '1', text: '有效' }]
  },

  // {
  //   type: 'date',
  //   label: '创建时间',
  //   field: 'updateTime'
  // }
]

export default function EditServices() {
  const { $fetch, history, $utils } = useContext(context)
  const [initValue, setInitValue] = useState({})
  const [list, setList] = useState(deafultList)
  const [imgUrl, setImgUrl] = useState('')
  const [loading, setLoading] = useState(false)

  const id = $utils.getQuery('id')

  useEffect(() => {
    async function getDetail() {
      const res = await $fetch('bi/jBanner/list', { id })
      const {records} = res
      const info = records[0] || {}
      setInitValue(info)
      setImgUrl(info.imgUrl || '')
      setList(
        list.map(item =>
          info[item.field] ? { ...item, value: info[item.field] } : item
        )
      )
    }
    if (id) {
      getDetail()
    }
  }, [id])

  async function toEdit(values) {
    await $fetch('bi/jBanner/save', {
      ...initValue,
      ...values,
      imgUrl,
    })
    message.success('操作成功', 2).then(() => {
      history.replace('/page/banner')
    })
  }

  const submit = values => {
    toEdit(values)
  }

  const uploadButton = (
    <div>
      <Icon type={loading ? 'loading' : 'plus'} />
      <div className="ant-upload-text">Upload</div>
    </div>
  )

  const customRequest = async info => {
    const formData = new FormData()
    formData.append('file', info.file)
    setLoading(true)
    const res = await $fetch('file/fileUpload', formData)
    setLoading(false)
    setImgUrl(res)
  }

  const handlePreview = ()=> {

  }

  return (
    <Content style={{ padding: '100px', backgroundColor: '#fff' }}>
      上传图片：
      <Upload
        name="file"
        listType="picture-card"
        className="avatar-uploader"
        showUploadList={false}
        onPreview={handlePreview}
        customRequest={customRequest}
      >
        {imgUrl ? (
          <img src={imgUrl} alt="avatar" style={{ width: '100%' }} />
        ) : (
          uploadButton
        )}
      </Upload>
      <CommForm list={list} layout="vertical" submit={submit} buttonText="提交"></CommForm>
    </Content>
  )
}
