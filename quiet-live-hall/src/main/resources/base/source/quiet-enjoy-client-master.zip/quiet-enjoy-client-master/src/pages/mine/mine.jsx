import Taro, { Component } from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import Card from '@/components/card/card'

import './mine.less'

export default class Mine extends Component {
  config = {
    navigationBarTitleText: '我的',
    // enablePullDownRefresh: true //全局
  }

  onPullDownRefresh() {
    // console.log(3)
  }

  onReachBottom() {
    // console.log(6)
  }

  render() {
    return (
      <View className="minePage">
        <Card></Card>
      </View>
    )
  }

  // enablePullDownRefresh
}
