import Taro, {Component}  from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import Price from '@/components/price/price'
import './pay.less'


export default class Pay extends Component {

  config = {
    navigationBarTitleText: '支付',
    // enablePullDownRefresh: true //全局
  }

  constructor(props){
    this.state = {
      info: {}
    }
  }


  handleClick(){
    Taro.navigateTo({
      url: '/pages/paySucc/paySucc'
    })
  }

  render() {
    return (
    <View className="payPage">
      <View className="payUl">
        <View className="payItem">
          <Text className="payItemLeft">工作室</Text>
          <Text>工作室</Text>
        </View>
        <View className="payItem">
          <Text className="payItemLeft">工作室</Text>
          <Text>工作室</Text>
        </View>
      </View>
      <View className="payUl">
        <View className="payItem">
          <Text className="payItemLeft">工作室</Text>
          <Text>工作室</Text>
        </View>
      </View>
      <Price
        price={this.state.info.price}
        handleClick={()=> this.handleClick()}
        time={this.state.info.time}
        text="立即支付"
      ></Price>
    </View>
  )
  }
}
