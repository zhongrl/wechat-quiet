import React, { useContext, useEffect, useState } from 'react'
import CommForm from '@components/commForm/CommForm'
import { context } from '@components/Provider'
import { message, Layout } from 'antd'

const { Content } = Layout

const deafultList = [
  {
    type: 'input',
    label: '门店名称',
    field: 'name'
  },
  {
    type: 'input',
    label: '门店地址',
    field: 'address'
  },
  // {
  //   type: 'input',
  //   label: '坐标',
  //   field: 'jwDu'
  // },
  {
    type: 'date',
    label: '开业时间',
    field: 'kyDate'
  },
  {
    type: 'input',
    label: '操作人',
    field: 'oper'
  },
  {
    type: 'select',
    label: '是否有效',
    field: 'delFlag',
    options: [{ value: '0', text: '无效' }, { value: '1', text: '有效' }]
  },


]

export default function EditServices() {
  const { $fetch, history, $utils } = useContext(context)
  const [initValue, setInitValue] = useState({})
  const [list, setList] = useState(deafultList)
  const [headImg, setHeadImg] = useState('')
  // const [loading, setLoading] = useState(false)

  const id = $utils.getQuery('id')

  useEffect(() => {
    async function getDetail() {
      const res = await $fetch('bi/jStore/selectByStoreId', { id })
      const info = res || {}
      setInitValue(info)
      setHeadImg(info.headImg || '')
      setList(
        list.map(item =>
          info[item.field] ? { ...item, value: info[item.field] } : item
        )
      )
    }
    if (id) {
      getDetail()
    }
  }, [id])

  async function toEdit(values) {
    await $fetch('bi/jStore/save', {
      ...initValue,
      ...values,
      headImg
    })
    message.success('操作成功', 2).then(() => {
      history.replace('/page/stores')
    })
  }

  const submit = values => {
    toEdit(values)
  }

  // const uploadButton = (
  //   <div>
  //     <Icon type={loading ? 'loading' : 'plus'} />
  //     <div className="ant-upload-text">Upload</div>
  //   </div>
  // )

  // const customRequest = async info => {
  //   const formData = new FormData()
  //   formData.append('file', info.file)
  //   setLoading(true)
  //   const res = await $fetch('file/fileUpload', formData)
  //   setLoading(false)
  //   setHeadImg(res)
  // }

  // const handlePreview = () => {}

  return (
    <Content style={{ padding: '100px', backgroundColor: '#fff' }}>
      {/* 上传门店头像：
      <Upload
        name="file"
        listType="picture-card"
        className="avatar-uploader"
        showUploadList={false}
        onPreview={handlePreview}
        customRequest={customRequest}
      >
        {headImg ? (
          <img src={headImg} alt="avatar" style={{ width: '100%' }} />
        ) : (
          uploadButton
        )}
      </Upload> */}
      <CommForm list={list} layout="vertical" submit={submit} buttonText="提交"></CommForm>
    </Content>
  )
}
