import Taro, { Component } from '@tarojs/taro'
import { View, Text, Image, Button, Navigator } from '@tarojs/components'
import photo from '@/assets/succ.png'
import './takeSucc.less'
import http from '../../utils/http'

export default class TakeSucc extends Component {
  config = {
    navigationBarTitleText: '取号成功'
  }

  constructor(props) {
    super(props)
    const { id, storeId, orderId } = this.$router.params
    this.state = {
      id,
      // storeId,
      orderId,
      info: {},
      orderInfo: {}
    }
  }

  componentDidMount() {
    this.getDeatail()
    this.getOrder()
  }

  async getDeatail() {
    const { id } = this.state
    const info = await http('custom/findJsSelectById', {
      id
    })
    this.setState({
      info
    })
  }
  async getOrder() {
    const { orderId } = this.state
    const { records } = await http('custom/list', {
      id: orderId
    })
    this.setState({
      orderInfo: records[0]
    })
  }

  handleClick() {
    Taro.navigateTo({
      url: '/pages/takeSucc/takeSucc'
    })
  }

  render() {
    return (
      <View className="takeSuccPage">
        <View className="takeSuccTop">
          <View className="takeSuccTopLeft">
            <View className="takeSuccTopTitle">
              <Text>{this.state.orderInfo.lineUpNumber}</Text>
            </View>
            <View>
              <Text>排队号码</Text>
            </View>
          </View>
          <View className="takeSuccTopItem">
            <View className="takeSuccTopTitle">
              <Text>{this.state.orderInfo.ddRenNum}</Text>
            </View>
            <View>
              <Text>前面人数</Text>
            </View>
          </View>
          <View className="takeSuccTopRight">
            <View className="takeSuccTopTitle">
              <Text>{this.state.orderInfo.ddTimeLong}</Text>
            </View>
            <View>
              <Text>预计等待</Text>
            </View>
          </View>
        </View>
        <View className="takeSuccMain">
          <View className="takeSuccMainPhoto">
            <Image src={this.state.info.headImg} className="takeSuccMainImg"></Image>
          </View>
          <View className="takeSuccMainText">
            <View className="takeSuccMainTextItem">
              <Text>{this.state.info.username}</Text>
            </View>
            <View className="takeSuccMainTextItem">
              <Text>
                {this.state.info.service}
              </Text>
            </View>
            <View className="takeSuccMainTextPrice">
              <Text className="takeSuccMainTextMoney">￥</Text>
              <Text>{this.state.info.price}</Text>
              <Text className="takeSuccMainTextTime">
                /{this.state.info.serviceTime}分钟
              </Text>
            </View>
          </View>
          <View className="takeSuccInfo">
            <View className="takeSuccMainRow">
              <Text>排队规则</Text>
            </View>
            <View className="takeSuccMainRow">
              <Text>1、请在前面等待20分钟时到店等候，避免排队被延后了哦；</Text>
            </View>
            <View className="takeSuccMainRow">
              <Text>2、如果叫号超过5分钟，你的排队将被延后处理；</Text>
            </View>
            <View className="takeSuccMainRow">
              <Text>3、等待时间仅供参考。如取消服务，请在叫号前取消排队。</Text>
            </View>
          </View>
        </View>
        <View className="takeSuccButtonRow">
          <Navigator className="takeSuccButton" openType="switchTab" url="/pages/order/order">查看排队</Navigator>
        </View>
      </View>
    )
  }
}
