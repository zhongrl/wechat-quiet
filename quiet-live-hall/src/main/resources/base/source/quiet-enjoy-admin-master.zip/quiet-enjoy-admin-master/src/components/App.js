import React from 'react'
import { HashRouter } from 'react-router-dom'
import { Provider } from '@components/Provider'
import PageRouter from '@components/PageRouter'
import { ConfigProvider } from 'antd'
import zhCN from 'antd/es/locale/zh_CN'

function App() {
  return (
    <ConfigProvider locale={zhCN}>
      <Provider>
        <HashRouter>
          <PageRouter></PageRouter>
        </HashRouter>
      </Provider>
    </ConfigProvider>
  )
}

export default App
