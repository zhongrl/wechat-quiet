import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components'
import Index from './pages/index'

import './app.less'

// 如果需要在 h5 环境中开启 React Devtools
// 取消以下注释：
// if (process.env.NODE_ENV !== 'production' && process.env.TARO_ENV === 'h5')  {
//   require('nerv-devtools')
// }

class App extends Component {
  config = {
    pages: [
      'pages/index/index',
      'pages/login/login',
      'pages/editComment/editComment',
      'pages/share/share',
      'pages/paySucc/paySucc',
      'pages/pay/pay',
      'pages/cancleTake/cancleTake',
      'pages/takeSucc/takeSucc',
      'pages/technicianDetail/technicianDetail',
      'pages/technician/technician',
      'pages/mine/mine',
      'pages/order/order',
      'pages/takeNumber/takeNumber',
      'pages/outer/outer',
      'pages/getShare/getShare'
    ],
    tabBar: {
      color: '#4A4A4A',
      selectedColor: '#AE9B75',
      borderStyle: 'white',
      list: [
        {
          pagePath: 'pages/index/index',
          text: '预约',
          iconPath: 'assets/tarbar/yuyue_gray.png',
          selectedIconPath: 'assets/tarbar/yuyue.png'
        },
        {
          pagePath: 'pages/order/order',
          text: '订单',
          iconPath: 'assets/tarbar/order_gray.png',
          selectedIconPath: 'assets/tarbar/order.png'
        },
        {
          pagePath: 'pages/mine/mine',
          text: '我的',
          iconPath: 'assets/tarbar/mine_gray.png',
          selectedIconPath: 'assets/tarbar/mine.png'
        }
      ]
    },
    window: {
      backgroundTextStyle: 'light',
      navigationBarBackgroundColor: '#fff',
      navigationBarTitleText: 'WeChat',
      navigationBarTextStyle: 'black'
    },
    permission: {
      'scope.userLocation': {
        desc: '你的位置信息将用于计算与门店的距离' // 高速公路行驶持续后台定位
      }
    }
  }

  componentDidMount() {}

  componentDidShow() {}

  componentDidHide() {}

  componentDidCatchError() {}

  // 在 App 类中的 render() 函数没有实际作用
  // 请勿修改此函数
  render() {
    return (
      <View className="app">
        <Index />
      </View>
    )
  }
}

Taro.render(<App />, document.getElementById('app'))
