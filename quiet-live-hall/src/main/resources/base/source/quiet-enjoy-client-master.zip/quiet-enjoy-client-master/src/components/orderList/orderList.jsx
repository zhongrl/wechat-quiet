import Taro from '@tarojs/taro'
import { View, Text, Button, Image } from '@tarojs/components'
import usePosition from '@/utils/usePosition'
import local from '@/assets/local_hight.png'
import './orderList.less'

export default function OrderList(props) {
  const { list = [], getList, tabIndex } = props
  const positions = usePosition(tabIndex === 0 ? list : [], getList)
  const cancle = item => {
    Taro.navigateTo({
      url: `/pages/cancleTake/cancleTake?orderId=${item.id}`
    })
  }

  const titles = {
    '1': '已评论',
    '2': '待支付',
    '3': '服务中',
    '4': '排队中',
    '5': '取消'
  }

  const callOne = num => {
    Taro.makePhoneCall({
      phoneNumber: num
    })
  }

  const toLocation = (item) => {
    const {jwDu, address = '', name = ''} = item
    const [lat, lng] = jwDu ? jwDu.split(',') : ['', '']
    if(lat){
      Taro.openLocation({
        latitude: Number(lat),
        longitude: Number(lng),
        name,
        address,
        scale: 18
      })
    }
  }

  return (
    <View className="orderList">
      {list.map(item => (
        <View className="orderItem" key={item.id}>
          {/* 订单状态，1 已支付，2待支付，3，服务中，4 排队中，5取消 */}

          <View className={`orderTitle${item.status}`}>
            <View>
              <Text className="orderTitleBold">{titles[item.status]}</Text>
            </View>
            {item.status == 4 ? (
              <View className="orderTitleRight">
                <Text className="orderBefore">前面{item.ddRenNum}人</Text>
                <Text>约等待{item.ddTimeLong}分钟</Text>
              </View>
            ) : null}
          </View>
          <View className="orderLocal">
            <Text>{item.storeName}</Text>
            <View onClick={()=> toLocation(item)}>
              <Text>{tabIndex === 0 ? positions[0] : ''}</Text>
              <Image src={local} className="localIcon"></Image>
            </View>
          </View>
          <View className="orderText">
            <View className="orderTextItem">
              <Text className="orderTextLeft">排队编号</Text>
              <Text>{item.lineUpNumber}</Text>
            </View>
            <View className="orderTextItem">
              <Text className="orderTextLeft">服务项目</Text>
              <Text>{item.serviceName}</Text>
            </View>
            <View className="orderTextItem">
              <Text className="orderTextLeft">技 师</Text>
              <Text>{item.jsUsername}</Text>
            </View>
            <View className="orderTextItem">
              <Text className="orderTextLeft">合 计</Text>
              <Text>￥{item.price}</Text>
            </View>
            <View className="orderTextItem">
              <Text className="orderTextLeft">取号时间</Text>
              <Text>{item.createTime}</Text>
            </View>
          </View>
          {item.status == 4 ? (
            <View className="orderButtons">
              <Button
                onClick={() => cancle(item)}
                className="orderButtonCancle"
              >
                取消排队
              </Button>
              <Button
                className="orderButtonItem"
                onClick={() => callOne(item.jsMobile)}
              >
                一键呼叫
              </Button>
            </View>
          ) : null}
        </View>
      ))}
    </View>
  )
}
