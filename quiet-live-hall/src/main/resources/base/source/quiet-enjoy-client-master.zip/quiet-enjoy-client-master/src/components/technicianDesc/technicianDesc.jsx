import Taro from '@tarojs/taro'
import { View, Text, Image, Navigator } from '@tarojs/components'
import photo from '@/assets/succ.png'
import './technicianDesc.less'

export default function TechnicianDesc(props) {
  const { info, numberInfo, handleClick } = props
  return (
    <View className="technicianDesc">
      <Image src={info.headImg} className="technicianDescImg"></Image>
      <View className="technicianDescDesc">
        <Text className="technicianDescName">{info.username}</Text>
        <Text>{info.level}</Text>
      </View>
      <View className="technicianDescTotal">
        <Text className="technicianDescTotalItem">评论数{numberInfo.plNum}</Text>
        <Text className="technicianDescTotalCenter">均分{numberInfo.avgNum}</Text>
        <Text
          className="technicianDescTotalItem"
          onClick={()=> handleClick()}
        >
          参看全部
        </Text>
      </View>
    </View>
  )
}
