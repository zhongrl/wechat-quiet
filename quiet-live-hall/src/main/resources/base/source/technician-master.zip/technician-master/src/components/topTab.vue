<template>
  <view class="top-tab">
    <view class="top-tab-content">
      <view
        v-for="(item,index) in list"
        @click="$emit('changeTab', index)"
        :key="index"
        class="top-tab-item"
      >
        <text>{{item.text}}</text>
        <text
          v-if="!isNaN(item.total) && item.total > 0"
          class="tab-total"
          :class="[index === tabIndex ? 'active-total': '']"
        >{{item.total}}</text>
        <view v-if="index === tabIndex" class="tab-line"></view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    tabIndex: {
      type: Number,
      default: 0
    },
    list: {
      required: true,
      default: () => []
    }
  }
}
</script>

<style>
.top-tab {
  height: 88rpx;
}
.top-tab-content {
  position: fixed;
  left: 0;
  top: 0;
  height: 88rpx;
  z-index: 100;
  width: 100%;
  display: flex;
  background: #ffffff;
  font-size: 28rpx;
  color: #030303;
  text-align: center;
}
.top-tab-item {
  flex: 1;
  position: relative;
  line-height: 40rpx;
  padding-top: 24rpx;
}
.tab-total {
  background: #4a4a4a;
  border-radius: 8rpx;
  border-radius: 8rpx;
  font-size: 28rpx;
  color: #ffffff;
  line-height: 30rpx;
  display: inline-block;
  padding: 0 8rpx;
  margin-left: 5px;
}
.active-total {
  background: #ae9b75;
  color: #ffffff;
}
.tab-line {
  background: #ae9b75;
  border-radius: 3rpx;
  border-radius: 3rpx;
  width: 110rpx;
  height: 6rpx;
  position: absolute;
  left: 50%;
  bottom: 0;
  transform: translateX(-50%);
}
</style>
