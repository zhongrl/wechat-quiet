import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components'
// import TabTitle from '@/components/tabTitle/tabTitle'
import EmptyList from '@/components/emptyList/emptyList'
import StoresDetail from '@/components/storesDetail/storesDetail'
import TechnicianList from '@/components/technicianList/technicianList'
// import Service from '@/components/service/service'
import http from '../../utils/http'

import './technician.less'

export default class Mine extends Component {
  config = {
    navigationBarTitleText: '门店详情',
    enablePullDownRefresh: true //全局
  }

  constructor(props) {
    super(props)
    const { id } = this.$router.params
    this.state = {
      id,
      // tabList: [
      //   { text: '门店技师', isChecked: true },
      //   { text: '服务标准', isChecked: false }
      // ],
      info: {},
      current: 1,
      size: 20,
      total: 0,
      list: [],
      isInit: false,
      isFetch: false
    }
  }

  componentDidMount() {
    this.getDeatail()
    this.getList()
  }

  async getDeatail() {
    const { id } = this.state
    const info = await http('custom/findXcxJStoreSelectById', {
      id
    })
    this.setState({
      info
    })
  }

  getList(page = 1) {
    this.setState(
      {
        isFetch: true
      },
      async () => {
        const { id, size, list } = this.state
        const { records, total } = await http('custom/findJs', {
          current: page,
          size,
          storeId: id
        })
        Taro.stopPullDownRefresh()
        this.setState({
          current: page,
          total,
          isInit: true,
          isFetch: false,
          list: page > 1 ? [...list, ...records] : records
        })
      }
    )
  }

  onPullDownRefresh() {
    this.getList()
  }

  onReachBottom() {
    const { current, total, list, isFetch } = this.state
    if (list.length < total && !isFetch) {
      this.getList(current + 1)
    }
  }

  // changeTab(i) {
  //   const { tabList } = this.state
  //   this.setState({
  //     current: 1,
  //     tabList: tabList.map((item, index) => ({
  //       ...item,
  //       isChecked: index === i
  //     }))
  //   })
  // }

  render() {
    return (
      <View className="technicianPage">
        <StoresDetail info={this.state.info}></StoresDetail>
        {/* <TabTitle
          list={this.state.tabList || []}
          changeTab={i => this.changeTab(i)}
        ></TabTitle> */}
        <View>
          <TechnicianList
            storeId={this.state.id}
            list={this.state.list}
          ></TechnicianList>
          {this.state.isInit && this.state.list.length === 0 ? (
            <EmptyList></EmptyList>
          ) : null}
        </View>
        {/* {this.state.tabList.findIndex(item => item.isChecked) === 0 ? (
          <View>
            <TechnicianList storeId={this.state.id} list={this.state.list}></TechnicianList>
            {this.state.isInit && this.state.list.length === 0 ? (
              <EmptyList></EmptyList>
            ) : null}
          </View>
        ) : (
          <Service storeId={this.state.id}></Service>
        )} */}
      </View>
    )
  }
}
