<template>
  <view class="payPage">
    <view class="payUl">
      <view class="payItem">
        <text class="payItemLeft">工作室</text>
        <text>{{info.storeName}}</text>
      </view>
      <view class="payItem">
        <text class="payItemLeft">技师</text>
        <text>{{info.jsUsername}}</text>
      </view>
      <view class="payItem">
        <text class="payItemLeft">{{info.serviceName}}</text>
        <text>¥{{info.price}}</text>
      </view>
    </view>
    <view class="payUl">
      <view class="payItem">
        <text class="payItemLeft">优惠券</text>
        <text :class="{grayText: !info.couponName}">{{info.couponName || '无可用优惠券'}}</text>
      </view>
    </view>
    <price :price="info.price" @handleClick="toPay" :time="info.time" text="立即支付"></price>
  </view>
</template>

<script>
// 3./order/selectNotPayJOrder只需要token  查询订单信息 优惠券信息都在里面了

// 4./order/createOrderParam 只需要token  支付签名接口， 不需要传参数

import http from '@/utils/http'
import price from '@/components/price'
export default {
  components: {
    price
  },
  data() {
    return {
      info: {},
      payInfo: {},
      token: ''
    }
  },
  onLoad(option) {
    const { code, token } = option
    if (token) {
      // 小程序中打开web页面
      // uni.setStorageSync('token', token)
      this.token = token
      this.getDetail()
    } else if (code) {
      // 公众号中
      this.codeLogin(code)
    } else {
      // error
      uni.showToast({
        title: '参数错误，请重试！',
        icon: 'none',
        duration: 5000
      })
    }
  },
  methods: {
    // 缺少初始获取状态的接口
    async getDetail() {
      const { token } = this
      const info = await http('order/selectNotPayJOrder', {}, { token })
      this.info = info
      uni.setStorageSync('payInfo', JSON.stringify(info))
    },
    async codeLogin(code) {
      const { token } = await http('custom/login', { code })
      this.token = token
      this.getDetail()
    },
    async toPay() {
      const { token } = this
      const payInfo = await http('order/createOrderParam', {}, { token })
      
      this.payInfo = payInfo
      if (typeof WeixinJSBridge == 'undefined') {
        if (document.addEventListener) {
          document.addEventListener(
            'WeixinJSBridgeReady',
            this.onBridgeReady,
            false
          )
        }
        if (document.attachEvent) {
          document.attachEvent('WeixinJSBridgeReady', this.onBridgeReady)
          document.attachEvent('onWeixinJSBridgeReady', this.onBridgeReady)
        }
      } else {
        this.onBridgeReady()
      }
    },
    onBridgeReady() {
      const { payInfo } = this
      WeixinJSBridge.invoke(
        'getBrandWCPayRequest',
        {
          appId: payInfo.appId, //公众号名称，由商户传入
          timeStamp: payInfo.timeStamp, //时间戳，自1970年以来的秒数
          nonceStr: payInfo.nonceStr, //随机串
          package: payInfo.packageValue,
          signType: payInfo.signType || 'MD5', //微信签名方式：
          paySign: payInfo.paySign //微信签名
        },
        res => {
          if (res.err_msg == 'get_brand_wcpay_request:ok') {
            // 使用以上方式判断前端返回,微信团队郑重提示：
            //res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。
            this.paySucc()
          }
        }
      )
    },
    async paySucc() {
      const { info, token } = this
      // const id = await http('custom/orderPayEndService')
      // 跳转到小程序
      uni.navigateTo({
        url: `/pages/paySucc/paySucc?price=${info.jyPrice}&token=${token}`
      })
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
}

.payUl {
  background: #ffffff;
  font-size: 28rpx;
  color: #030303;
  line-height: 40rpx;
  padding: 0 30rpx 0 40rpx;
  margin-bottom: 20rpx;
}

.payItem {
  padding: 24rpx 0;
  display: flex;
  justify-content: space-between;
  border-bottom: solid 1rpx #d8d8d8;
}

.payItem:last-child {
  border: none;
}

.payItemLeft {
  color: #9b9b9b;
}
.grayText {
  color: #9b9b9b;
}
</style>
