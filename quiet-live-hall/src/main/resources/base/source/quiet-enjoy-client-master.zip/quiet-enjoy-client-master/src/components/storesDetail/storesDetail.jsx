import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import local from '@/assets/local_white.png'
import './storesDetail.less'

export default function TabTitle(props) {
  const { info } = props

  const toLocation = (item) => {
    const {jwDu, address = '', name = ''} = item
    const [lat, lng] = jwDu ? jwDu.split(',') : ['', '']
    if(lat){
      Taro.openLocation({
        latitude: Number(lat),
        longitude: Number(lng),
        name,
        address,
        scale: 18
      })
    }
  }

  return (
    <View className="technicianDetail">
      <View className="technicianDetailBg">
        <Image src={info.imgurl} className="technicianDetailBgInner"></Image>
      </View>
      <View className="technicianDetailInner">
        <View className="technicianDetailTitle" onClick={()=> toLocation(info)}>
          <Image src={local} className="technicianDetailLocal"></Image>
          <Text>{info.name}</Text>
        </View>
        <View onClick={()=> toLocation(info)}>
          <Text>{info.address}</Text>
        </View>
        <View>
          <Text>{info.remarke}</Text>
        </View>
      </View>
    </View>
  )
}
