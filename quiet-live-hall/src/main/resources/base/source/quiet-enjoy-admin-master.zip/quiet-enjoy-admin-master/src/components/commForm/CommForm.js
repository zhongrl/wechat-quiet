import React, { useContext } from 'react'
import {
  Form,
  Input,
  Button,
  Select,
  TimePicker,
  DatePicker
} from 'antd'
import { context } from '@components/Provider'
import dayjs from 'dayjs'
import moment from 'moment'
import 'moment/locale/zh-cn'

const { RangePicker } = DatePicker

const { Option } = Select

const defaultFormItemLayout = {
  labelCol: {
    xs: { span: 2 },
    sm: { span: 2 }
  },
  wrapperCol: {
    xs: { span: 8 },
    sm: { span: 8 }
  }
}

function CommForm(props) {
  const {
    list,
    submit,
    layout = 'inline',
    buttonText = '搜索',
    isShowReset = true,
    isShowLabel = true,
    formItemLayout = {},
    block = false,
    form
  } = props
  const { history } = useContext(context)
  const { getFieldDecorator, validateFields } = form

  const timeFormat = 'HH:mm'
  const dateFormat = 'YYYY-MM-DD'

  const mixItemLayout =
    layout === 'inline'
      ? { ...formItemLayout }
      : { ...defaultFormItemLayout, ...formItemLayout }

  const handleSubmit = e => {
    e.preventDefault()
    validateFields((err, values) => {
      if (!err) {
        const formatValues = Object.keys(values).reduce((pre, curr) => {
          let val = values[curr]
          if(Array.isArray(val)){
            val = val.map(v=> dayjs(v.format()).format(dateFormat))
          }
          if (typeof val === 'object' && !Array.isArray(val)) {
            const item = list.find(({ field }) => field === curr)
            if (item) {
              let { type, format } = item
              format = format
                ? format
                : type === 'date'
                ? dateFormat
                : timeFormat
              val = dayjs(val.format()).format(format)
            }
          }
          pre[curr] = val || ''
          return pre
        }, {})
        submit(formatValues, history)
      }
    })
  }

  const getInput = (item, index) => {
    const { type = 'input', label = '', attrs, options = [], format } = item
    if (type === 'input') {
      const placeholder = label ? `请输入${label}` : ''
      return <Input {...attrs} placeholder={placeholder} />
    }
    if (type === 'password') {
      const placeholder = label ? `请输入${label}` : ''
      return <Input.Password {...attrs} placeholder={placeholder} />
    }
    if (type === 'select') {
      const placeholder = label ? `请选择${label}` : ''
      return (
        <Select {...attrs} placeholder={placeholder}>
          {options.map((option, optionIndex) => (
            <Option value={option.value} key={`${index}-${optionIndex}`}>
              {option.text}
            </Option>
          ))}
        </Select>
      )
    }
    if (type === 'time') {
      return <TimePicker format={format || timeFormat} />
    }
    if (type === 'date') {
      const placeholder = label ? `请选择${label}` : ''
      return (
        <DatePicker placeholder={placeholder} format={format || dateFormat} />
      )
    }
    if (type === 'rangeDate') {
      // const placeholder = label ? `请选择${label}` : ''
      return (
        <RangePicker  format={format || dateFormat} />
      )
    }
  }

  const getRules = item => {
    const { label, rules = [] } = item
    return rules.map(rule => {
      if (typeof rule === 'object') {
        return rule
      }
      if (typeof rule === 'string') {
        if (rule === 'required') {
          return {
            required: true,
            message: `请输入${label}`
          }
        }
      }
      return {}
    })
  }

  const getItem = (item, index) => {
    const { field, value, format, type } = item
    const valueInfo =
      typeof value === 'undefined'
        ? {}
        : {
            initialValue:
              type === 'date' ? moment(value, format || dateFormat) : value
          }
    return getFieldDecorator(field, {
      ...valueInfo,
      rules: getRules(item, index)
    })(getInput(item, index))
  }

  return (
    <div className="form">
      <Form
        layout={layout}
        onSubmit={handleSubmit}
        {...mixItemLayout}
        className={layout === 'inline' ? 'inline-form' : ''}
      >
        {list.map((item, index) => (
          <Form.Item label={isShowLabel ? item.label || '' : ''} key={index}>
            {getItem(item, index)}
          </Form.Item>
        ))}

        <Form.Item className={layout === 'inline' ? 'from-buttons' : ''}>
          {isShowReset ? (
            <Button
              block={block}
              onClick={() => form.resetFields()}
              style={{ marginRight: '40px' }}
            >
              重置
            </Button>
          ) : null}

          <Button type="primary" htmlType="submit" block={block}>
            {buttonText}
          </Button>
        </Form.Item>
      </Form>
    </div>
  )
}

export default Form.create({
  name: 'form',
  onValuesChange: (props, ...other) =>
    typeof props.updateValue === 'function' ? props.updateValue(...other) : ''
})(CommForm)
