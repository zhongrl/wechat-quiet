<template>
  <view class="orderDetail">
    <view class="orderDetailText">
      <view class="orderDetailTextItem">
        <text>订单号</text>
        <text class="orderDetailRightText">{{detail.orderNumber}}</text>
      </view>
      <view class="orderDetailTextItem">
        <text>服务时间</text>
        <text
          class="orderDetailRightText"
        >{{detail.jsServiceTime ? detail.jsServiceTime.replace(/:\d{2}$/, ''): ''}}</text>
      </view>
      <view class="orderDetailTextItem">
        <text>{{detail.serviceName}}</text>
        <text class="orderDetailRightText">￥{{detail.orgPrice}}</text>
      </view>
      <view class="orderDetailTextItem">
        <text>订单实付</text>
        <text class="orderDetailRedText">￥{{detail.price}}</text>
      </view>
    </view>
    <empty-list v-if="list.length === 0 && loadingStatus === 2"></empty-list>
    <view class="commentList">
      <view class="commentItem" v-for="item in list" :key="item.id">
        <view class="commentPhoto">
          <image class="photo" v-if="item.wxHeadImg" :src="item.wxHeadImg" />
        </view>
        <view class="commentDescription">
          <view class="commentTop">
            <text>{{item.wxUserName}}</text>
            <view class="commentStar">
              <star :num="item.avgNum"></star>
            </view>
          </view>
          <view class="commentText">{{item.remark}}</view>
          <view class="commentBottom">
            <text>技师：{{item.userName}}</text>
            <text>{{item.createTime.split(' ')[0]}}</text>
          </view>
          <view>
            <img-list :list="[item.img1, item.img2, item.img3]"></img-list>
          </view>
        </view>
      </view>
    </view>
    <uni-loadmore v-if="list.length >= size" :status="list.length < total ? 'loading' : 'noMore'"></uni-loadmore>
  </view>
</template>

<script>
import { uniCalendar, uniLoadMore } from '@dcloudio/uni-ui'
import emptyList from '@/components/emptyList'
import star from '@/components/star'
import imgList from '@/components/imgList'
import http from '@/utils/http'

export default {
  components: {
    'uni-loadmore': uniLoadMore,
    star,
    'empty-list': emptyList,
    'img-list': imgList
  },
  data() {
    return {
      detail: {},
      size: 15,
      current: 1,
      total: 0,
      loadingStatus: 0, // 0 未开始，1请求中，2请求完成
      list: []
    }
  },
  onLoad(option) {
    this.getDetail(option.id)
    this.getList(option.id)
  },
  onReachBottom() {
    const { list, total, current } = this
    if (list.length < total) {
      // this.getList(current + 1)
    }
  },
  methods: {
    async getDetail(id) {
      const { records } = await http('js/list', { id })
      this.detail = records[0] || {}
    },
    async getList(id,page = 1) {
      const { loadingStatus, size, current, list } = this
      if (loadingStatus === 1) {
        return false
      }
      this.loadingStatus = 1
      const records = await http('js/jEvaluate/selectById', {
        orderId: id
      })
      // this.total = total
      // this.current = page
      this.loadingStatus = 2
      this.list = records ? [records] : []
    }
  }
}
</script>

<style>
.orderDetail {
  background: #f9f9f9;
  min-height: 100vh;
}

.orderDetailText {
  background: #fff;
}

.orderDetailTextItem {
  display: flex;
  justify-content: space-between;
  padding: 24rpx 0;
  margin: 0 30rpx 0 40rpx;
  border-bottom: solid 1rpx #d8d8d8;
  font-size: 28rpx;
  color: #9b9b9b;
  line-height: 40rpx;
}

.orderDetailRightText {
  color: #000000;
}

.orderDetailTextItem:last-child {
  border: none;
}

.orderDetailRedText {
  color: #a80000;
}

.commentList {
  margin-top: 10rpx;
}

.commentItem {
  background: #fff;
  display: flex;
  margin-bottom: 10rpx;
  padding: 30rpx 42rpx 25rpx 40rpx;
}

.commentPhoto {
  width: 80rpx;
  height: 80rpx;
  margin-right: 23rpx;
}
.photo {
  width: 80rpx;
  height: 80rpx;
  border-radius: 100%;
}

.commentDescription {
  flex: 1;
  font-size: 24rpx;
  color: #9b9b9b;
}

.commentTop {
  display: flex;
  justify-content: space-between;
  font-size: 28rpx;
  color: #030303;
  margin-bottom: 8rpx;
}

.commentBottom {
  margin-top: 20rpx;
  display: flex;
  justify-content: space-between;
  font-size: 20rpx;
  color: #9b9b9b;
}
</style>
