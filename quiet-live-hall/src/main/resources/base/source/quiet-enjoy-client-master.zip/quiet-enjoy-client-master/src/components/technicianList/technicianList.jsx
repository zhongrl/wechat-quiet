import Taro, { useEffect, useState } from '@tarojs/taro'
import { View, Text, Button, Image, Navigator } from '@tarojs/components'
import Modal from '@/components/modal/modal'
// import local from '@/assets/local_hight.png'
import './technicianList.less'

export default function TechnicianList(props) {
  const [showModal, setShowModal] = useState(false)
  const [current, setCurrent] = useState({})
  const { storeId, list = [] } = props

  const cancle = async (item, e) => {
    // e.preventDefault(); 
    // e.stopPropagation()
    setShowModal(true)
    setCurrent(item)
  }

  const handleClick = () => {
    setShowModal(false)
    Taro.navigateTo({
      url: `/pages/cancleTake/cancleTake?orderId=${current.id}`
    })
  }

  const yuYue = list.findIndex(({ isYuYue }) => isYuYue == 1) > -1

  return (
    <View className="technicianList">
      {list.map(item => (
        <View className="technicianItem" key={item.id}>
          <Navigator
            className="technicianNav"
            url={`/pages/technicianDetail/technicianDetail?id=${item.id}&storeId=${storeId}`}
          >
          <View className="technicianListPhoto">
            <Image className="technicianListPhotoInner" src={item.headImg} />
          </View>
          <View className="technicianListMain">
            <View className="technicianTop">
              <Text className="technicianBold">{item.username}<Text className="technicianLevel">{item.level}</Text></Text>
              
              <View>
                <Text>￥<Text className="through">{item.orgPrice}</Text></Text>
                <Text className="technicianBold">￥{item.price}</Text>
                <Text>/{item.serviceTime}分钟</Text>
              </View>
            </View>
            {/* 1 可接单，2 停止接单，3 休息中 */}
            <View className="technicianMain">
              {(item.jsStatus == 2 || item.jsStatus == 3) ? (
                <View className="technicianMainStop">
                  <View>
                    <Text>{item.jsStatus == 2 ? '停止接单' : '休息中'}</Text>
                  </View>
                </View>
              ) : item.isQuNum > 0 ? (
                <View className="technicianMainText">
                  <View>
                    <Text>前面有{item.ddRenNum}人</Text>
                  </View>
                  <View>
                    <Text className="grayText">约等候{item.ddTimeLong}</Text>
                  </View>
                </View>
              ) : (
                <View className="technicianMainCurrent">
                  <View>
                    <Text>立即取号，无需等待</Text>
                  </View>
                </View>
              )}
            </View>
          </View>
        </Navigator>
              {yuYue ? (
                item.isYuYue == 1 ? (
                  <Button
                    className="technicianButton"
                    onClick={(e) => cancle(item, e)}
                  >
                    已取号
                  </Button>
                ) : null
              ) : item.jsStatus == 1 ? (
                <Navigator
                  className="technicianButton"
                  url={`/pages/takeNumber/takeNumber?id=${item.id}&storeId=${storeId}`}
                >
                  取号
                </Navigator>
              ) : (
                <Button className="technicianButtonCancle">暂停取号</Button>
              )}
        </View>
      ))}
      {showModal ? (
        <Modal
          title="取消订单"
          content={['是否需要取消订单？']}
          buttonText="确认"
          cancleButtonText="关闭"
          handleClick={() => handleClick()}
          cancleHandleClick={() => setShowModal(false)}
        ></Modal>
      ) : null}
    </View>
  )
}
