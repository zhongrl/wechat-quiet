import Taro, {Component} from '@tarojs/taro'
import { View, Text, Image, Button, Textarea } from '@tarojs/components'
import TechnicianInfo from '@/components/technicianInfo/technicianInfo'
import http, {upload} from '@/utils/http'
import EditStar from '@/components/editStar/editStar'
import Modal from '@/components/modal/modal'
import camera from '@/assets/camera.png'
import './editComment.less'

export default class EditComment extends Component {
  config = {
    navigationBarTitleText: '评价'
  }

  constructor(props) {
    super(props)
    this.state = {
      showModal: false,
      isShowSucc: false,
      imgList: [],
      info: {},
      fetchData: {}
    }
  }

  componentDidMount() {
    this.getDetail()
  }

  async getDetail(){
    const info = await http('order/selectNotPayJOrder')
    this.setState({
      info,
      fetchData: {
        userId: info.jsUserId,
        orderId: info.id,
        jsManyi: 0,
        serviceYx: 0,
        gtDw: 0,
        remark: ''
      }
    })
  }

  async submit () {
    const {fetchData, imgList} = this.state
    const imgInfo = imgList.reduce((pre, curr, index)=> {
      pre[`img${index + 1}`] = curr
      return pre
    }, {})
    const info = await http('custom/jEvaluate/save', {...fetchData, ...imgInfo})
    this.setState({
      isShowSucc: true
    })
  }

  chooseImg() {
    Taro.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: async (res) => {
        const tempFilePath = res.tempFilePaths[0]
        const img = await upload('file/fileUpload', tempFilePath)
        const {imgList} = this.state
        this.setState({
          imgList: [...imgList, img]
        })
      }
    })
  }
  changeInput(e){
    const {fetchData} = this.state
    this.setState({
      fetchData: {
        ...fetchData,
        remark: e.detail.value
      }
    })
  }

  changeStar(n, type){
    const {fetchData} = this.state
    if(type === 1){
      this.setState({
        fetchData: {
          ...fetchData,
          jsManyi: n + 1
        }
      })
    }
    if(type === 2){
      this.setState({
        fetchData: {
          ...fetchData,
          serviceYx: n + 1
        }
      })
    }
    if(type === 3){
      this.setState({
        fetchData: {
          ...fetchData,
          gtDw: n + 1
        }
      })
    }
  }

  showImg(url){
    const {imgList} = this.state
    Taro.previewImage({
      current: url,
      urls: imgList,
    })
  }

  // 评论成功
  handleSucc(){
    this.setState({
      isShowSucc: true
    })
    Taro.navigateTo({
      url: `/pages/share/share`
    })
  }

  render() {
    return (
    <View className="editCommentPage">
      {this.state.fetchData.remark}
      <View className="editCommentMain">
        <TechnicianInfo info={{headImg: this.state.info.jsHeadImg, username: this.state.info.jsUsername, jsLevel: this.state.info.jsLevel}}></TechnicianInfo>
        <View className="editCommentItem">
          <Text className="editCommentLable">技师技术是否满意</Text>
          <View className="editCommentStar">
            <EditStar handleClick={(n)=> this.changeStar(n, 1)} num={this.state.fetchData.jsManyi || 0}></EditStar>
          </View>
        </View>
        <View className="editCommentItem">
          <Text className="editCommentLable">服务是否用心</Text>
          <View className="editCommentStar">
            <EditStar handleClick={(n)=> this.changeStar(n, 2)} num={this.state.fetchData.serviceYx || 0}></EditStar>
          </View>
        </View>
        <View className="editCommentItem">
          <Text className="editCommentLable">沟通是否到位</Text>
          <View className="editCommentStar">
            <EditStar handleClick={(n)=> this.changeStar(n, 3)} num={this.state.fetchData.gtDw || 0}></EditStar>
          </View>
        </View>
        <View className="editCommentDesc">
          <View className="editCommentDescText">
            <Textarea
              className="editCommentTextarea"
              placeholder="越表扬越优秀！不要吝啬你的赞美呀！"
              value={this.state.fetchData.remark} onInput={e=> this.changeInput(e)}
            ></Textarea>
          </View>
          <View className="editCommentImgs">

            {this.state.imgList.map(url=> (
              <View className="editCommentImgsItem" key={url}>
                <Image onClick={(url)=> this.showImg(url)} className="showImgItem" src={url}></Image>
              </View>
            ))}

            {this.state.imgList.length < 3 ? (
              <View className="editCommentImgsItem" onClick={()=> this.chooseImg()}>
                <View className="editCommentUpload">
                  <Image className="editCamera" src={camera}></Image>
                </View>
                <View>
                  <Text>添加照片</Text>
                </View>
              </View>
            ) : null}
          </View>
        </View>
        <View className="editCommentBottom">
          <Button className="editCommentButton" onClick={()=> this.submit()}>提交</Button>
        </View>
      </View>
      {this.state.showModal ? (
        <Modal
          title="温馨提示"
          content={['写点啥呗！']}
          buttonText="确认"
          // handleClick={()=> this.handleClick()}
        ></Modal>
      ) : null}

      {this.state.isShowSucc ? (
        <Modal
          title="评价成功"
          content={['哇哦！', '你的评价是我们继续努力的动力！']}
          buttonText="知道了"
          handleClick={()=> this.handleSucc()}
        >
        </Modal>
      ) : null}
    </View>
  )
  }
}
