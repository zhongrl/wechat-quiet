import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import photo from '@/assets/succ.png'
import './technicianInfo.less'

export default function TechnicianInfo(props) {
  const {info} = props
  return (
    <View className="technicianInfo">
      <Image src={info.headImg} className="technicianInfoImg"></Image>
      <View className="technicianInfoDesc">
        <Text className="technicianInfoName">{info.username}</Text>
        {info.jsLevel ? <Text className="technicianInfoLevel">{info.jsLevel}</Text> : null}
      </View>
    </View>
  )
}
