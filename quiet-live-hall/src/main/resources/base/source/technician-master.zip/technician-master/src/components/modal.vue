<template>
  <view class="modal">
    <view class="modalBlock"></view>
    <view class="modalMain">
      <view class="modalTitle">
        <text>{{title}}</text>
      </view>

      <view class="modalDesc" v-if="content.length > 0">
        <view class="modalDescRor" v-for="(des, i) in content" :key="i">
          <text>{{des}}</text>
        </view>
      </view>

      <view class="modalButtons" v-if="cancleButtonText">
        <button
          class="modalButtonCancleItem"
          @click="$emit('cancleHandleClick')"
        >{{cancleButtonText}}</button>
        <button class="modalButtonItem" @click="$emit('handleClick')">{{buttonText}}</button>
      </view>

      <view class="modalBottom" v-else>
        <button class="modalButton" @click="$emit('handleClick')">{{buttonText}}</button>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      default: '温馨提示'
    },
    content: {
      type: Array,
      default: () => []
    },
    buttonText: {
      type: String,
      default: '确认'
    },
    cancleButtonText: {
      type: String,
      default: ''
    }
    // handleClick,
    // cancleHandleClick
  }
}
</script>

<style>
.modalBlock {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 6;
}

.modalMain {
  position: fixed;
  left: 50%;
  transform: translateX(-50%);
  top: 299rpx;
  width: 600rpx;
  background: #ffffff;
  border-radius: 20rpx;
  z-index: 8;
  font-size: 28rpx;
  color: #030303;
  line-height: 40rpx;
  text-align: center;
}

.modalTitle {
  font-size: 36rpx;
  color: #030303;
  line-height: 50rpx;
  padding: 30rpx 0;
}

.modalDesc {
  width: 420rpx;
  margin: auto;
}

.modalButton {
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
  font-size: 32rpx;
  color: #ffffff;
  background: #b09e85;
  border-radius: 40rpx;
  margin: 100rpx auto 30rpx auto;
}

.modalButtons {
  display: flex;
  padding: 100rpx 30rpx 30rpx 30rpx;
}

.modalButtonItem {
  flex: 1;
  height: 80rpx;
  line-height: 80rpx;
  font-size: 32rpx;
  color: #ffffff;
  background: #b09e85;
  border-radius: 40rpx;
  margin-left: 30rpx;
}

.modalButtonCancleItem {
  flex: 1;
  height: 80rpx;
  line-height: 80rpx;
  font-size: 32rpx;
  color: #ffffff;
  background: #b09e85;
  border-radius: 40rpx;
  margin-right: 30rpx;
}
</style>
