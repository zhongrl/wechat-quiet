import Taro, { Component } from '@tarojs/taro'
import { View, Text, Image, Button, Textarea } from '@tarojs/components'
import shareLogo from '@/assets/share_logo.png'
import shareIcon from '@/assets/share_icon_min.png'
import http from '../../utils/http'
import email from '@/assets/email.png'
import './share.less'

export default class Share extends Component {
  config = {
    navigationBarTitleText: ''
  }

  constructor(props) {
    super(props)
    this.state = { couponId: '', openId: '', unionid: ''}
  }

  componentWillMount() {}

  componentDidMount() {
    this.getDetail()
  }

  componentWillUnmount() {}

  componentDidShow() {}

  onShareAppMessage(options) {
    const {couponId,openId, unionid} = this.state
    return {
      title: '为你的好友送上20元抵扣券',
      path: `/pages/login/login?couponId=${couponId}&openId=${openId}&unionid=${unionid}`,
      imageUrl: shareIcon,     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
    }
  }

  async getDetail(){
    const {couponId, openId, unionid} = await http('custom/selectUserDetail')
    this.setState({
      couponId,
      openId,
      unionid
    })
  }

  render() {
    return (
      <View className="sharePage">
        <View className="shareMain">
          <View className="shareLogoItem">
            <Image className="shareLogo" src={shareLogo}></Image>
          </View>
          <View className="shareEmailItem">
            <Image src={email} className="shareEmail"></Image>
          </View>
          <View className="shareText">
            <View className="shareTextRow">
              <Text>为你的好友送上</Text>
              <Text class="shareTextBold">20元</Text>
              <Text>抵扣券</Text>
            </View>
            <View className="shareTextTip">
              <Text>好友首次消费后</Text>
            </View>
            <View className="shareTextRow">
              <Text>你将获得</Text>
              <Text class="shareTextBold">20元</Text>
              <Text>奖励</Text>
            </View>
          </View>
          <View className="shareButtonRow">
            <Button className="shareButton" openType="share">
              分享给好友
            </Button>
          </View>
          <View className="shareBottomText">
            <Text>邀请越多 奖励越多</Text>
          </View>
          <View className="shareCompText">
            <Text>静享生活体验馆</Text>
          </View>
        </View>
      </View>
    )
  }
}
