import React, { lazy } from 'react'
import { Route } from 'react-router-dom'

const TestPage = lazy(() => import('@views/test/Test'))
const HomePage = lazy(() => import('@views/home/Home'))
const User = lazy(() => import('@views/user/User'))
const Technician = lazy(() => import('@views/technician/Technician'))
const Stores = lazy(() => import('@views/stores/Stores'))
const EditStores = lazy(() => import('@views/editStores/EditStores'))
const Operation = lazy(() => import('@views/operations/Operations'))
const Services = lazy(() => import('@views/services/Services'))
const EditTechnician = lazy(() =>
  import('@views/editTechnician/EditTechnician')
)
const EditServices = lazy(() => import('@views/editServices/EditServices'))
const Banner = lazy(() => import('@views/banner/Banner'))
const EditBanner = lazy(() => import('@views/editBanner/EditBanner'))

const Card = lazy(() => import('@views/card/Card'))
const UsedCard = lazy(() => import('@views/usedCard/UsedCard'))
const EditCard = lazy(() => import('@views/editCard/EditCard'))
const Order = lazy(() => import('@views/order/Order'))
const Turnover = lazy(() => import('@views/turnover/Turnover'))

const Comment = lazy(() => import('@views/comment/Comment'))

export default function CommRouter() {
  const routers = [
    // '/" exact component': Technician,
    { path: '/page/technician', component: Technician },
    { path: '/page/user', component: User },
    { path: '/page/editTechnician', component: EditTechnician },
    { path: '/page/stores', component: Stores },
    { path: '/page/editStores', component: EditStores },
    { path: '/page/operations', component: Operation },
    { path: '/page/banner', component: Banner },
    { path: '/page/card', component: Card },
    { path: '/page/usedCard', component: UsedCard },
    { path: '/page/order', component: Order },
    { path: '/page/turnover', component: Turnover },
    { path: '/page/comment', component: Comment },
    { path: '/page/editCard', component: EditCard },
    { path: '/page/editBanner', component: EditBanner },
    { path: '/page/services', component: Services },
    { path: '/page/editServices', component: EditServices },
    { path: '/page/test', component: TestPage },
    { path: '/page/home', component: HomePage }
  ]

  return (
    <>
      <Route path="/" exact component={Stores} />
      {routers.map(item => (
        <Route key={item.path} path={item.path} component={item.component} />
      ))}
    </>
  )
}
