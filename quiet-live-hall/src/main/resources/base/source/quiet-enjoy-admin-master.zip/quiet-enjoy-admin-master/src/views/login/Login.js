import React, { useContext } from 'react'
import CommForm from '@components/commForm/CommForm'
import { context } from '@components/Provider'
import { Layout } from 'antd'
import logo from '../../assets/logo.png'

const { Content, Footer } = Layout

// admin/111111

export default function Login() {
  const { $fetch, history } = useContext(context)
  if(localStorage.getItem('token')) history.push('/')
  async function toLogin(values) {
    const res = await $fetch('bi/syslogin', { ...values })
    localStorage.setItem('token', res)
    history.push('/')
  }

  const submit = values => {
    toLogin(values)
  }

  const list = [
    {
      type: 'input',
      label: '用户名',
      field: 'account',
      // value: '20',
      // attrs: {
      //   prefix: <Icon type="user" />
      // },
      rules: ['required']
    },
    {
      type: 'password',
      label: '密码',
      field: 'password',
      // value: '',
      // attrs: {},
      rules: [{ required: true, message: '请输入用户名' }]
    }
  ]

  const formItemLayout = {
    labelCol: {
      xs: { span: 0 },
      sm: { span: 0 }
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 24 }
    }
  }

  return (
    <Layout style={{ minHeight: '100vh', backgroundColor: '#f8f8f8' }}>
      <Content>
        <div className="login-main">
          <div className="logo">
            <img src={logo} alt="" />
          </div>
          <CommForm
            list={list}
            submit={submit}
            buttonText="登陆"
            isShowReset={false}
            isShowLabel={false}
            formItemLayout={formItemLayout}
            block={true}
            layout="vertical"
          ></CommForm>
        </div>
      </Content>
      <Footer style={{
      background: '#f8f8f8',
      padding: '10px 0',
      textAlign: 'center',
      marginTop: '10px'
    }}>静享生活馆后台管理系统 V1.0<br/>深圳市益享服务科技有限公司</Footer>
    </Layout>
  )
}
