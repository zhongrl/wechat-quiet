import React from 'react'
import { Table } from 'antd'

export default function Loading(props) {
  const { dataSource, columns, pagination = false } = props

  const computedData = dataSource.map((data, index) => {
    const { key = `${index}` } = data
    return {
      ...data,
      key
    }
  })

  const computedCoumns = columns.map((coumn, index) => {
    const { key, dataIndex } = coumn
    return {
      ...coumn,
      key: key ? key : dataIndex
    }
  })

  const scrollX = columns.reduce(
    (pre, { width = 150, fixed }) => (fixed ? pre : pre + width),
    1
  )

  const defaultPagination = {
    current: 1,
    pageSize: 15,
    showTotal: total => {
      return `共 ${total} 条`
    }
  }

  return (
    <div>
      <Table
        size="middle"
        columns={computedCoumns}
        dataSource={computedData}
        scroll={{ x: scrollX }}
        pagination={
          pagination ? { ...defaultPagination, ...pagination } : pagination
        }
      />
    </div>
  )
}
