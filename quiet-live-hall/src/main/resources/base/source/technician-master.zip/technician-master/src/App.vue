<script>
export default {
  onLaunch: function() {
    // console.log('App Launch')
  },
  onShow: function() {
    // console.log('App Show')
  },
  onHide: function() {
    // console.log('App Hide')
  }
}
</script>

<style>
page {
  font-family: PingFangSC-Regular;
  font-size: 24rpx;
  color: #9b9b9b;
}
uni-page-head{
  display: none;
}
/* .top-tab{
  display: none;
} */
.page {
  min-height: 100vh;
  background: #f9f9f9;
}
::-webkit-input-placeholder {
  color: #ccc;
}
</style>
