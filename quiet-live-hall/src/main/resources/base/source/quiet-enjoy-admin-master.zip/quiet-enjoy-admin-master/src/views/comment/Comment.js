import React, { useContext, useEffect, useState } from 'react'
import CommTable from '@components/commTable/CommTable'
import { context } from '@components/Provider'
import {
  Button,
  Modal,
  message,
  Layout,
  Avatar,
  Divider,
  Descriptions,
  Switch,
  Popover,
  Rate
} from 'antd'
// import { Link } from 'react-router-dom'
// import CommForm from '@components/commForm/CommForm'

const { Content } = Layout

const defaultInfoList = [
  {
    label: '技师姓名/昵称',
    field: 'username'
  },
  {
    label: '性别',
    field: 'gender',
    options: [{ value: '1', text: '男' }, { value: '2', text: '女' }]
  },
  {
    label: '技师等级',
    field: 'level'
  },
  {
    label: '手机号',
    field: 'mobile'
  },
  {
    label: '综合评分',
    field: 'jstotlfen'
  },
  {
    label: '评论数',
    field: 'pinglunnum'
  }
]

export default function Services() {
  const { $fetch, $utils } = useContext(context)
  const [total, setTotal] = useState(0)
  const [list, setList] = useState([])
  const [visible, setVisible] = useState(false)
  const [current, setCurrent] = useState({})
  const [searchInfo, setSearchInfo] = useState({})
  const [pageInfo, setPageInfo] = useState({
    current: 1,
    size: 15
  })

  const [infoList, setInfoList] = useState(defaultInfoList)
  const [headImg, setHeadImg] = useState('')

  const id = $utils.getQuery('userId')

  useEffect(() => {
    async function getDetail() {
      const res = await $fetch('bi/js/selectByJs', { id })
      const info = res || {}
      setHeadImg(info.headImg || '')
      setInfoList(
        infoList.map(item =>
          info[item.field] !== undefined
            ? {
                ...item,
                value: item.options
                  ? item.options.map(opt => {
                      if (opt.value == info[item.field]) return opt.text
                    })
                  : info[item.field]
              }
            : item
        )
      )
    }
    if (id) {
      getDetail()
    }
  }, [id])

  const toEdit = async (checked, record) => {
    // console.log(checked, record)
    const { id } = record

    setList(
      list.map(item =>
        item.id == id ? { ...item, switchLoading: true } : item
      )
    )
    await $fetch('bi/jEvaluate/update', { id: id, status: checked ? 1 : 2 })
    setList(
      list.map(item =>
        item.id == id
          ? { ...item, switchLoading: false, status: checked ? 1 : 2 }
          : item
      )
    )
  }

  const toDelete = record => {
    setCurrent(record)
    setVisible(true)
  }

  const columns = [
    {
      title: '头像',
      width: 60,
      dataIndex: 'wxHeadImg',
      render: record =>
        record ? <Avatar src={record} /> : <Avatar icon="user" />
    },
    {
      title: '用户',
      dataIndex: 'wxUserName'
    },
    {
      title: '评论时间',
      dataIndex: 'createTime'
    },
    {
      title: '评分',
      dataIndex: 'jsManyi',
      render: (num, record) => {
        const content = (
          <div>
            <span style={{display: 'block'}}>技师满意度：<Rate disabled defaultValue={record.jsManyi} /></span>
            <span style={{display: 'block'}}>沟通满意度：<Rate disabled defaultValue={record.gtDw} /></span>
            <span style={{display: 'block'}}>服务满意度：<Rate disabled defaultValue={record.serviceYx} /></span>
          </div>
        )
        return (
          <Popover content={content}>
            <span><Rate disabled defaultValue={num} /></span>
          </Popover>
        )
      }
    },
    {
      title: '图片',
      key: 'img',
      render: record => (
        <div>
          {[record.img1, record.img2, record.img3].map((url, ind) =>
            url ? (
              <img
                alt=""
                src={url}
                key={`${ind}`}
                style={{ width: '60px', marginRight: '10px' }}
              />
            ) : null
          )}
          {/* <img alt="" src={record.img1} style={{ width: '60px' }} />
          <img alt="" src={record.img2} style={{ width: '60px' }} />
          <img alt="" src={record.img3} style={{ width: '60px' }} /> */}
        </div>
      )
    },
    {
      title: '评论内容',
      dataIndex: 'remark'
    },
    {
      title: '操作',
      key: 'action',
      render: record => (
        <span>
          <Switch
            checkedChildren="显示"
            unCheckedChildren="隐藏"
            checked={record.status != 1 ? false : true}
            loading={record.switchLoading}
            onChange={checked => toEdit(checked, record)}
          />
          <Divider type="vertical" />
          <Button type="danger" onClick={() => toDelete(record)}>
            删除
          </Button>
        </span>
      )
    }
  ]

  const getList = async function() {
    const res = await $fetch('bi/jEvaluate/list', {
      userId: id,
      ...pageInfo,
      ...searchInfo
    })
    const { records = [], total: resTotal } = res
    setTotal(resTotal)
    setList(records)
  }

  const changePage = (current, size) => {
    setPageInfo({
      ...pageInfo,
      current,
      size
    })
  }

  useEffect(() => {
    getList()
  }, [pageInfo, searchInfo])

  const handleOk = async () => {
    setVisible(false)
    await $fetch('bi/jEvaluate/update', { id: current.id, status: 3 })
    message.success('删除成功', 2).then(() => {
      getList()
    })
  }

  const handleCancel = () => {
    setVisible(false)
  }

  const submit = values => {
    setPageInfo({
      ...pageInfo,
      current: 1
    })
    setSearchInfo(values)
  }
  // const updateValue = (changeItem, values = {}) => {
  //   // setSearchInfo(values)
  // }

  return (
    <Content style={{ padding: '40px', backgroundColor: '#fff' }}>
      <Descriptions title="技师信息">
        <Descriptions.Item label="头像">
          {headImg ? (
            <Avatar size={64} src={headImg} />
          ) : (
            <Avatar size={64} icon="user" />
          )}
        </Descriptions.Item>
        {infoList.map((item, index) => (
          <Descriptions.Item label={item.label} key={index + 1}>
            {item.value}
          </Descriptions.Item>
        ))}
      </Descriptions>

      <CommTable
        dataSource={list}
        columns={columns}
        pagination={{
          total,
          current: pageInfo.current,
          pageSize: pageInfo.size,
          onChange: changePage,
          showSizeChanger: true,
          onShowSizeChange: changePage
        }}
      ></CommTable>

      <Modal
        title="确认操作"
        visible={visible}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <p>{`确定删除“${current.wxUserName}”的这条评论么？`}</p>
      </Modal>
    </Content>
  )
}
