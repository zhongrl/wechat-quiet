import Taro from '@tarojs/taro'
import { View, Text, Button } from '@tarojs/components'
import './modal.less'

export default function Modal(props) {
  const {
    title = '温馨提示',
    content = [],
    buttonText = '确认',
    handleClick,
    cancleButtonText = '',
    cancleHandleClick
  } = props

  return (
    <View className="modal">
      <View className="modalBlock"></View>
      <View className="modalMain">
        <View className="modalTitle">
          <Text>{title}</Text>
        </View>

        {content.length > 0 ? (
          <View className="modalDesc">
            {content.map((des, i) => (
              <View className="modalDescRor" key={i}>
                <Text>{des}</Text>
              </View>
            ))}
          </View>
        ) : null}

        {cancleButtonText ? (
          <View className="modalButtons">
            <Button className="modalButtonCancleItem" onClick={() => cancleHandleClick()}>
              {cancleButtonText}
            </Button>
            <Button className="modalButtonItem" onClick={() => handleClick()}>
              {buttonText}
            </Button>
          </View>
        ) : (
          <View className="modalBottom">
            <Button className="modalButton" onClick={() => handleClick()}>
              {buttonText}
            </Button>
          </View>
        )}
      </View>
    </View>
  )
}
