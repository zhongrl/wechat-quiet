const apiHost = 'https://www.jingxiang2019.com/'

export { apiHost }

export default function(api, body = {}, method = 'POST') {
  let headers = {
    accessToken: localStorage.getItem('token') || ''
  }
  // if (body instanceof FormData) {
  //   // fetch uploade file can not set multipart/form-data
  //   // headers = { ...headers, 'Content-Type': 'multipart/form-data' }
  // } else {
  //   body = typeof body === 'object' ? JSON.stringify(body) : body
  //   headers = { ...headers, 'Content-Type': 'application/json' }
  // }
  if (!(body instanceof FormData)) {
    body = typeof body === 'object' ? JSON.stringify(body) : body
    headers = { ...headers, 'Content-Type': 'application/json' }
  }
  return new Promise((resolve, reject) => {
    fetch(`${apiHost}${api}`, {
      method,
      headers,
      body
    }).then(res => {
      if (res.ok) {
        resolve(res.json())
      } else {
        reject(res)
      }
    })
  })
}
