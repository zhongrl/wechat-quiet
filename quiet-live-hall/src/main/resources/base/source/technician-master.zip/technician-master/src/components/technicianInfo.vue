<template>
  <view class="technicianInfo">
    <image :src="info.headImg" class="technicianInfoImg" />
    <view class="technicianInfoDesc">
      <text class="technicianInfoName">{{info.username}}</text>
      <text class="technicianInfoLevel" v-if="info.jsLevel">{{info.jsLevel}}</text>
    </view>
  </View>
</template>

<script>
export default {
  props: {
    info: {
      type: Object,
      default: ()=> ({})
    }
  }
}
</script>

<style>
.technicianInfo {
  background: #FFFFFF;
  font-size: 28rpx;
  color: #4A4A4A;
  line-height: 40rpx;
  text-align: center;
  padding-top: 40rpx;
}

.technicianInfoImg {
  width: 140rpx;
  height: 140rpx;
  border-radius: 50%;
  background: gray;
}

.technicianInfoDesc {
  font-size: 24rpx;
  color: #A1A1A1;
  padding: 32rpx 0 50rpx 0;
}

.technicianInfoName {
  font-size: 36rpx;
  color: #030303;
  margin-right: 17rpx;
}
.technicianInfoLevel{
  font-size: 24rpx;
  color: #A1A1A1;
  margin-left: 17rpx;
}
</style>
