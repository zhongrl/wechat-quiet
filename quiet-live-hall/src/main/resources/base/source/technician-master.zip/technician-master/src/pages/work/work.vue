<template>
  <view class="workStatus">
    <view class="statusContent">
      <view
        v-for="(item, index) in statusList"
        :key="index"
        @click="changeTab(index)"
        :class="index === currIndex ? 'activeStatusItem' : 'statusItem'"
      >
        <text>{{item.text}}</text>
      </view>
    </view>
    <view class="statusText">
      <view>
        <text>员工须知</text>
      </view>
      <view>
        <text>接单中：每天上班请准时切换为接单中工作状态</text>
      </view>
      <view>
        <text>停止接单：如果订单饱和可选择定制接单</text>
      </view>
      <view>
        <text>休息中：下班、假期可选择此状态</text>
      </view>
    </view>
    <view class="buttonItem">
      <view class="submitButton" @click="logout">退出登陆</view>
    </view>
  </view>
</template>

<script>
import http from '@/utils/http'
export default {
  data() {
    return {
      currIndex: 0,
      statusList: [
        { text: '接单中', isChecked: true },
        { text: '停止接单', isChecked: false },
        { text: '休息中', isChecked: false }
      ]
    }
  },
  onLoad() {
    this.init()
  },
  methods: {
    // 缺少初始获取状态的接口
    async init() {
      const { jsStatus } = await http('js/findJsStatus')
      this.currIndex = jsStatus - 1
    },

    async changeStatus(i) {
      // jsStatus   1 可接单，2 停止接单，3 休息中
      const res = await http('js/updateJsUserStatus', {
        jsStatus: i + 1
      })
      this.currIndex = i
      uni.showToast({
        title: '修改成功',
        icon: 'none',
        duration: 2000
      })
    },

    async logout() {
      const res = await http('js/logOut')
      uni.removeStorageSync('token')
      uni.navigateTo({
        url: '/pages/login/login'
      })
    },

    changeTab(i) {
      this.changeStatus(i)
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
}

.statusContent {
  padding: 295rpx 55rpx 0 55rpx;
  display: flex;
  justify-content: space-between;
}

.statusItem {
  width: 200rpx;
  height: 200rpx;
  line-height: 200rpx;
  text-align: center;
  background: #ffffff;
  border-radius: 20rpx;
  font-size: 36rpx;
  color: #4a4a4a;
  letter-spacing: 0;
}

.activeStatusItem {
  width: 200rpx;
  height: 200rpx;
  line-height: 200rpx;
  text-align: center;
  background: #b09e85;
  border-radius: 20rpx;
  font-size: 36rpx;
  color: #ffffff;
  letter-spacing: 0;
}

.statusText {
  padding: 108rpx 55rpx 40rpx 55rpx;
  font-size: 20rpx;
  color: #4a4a4a;
}

.buttonItem {
  margin-top: 193rpx;
  display: flex;
  justify-content: center;
}

.submitButton {
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
  border-radius: 40rpx;
  border: none;
  font-size: 32rpx;
  text-align: center;
  background: #b09e85;
  color: #ffffff;
}
</style>
