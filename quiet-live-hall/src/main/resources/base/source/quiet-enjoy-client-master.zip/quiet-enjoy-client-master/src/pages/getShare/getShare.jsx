import Taro, { Component } from '@tarojs/taro'
import { View, Text, Image, Navigator } from '@tarojs/components'
import shareLogo from '@/assets/share_logo.png'
import email from '@/assets/email.png'
import http from '../../utils/http'
import './getShare.less'

export default class GetShare extends Component {
  config = {
    navigationBarTitleText: '',
  }

  constructor(props) {
    super(props)
    const { couponId = '', openId = '', unionid } = this.$router.params
    this.state = { couponId, openId, unionid }
  }

  componentWillMount() {
  }

  componentDidMount() {
    this.getCard()
  }

  componentWillUnmount() {}

  componentDidShow() {}

  // onShareAppMessage(options) {
  //   return {
  //     title: '为你的好友送上20元抵扣券'
  //   }
  // }

  async getCard(){
    const {couponId, openId, unionid} = this.state
    const { code } = await Taro.login()
    await http('custom/shareUserJCouponDetail', {
      isWxWp: 'minapp',
      giveOpenid: openId,
      couponId,
      unionid,
      code
    })
  }

  render() {
    return (
      <View className="sharePage">
        <View className="shareMain">
          <View className="shareLogoItem">
            <Image className="shareLogo" src={shareLogo}></Image>
          </View>
          <View className="shareEmailItem">
            <Image src={email} className="shareEmail"></Image>
          </View>
          <View className="shareText">
            <View className="shareTextRow">
              <Text>好友为你送上</Text>
              <Text class="shareTextBold">20元</Text>
              <Text>抵扣券</Text>
            </View>
            <View className="shareTextTip">
              <Text>首次消费后</Text>
            </View>
            <View className="shareTextRow">
              <Text>可直接抵扣</Text>
              <Text class="shareTextBold">20元</Text>
            </View>
          </View>
          <View className="shareButtonRow">
            <Navigator
              className="shareButton"
              url='/pages/index/index'
              openType="switchTab"
            >去使用</Navigator>
          </View>
          <View className="shareBottomText">
            <Text>邀请越多 奖励越多</Text>
          </View>
          <View className="shareCompText">
            <Text>静享生活体验馆</Text>
          </View>
        </View>
      </View>
    )
  }
}
