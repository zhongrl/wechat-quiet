<template>
  <view>
    <top-tab :tabIndex="tabIndex" :list="tabList" @changeTab="changeTab"></top-tab>
    <empty-list v-if="list.length === 0 && loadingStatus === 2"></empty-list>

    <view class="orderList">
      <view class="workItem" v-for="item in list" :key="item.id">
        <view :class="`workTitle${item.status}`">
          <text>{{item.lineUpNumber}}</text>
          <text>{{statusText[item.status]}}</text>
        </view>
        <view class="workTextItem">
          <view class="workText">
            <text>服务项目</text>
            <text class="workRightText">{{item.serviceName}}</text>
          </view>
          <view class="workText">
            <text class="spaceText">合计</text>
            <text class="workRightText">￥{{item.price}}</text>
          </view>
          <view class="workText">
            <text>取号时间</text>
            <text class="workRightText">{{item.createTime}}</text>
          </view>

          <view class="workButtons" v-if="item.status == 2 || item.status == 3">
            <button @click="handleButton(item, 9)" class="workButtonItem">线下结算</button>
            <button
              @click="handleButton(item, item.status)"
              :class="`workButtonItem${item.status}`"
            >{{item.status == 2 ? '催促结算' : '结算'}}</button>
          </view>

          <view class="workButtons" v-if="item.status == 4">
            <button @click="handleButton(item, 41)" class="workButtonCancle">取消排队</button>
            <!-- <button @click="handleButton(item, 42)" class="workButtonItem">一键呼叫</button> -->
            <a class="workButtonTel" :href="`tel:${item.custMobile}`">一键呼叫</a>
            <button @click="handleButton(item, 43)" class="workButtonItem">开始服务</button>
          </view>
        </view>
      </view>
    </view>
    <uni-popup ref="popup" type="center">
      <!-- <view class="popup-title">
        <text>请输入取消理由</text>
      </view>-->
      <view>
        <comm-form :formList="formList" @submit="submit"></comm-form>
      </view>
    </uni-popup>
    <!-- <uni-loadmore v-if="list.length >= size" :status="list.length < total ? 'loading' : 'noMore'"></uni-loadmore> -->
  </view>
</template>
<script>
// import { uniLoadMore } from '@dcloudio/uni-ui'
// import moment from 'moment'
import http from '@/utils/http'
import topTab from '@/components/topTab'
import emptyList from '@/components/emptyList'
import { uniPopup } from '@dcloudio/uni-ui'
import commForm from '@/components/commForm'

// const today = moment().format('YYYY-MM-DD')
export default {
  components: {
    // 'uni-loadmore': uniLoadMore,
    'top-tab': topTab,
    'empty-list': emptyList,
    'uni-popup': uniPopup,
    'comm-form': commForm
  },
  data() {
    return {
      tabIndex: 0,
      tabList: [{ text: '排队中' }, { text: '已完成' }],
      size: 15,
      current: 1,
      loadingStatus: 0, // 0 未开始，1请求中，2请求完成
      list: [],
      statusText: {
        '1': '已完成',
        '2': '待支付',
        '3': '服务中',
        '4': '排队中',
        '5': '取消'
      },
      formList: [
        {
          type: 'textarea',
          label: '取消理由',
          name: 'cancelRemark',
          rules: ['required']
        }
      ],
      currId: ''
      // tempInfo: {}
    }
  },
  onLoad() {
    this.getList()
  },
  // onReachBottom() {
  //   const { list, total, current } = this
  //   if (list.length < total) {
  //     this.getList(current + 1)
  //   }
  // },
  onPullDownRefresh() {
    this.getList()
  },
  methods: {
    async getList(page = 1) {
      const { loadingStatus, size, current, list, tabIndex, tabList } = this
      if (loadingStatus === 1) {
        return false
      }
      this.loadingStatus = 1
      uni.stopPullDownRefresh()

      const { orders, total } = await http('js/orderQueuing', {
        status: tabIndex === 0 ? 4 : 1,
        current: page,
        size
      })
      this.loadingStatus = 2
      this.current = page
      this.list = page > 1 ? [...list, ...orders] : [...orders]
      // this.total = total
    },
    changeTab(index) {
      const { tabIndex } = this
      if (tabIndex === index) {
        return false
      }
      this.current = 1
      this.tabIndex = index
      this.getList()
    },

    async handleButton(item, flg) {
      const num = Number(flg)
      if (num === 2) {
        // text = '催促结算'
        await http('js/cuiCuService', { id: item.id })
        this.showToast('已催促结算').then(() => {
          this.getList()
        })
      }
      if (num === 3) {
        // text = '结算'
        await http('js/updateOrderEndService', { id: item.id })
        this.showToast('订单结算成功').then(() => {
          this.getList()
        })
      }
      if (num === 9) {
        // text = '线下结算'
        await http('js/upPayOrderService', { id: item.id })
        this.showToast('线下结算成功').then(() => {
          this.getList()
        })
      }
      if (num === 41) {
        // 取消排队
        this.currId = item.id
        this.$refs.popup.open()
      }

      // if (num === 42) {
      //   // text = '一键呼叫'
      //   const { custMobile } = item
      //   // h5 呼叫电话可能会有问题，可能需要换成<a href="tel:400-0000-688">400-0000-688</a>
      //   uni.makePhoneCall({
      //     phoneNumber: custMobile
      //   })
      // }
      if (num === 43) {
        // text = '开始服务'
        await http('js/updateOrderService', { id: item.id })
        this.getList()
      }
    },
    async submit(values) {
      const { currId } = this
      await http('js/orderCancel', { id: currId, ...values })
      this.$refs.popup.close()
      this.showToast('取消成功').then(() => {
        this.getList()
      })
    },
    showToast(msg, duration = 2000) {
      return new Promise((resolve, reject) => {
        uni.showToast({
          title: msg,
          icon: 'none',
          duration: duration
        })
        setTimeout(() => {
          resolve()
        }, duration)
      })
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
}
.orderList {
  margin: 24rpx 10rpx 0 10rpx;
  height: 800rpx;
  background: #f9f9f9;
}

.workItem {
  background: #ffffff;
  border-radius: 8rpx;
  overflow: hidden;
  margin-bottom: 11rpx;
  padding-bottom: 27rpx;
}

.workTitle1 {
  display: flex;
  justify-content: space-between;
  padding: 10rpx 21rpx 10rpx 30rpx;
  line-height: 40rpx;
  font-size: 28rpx;
  color: #ffffff;
  background: #9b9b9b;
}

.workTitle2 {
  display: flex;
  justify-content: space-between;
  padding: 10rpx 21rpx 10rpx 30rpx;
  line-height: 40rpx;
  font-size: 28rpx;
  color: #ffffff;
  background: #b09e85;
}

.workTitle3 {
  display: flex;
  justify-content: space-between;
  padding: 10rpx 21rpx 10rpx 30rpx;
  line-height: 40rpx;
  font-size: 28rpx;
  color: #ffffff;
  background: #b09e85;
}

.workTitle4 {
  display: flex;
  justify-content: space-between;
  padding: 10rpx 21rpx 10rpx 30rpx;
  line-height: 40rpx;
  font-size: 28rpx;
  color: #ffffff;
  background: #02af65;
}

.workTitle5 {
  display: flex;
  justify-content: space-between;
  padding: 10rpx 21rpx 10rpx 30rpx;
  line-height: 40rpx;
  font-size: 28rpx;
  color: #ffffff;
  background: #d1d1d1;
}

.workTextItem {
  padding: 20rpx 20rpx 30rpx 20rpx;
  font-size: 28rpx;
  color: #9b9b9b;
}

.workRightText {
  color: #000000;
}

.workText {
  display: flex;
  justify-content: space-between;
  line-height: 40rpx;
  margin-bottom: 8rpx;
}

.workButtons {
  display: flex;
  justify-content: flex-end;
  padding-right: 20rpx;
}

.workButtonItem {
  width: 200rpx;
  height: 64rpx;
  line-height: 64rpx;
  font-size: 28rpx;
  color: #ffffff;
  border: none;
  background: #b09e85;
  margin: 0 0 0 45rpx;
  border-radius: 33px;
}
.workButtonItem2 {
  width: 200rpx;
  height: 64rpx;
  line-height: 64rpx;
  font-size: 28rpx;
  color: #ffffff;
  border: none;
  background: #b09e85;
  margin: 0 0 0 45rpx;
  border-radius: 33px;
}
.workButtonItem3 {
  width: 200rpx;
  height: 64rpx;
  line-height: 64rpx;
  font-size: 28rpx;
  color: #ffffff;
  border: none;
  background: #b09e85;
  margin: 0 0 0 45rpx;
  border-radius: 33px;
}
.workButtonTel {
  width: 200rpx;
  height: 64rpx;
  line-height: 64rpx;
  font-size: 28rpx;
  color: #ffffff;
  border: none;
  background: #b09e85;
  margin: 0 0 0 45rpx;
  text-align: center;
  border-radius: 33px;
  text-decoration: none;
}

.workButtonCancle {
  width: 200rpx;
  height: 64rpx;
  line-height: 64rpx;
  font-size: 28rpx;
  color: #ffffff;
  border: none;
  border: 2rpx solid #b09e85;
  color: #b09e85;
  background: #fff;
  margin: 0 0 0 45rpx;
  border-radius: 33px;
}

.spaceText {
  letter-spacing: 2em;
}
.popup-title {
  font-size: 28rpx;
  color: #000000;
  padding: 10rpx 0 30rpx 0;
}
</style>
