import Taro, { useEffect, useState } from '@tarojs/taro'
import {
  Swiper,
  SwiperItem,
  Image,
  WebView,
  Navigator
} from '@tarojs/components'
import http from '../../utils/http'
import './banner.less'
// import { getMaxListeners } from 'cluster'

export default function Banner() {
  const [list, setList] = useState([])

  useEffect(() => {
    async function getList() {
      const res = await http('custom/findXcxBanner', {
        current: 1,
        size: 10
      })
      const { records } = res
      setList(records)
    }
    getList()
  }, [])

  return (
    <Swiper indicatorDots autoplay className="bannerWrap">
      {list.map(item => (
        <SwiperItem key={item.id}>
          {/* <Navigator url={`/pages/outer/outer?url=${item.url}`}>
            <Image src={item.imgUrl} className="bannerImg" />
          </Navigator> */}
          <Navigator url={`/pages/share/share?id=${item.id}`}>
            <Image src={item.imgUrl} className="bannerImg" />
          </Navigator>
        </SwiperItem>
      ))}
    </Swiper>
  )
}
