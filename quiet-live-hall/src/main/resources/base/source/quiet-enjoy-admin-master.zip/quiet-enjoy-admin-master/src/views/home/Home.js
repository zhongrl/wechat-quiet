import React from 'react'
import { Layout } from 'antd'

const { Content } = Layout

export default function Login(props) {
  return ( 
    <Content style={{ textAlign: 'center', height: '100%', padding: '100px 0', backgroundColor: '#fff' }}>
      <h1>欢迎来到静享生活馆后台管理系统</h1>
    </Content>
  )
}
