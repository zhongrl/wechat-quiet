<template>
  <view class="editCommentPage">
    <view class="editCommentMain">
      <technicianInfo
        :info="{headImg: info.jsHeadImg, username: info.jsUsername, jsLevel: info.jsLevel}"
      ></technicianInfo>
      <view class="editCommentItem">
        <text class="editCommentLable">技师技术是否满意</text>
        <view class="editCommentStar">
          <star @handleClick="changeStar" :id="1" :num="fetchData.jsManyi || 0"></star>
        </view>
      </view>
      <view class="editCommentItem">
        <text class="editCommentLable">服务是否用心</text>
        <view class="editCommentStar">
          <star @handleClick="changeStar" :id="2" :num="fetchData.serviceYx || 0"></star>
        </view>
      </view>
      <view class="editCommentItem">
        <text class="editCommentLable">沟通是否到位</text>
        <view class="editCommentStar">
          <star @handleClick="changeStar" :id="3" :num="fetchData.gtDw || 0"></star>
        </view>
      </view>
      <view class="editCommentDesc">
        <view class="editCommentDescText">
          <textarea
            class="editCommentTextarea"
            v-model="fetchData.remark"
            placeholder="越表扬越优秀！不要吝啬你的赞美呀！"
          ></textarea>
        </view>
        <view class="editCommentImgs">
          <view class="editCommentImgsItem" v-for="url in imgList" :key="url">
            <image @click="showImg(url)" class="showImgItem" :src="url" />
          </view>

          <view class="editCommentImgsItem" @click="chooseImg" v-if="imgList.length < 3">
            <view class="editCommentUpload">
              <image class="editCamera" :src="camera" />
            </view>
            <view>
              <text>添加照片</text>
            </view>
          </view>
        </view>
      </view>
      <view class="editCommentBottom">
        <view class="editCommentButton" @click="submit">提交</view>
      </view>
    </view>
    <modal
      v-if="showModal"
      title="温馨提示"
      :content="['写点啥呗！']"
      buttonText="确认"
      @handleClick="showModal = false"
    ></modal>

    <modal
      v-if="isShowSucc"
      title="评价成功"
      :content="['哇哦！', '你的评价是我们继续努力的动力！']"
      buttonText="知道了"
      @handleClick="handleSucc"
    ></modal>
  </view>
</template>

<script>
import http, { upload } from '@/utils/http'
// import succ from '@/assets/succ.png'
import camera from '@/assets/camera.png'
import technicianInfo from '@/components/technicianInfo'
import modal from '@/components/modal'
import star from '@/components/editStar'

export default {
  components: {
    technicianInfo,
    star,
    modal
  },
  data() {
    return {
      isShowSucc: false,
      showModal: false,
      token: '',
      imgList: [],
      info: {},
      fetchData: {
        remark: ''
      },
      camera
    }
  },
  onLoad(option) {
    const { token } = option
    this.token = token
    this.init()
  },
  // onBackPress(){
  //   return true
  // },
  methods: {
    // 缺少初始获取状态的接口

    async init() {
      const { token } = this
      const payInfo = uni.getStorageSync('payInfo')
      const info = payInfo ? JSON.parse(payInfo) : {}
      // const info = await http('order/selectNotPayJOrder', {}, { token })
      this.info = info
      this.fetchData = {
        userId: info.jsUserId,
        orderId: info.id,
        jsManyi: 0,
        serviceYx: 0,
        gtDw: 0,
        remark: ''
      }
    },

    async submit() {
      const { fetchData, imgList, token } = this
      if (!fetchData.remark) {
        this.showModal = true
        return false
      }

      const imgInfo = imgList.reduce((pre, curr, index) => {
        pre[`img${index + 1}`] = curr
        return pre
      }, {})
      const info = await http(
        'custom/jEvaluate/save',
        {
          ...fetchData,
          ...imgInfo
        },
        { token }
      )
      this.isShowSucc = true
    },

    chooseImg() {
      const { token } = this
      uni.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album'],
        success: async res => {
          const tempFilePath = res.tempFilePaths[0]
          const img = await upload('file/fileUpload', tempFilePath, { token })
          const { imgList } = this
          this.imgList = [...imgList, img]
        },
        fail: e => {
          uni.showToast({
            title: 'msg',
            icon: 'none',
            duration: 2000
          })
        }
      })
    },
    changeInput(e) {
      const { fetchData } = this
      this.fetchData = {
        ...fetchData,
        remark: e.detail.value
      }
    },

    changeStar(arr) {
      const { fetchData } = this
      const [n, type] = arr
      let temp = {}
      if (type === 1) {
        this.fetchData.jsManyi = n
      }
      if (type === 2) {
        this.fetchData.serviceYx = n
      }
      if (type === 3) {
        this.fetchData.gtDw = n
      }
    },

    showImg(url) {
      const { imgList } = this
      uni.previewImage({
        current: url,
        urls: imgList
      })
    },

    // 评论成功
    handleSucc() {
      const { token } = this
      this.isShowSucc = true
      // uni.navigateTo 会导致share路由分享功能无效，所以使用window.location.href刷新病跳转
      window.location.href = `${location.origin}/technician/pages/share/share?token=${token}`
      // uni.navigateTo({
      //   url: `/pages/share/share?token=${token}`
      // })
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
}
.editCommentPage {
  padding-bottom: 20px;
}

.editCommentItem {
  background: #ffffff;
  border-radius: 8rpx;
  margin: 10rpx 10rpx 0 10rpx;
  font-size: 28rpx;
  color: #030303;
  display: flex;
  justify-content: space-between;
  padding: 25rpx 40rpx 25rpx 30rpx;
  align-items: center;
}

.editCommentTextarea {
  font-size: 28rpx;
  line-height: 40rpx;
}

.editCommentDesc {
  background: #ffffff;
  border-radius: 8rpx;
  margin: 10rpx;
  padding: 20rpx;
}

.editCommentImgs {
  display: flex;
  text-align: center;
  padding: 20rpx;
}

.editCommentImgsItem {
  width: 131rpx;
  height: 131rpx;
  background: #f9f9f9;
  border-radius: 8rpx;
  font-size: 20rpx;
  color: #9b9b9b;
  line-height: 28rpx;
  margin-right: 20rpx;
}
.showImgItem {
  width: 131rpx;
  height: 131rpx;
}

.editCamera {
  width: 58rpx;
  height: 44rpx;
}

.editCommentUpload {
  padding: 20rpx 0 10rpx 0;
}

.editCommentBottom {
  margin: 37rpx 0 10rpx 0;
  display: flex;
  justify-content: center;
  text-align: center;
}

.editCommentButton {
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
  background: #b09e85;
  border-radius: 40rpx;
  font-size: 32rpx;
  color: #ffffff;
}
</style>
