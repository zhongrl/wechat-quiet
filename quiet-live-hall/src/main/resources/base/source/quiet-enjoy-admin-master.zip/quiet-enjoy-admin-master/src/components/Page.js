import React, { useState } from 'react'
import { Layout } from 'antd'
import SlideMenu from '@components/SlideMenu'
import MainHeader from '@components/MainHeader'
import MainRouter from '@components/MainRouter'

const { Content, Footer } = Layout

export default function Page(props) {
  const [collapsed, setCollapsed] = useState(true)
  return (
    <Layout style={{ minWidth: '1200px',minHeight: '100vh' }}>
      <SlideMenu collapsed={collapsed}></SlideMenu>
      <Layout>
        <MainHeader
          collapsed={collapsed}
          setCollapsed={setCollapsed}
        ></MainHeader>
        <Content>
          <MainRouter></MainRouter>
        </Content>
        <Footer style={{
        background: '#fff',
        padding: '10px 0',
        textAlign: 'center',
        marginTop: '10px'
      }}>
        <p style={{margin: 0}}>静享生活馆后台管理系统 V1.0</p>
        <p style={{margin: 0}}>深圳市益享服务科技有限公司</p>
        </Footer>
      </Layout>
    </Layout>
  )
}
