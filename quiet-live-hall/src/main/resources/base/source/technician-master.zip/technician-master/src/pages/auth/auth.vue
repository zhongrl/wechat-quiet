<template>
  <view class="auth"></view>
</template>

<script>
import http from '@/utils/http'
import shareLogo from '@/assets/share_logo.png'
import email from '@/assets/email.png'

const homeUrl = 'https://www.jingxiang2019.com/technician/pages/login/login'

export default {
  data() {
    return {}
  },
  onLoad(option) {
    const { code, redirect_uri = homeUrl } = option
    const authorize = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx0a45b143e43cfb37'
    location.href = `${authorize}&redirect_uri=${encodeURIComponent(redirect_uri)}&response_type=code&scope=snsapi_userinfo&state=0#wechat_redirect`
  }
}
</script>

<style>
page {
  background: #f9f9f9;
}
.auth {
  display: none;
}
</style>
