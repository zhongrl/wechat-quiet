import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components'
import TabTitle from '@/components/tabTitle/tabTitle'
import OrderList from '@/components/orderList/orderList'
import EmptyList from '@/components/emptyList/emptyList'
import http from '../../utils/http'
import './order.less'

export default class Mine extends Component {
  config = {
    navigationBarTitleText: '订单',
    enablePullDownRefresh: true //全局
  }

  constructor() {
    this.state = {
      // status: 4,  // 1 已支付，2待支付，3，服务中，4 排队中，5取消
      tabList: [
        { text: '排队中', isChecked: true, value: 4 },
        { text: '服务中', isChecked: false, value: 3 },
        { text: '已完成', isChecked: false, value: 1 }
      ],
      current: 1,
      size: 20,
      total: 0,
      list: [],
      isInit: false,
      isFetch: false
    }
    // this.changeTab = this.changeTab.bind(this)
  }

  componentDidShow(){
    this.getList()
  }

  // componentDidMount() {
    
  // }

  getList(page = 1) {
    this.setState(
      {
        isFetch: true
      },
      async () => {
        const { size, list, tabList } = this.state
        const currTab = tabList.find(({ isChecked }) => isChecked)
        const { records, total } = await http('custom/list', {
          current: page,
          size,
          // storeId: id,
          status: (currTab && currTab.value) || 4
        })
        Taro.stopPullDownRefresh()
        this.setState({
          current: page,
          total,
          isInit: true,
          isFetch: false,
          list: page > 1 ? [...list, ...records] : records
        })
      }
    )
  }

  onPullDownRefresh() {
    this.getList()
  }

  onReachBottom() {
    const { current, total, list, isFetch } = this.state
    if (list.length < total && !isFetch) {
      this.getList(current + 1)
    }
  }

  changeTab(i) {
    const { tabList } = this.state
    this.setState(
      {
        tabList: tabList.map((item, index) => ({
          ...item,
          isChecked: index === i
        }))
      },
      () => {
        this.getList()
      }
    )
  }

  render() {
    const tabIndex = this.state.tabList.findIndex(({ isChecked }) => isChecked)
    return (
      <View className="orderPage">
        <TabTitle
          list={this.state.tabList || []}
          changeTab={i => this.changeTab(i)}
        ></TabTitle>
        <OrderList tabIndex={tabIndex > -1 ? tabIndex : 4} list={this.state.list} getList={()=> this.getList()}></OrderList>
        {this.state.isInit && this.state.list.length === 0 ? (
          <EmptyList></EmptyList>
        ) : null}
      </View>
    )
  }

  // enablePullDownRefresh
}
