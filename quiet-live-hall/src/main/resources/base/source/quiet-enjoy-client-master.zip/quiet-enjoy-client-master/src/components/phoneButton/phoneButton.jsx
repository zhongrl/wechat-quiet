import Taro, {useState, useEffect} from '@tarojs/taro'
import { Button } from '@tarojs/components'
import './phoneButton.less'

export default function PhoneButton(props) {
  const { callback } = props
  const [code, setCode] = useState('')

  useEffect(()=> {
    const init = async ()=> {
      const {code: resCode} = await Taro.login()
      setCode(resCode)
    }
    init()
  }, [])

  const getPhoneNumber = async info => {
    const { detail = {} } = info
    const { encryptedData } = detail
    if (typeof encryptedData !== 'undefined') {
      callback({
        code,
        ...detail
      })
    }
  }

  return (
    <Button
      class="phoneButton"
      openType="getPhoneNumber"
      onGetPhoneNumber={getPhoneNumber}
    >
      取号
    </Button>
  )
}
