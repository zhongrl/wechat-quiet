import Taro from '@tarojs/taro'

const apiHost = 'https://www.jingxiang2019.com/'

export default function(api, body = {}, isShowError = true) {
  return new Promise((resolve, reject) => {
    Taro.showLoading({
      mask: true
    })
    Taro.request({
      method: 'POST',
      url: `${apiHost}${api}`,
      data: body,
      header: {
        'content-type': 'application/json',
        accessToken: Taro.getStorageSync('token') || ''
      }
    })
      .then(res => {
        Taro.hideLoading()
        const { code, msg, data } = res.data
        if (code === '00000000') {
          resolve(data)
        } else if (code === '00000002') {
          Taro.navigateTo({
            url: '/pages/login/login'
          })
          reject(msg, code)
        } else {
          if (isShowError) {
            Taro.showToast({
              title: msg || '系统异常，请稍后重试！',
              icon: 'none',
              duration: 2000
            })
          }
          reject(msg, code)
        }
      })
      .catch(reson => {
        Taro.hideLoading()
        Taro.showToast({
          title: typeof reson === 'string' ? reson : '接口请求出错',
          icon: 'none',
          duration: 2000
        })
        reject(reson)
      })
  })
}

export function upload(api, filep, isShowError = true) {
  return new Promise((resolve, reject) => {
    Taro.showLoading({
      mask: true
    })
    Taro.uploadFile({
      url: `${apiHost}${api}`,
      filePath: filep, 
      name: 'file',
    })
      .then(res => {
        Taro.hideLoading()
        const { code, msg, data } = typeof res.data === 'string' ? JSON.parse(res.data) : res.data 
        if (code === '00000000') {
          resolve(data)
        } else if (code === '00000002') {
          Taro.navigateTo({
            url: '/pages/login/login'
          })
          reject(msg, code)
        } else {
          if (isShowError) {
            Taro.showToast({
              title: msg || '系统异常，请稍后重试！',
              icon: 'none',
              duration: 2000
            })
          }
          reject(msg, code)
        }
      })
      .catch(reson => {
        Taro.hideLoading()
        Taro.showToast({
          title: typeof reson === 'string' ? reson : '接口请求出错',
          icon: 'none',
          duration: 2000
        })
        reject(reson)
      })
  })
}
