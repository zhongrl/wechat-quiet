const apiHost = 'https://www.jingxiang2019.com/'

export default function(api, body = {}, conf = {}) {
  return new Promise((resolve, reject) => {
    uni.showLoading({
      mask: true
    })
    const { token = '' } = conf
    const storageToken = uni.getStorageSync('token') || ''
    uni.request({
      method: 'POST',
      url: `${apiHost}${api}`,
      data: body,
      header: {
        'content-type': 'application/json',
        accessToken: token || storageToken
      },
      success: res => {
        uni.hideLoading()
        const { code, msg, data } = res.data
        if (code === '00000000') {
          resolve(data)
        } else if (code === '00000002') {
          uni.removeStorageSync('token')
          uni.navigateTo({
            url: '/pages/login/login'
          })
          reject(msg, code)
        } else {
          uni.showToast({
            title: msg,
            icon: 'none',
            duration: 2000
          })
          reject(msg, code)
        }
      },
      fail: reson => {
        uni.hideLoading()
        uni.showToast({
          title: typeof reson === 'string' ? reson : '接口请求出错',
          icon: 'none',
          duration: 2000
        })
        reject(reson)
      }
    })
  })
}

export function upload(api, filep, isShowError = true) {
  return new Promise((resolve, reject) => {
    uni.showLoading({
      mask: true
    })
    uni
      .uploadFile({
        url: `${apiHost}${api}`,
        filePath: filep,
        name: 'file'
      })
      .then(res => {
        uni.hideLoading()
        let result = []
        if (Array.isArray(res)) {
          result = res[1] || {}
          result = result.data
        }
        const { code, msg, data } =
          typeof result === 'string' ? JSON.parse(result) : result
        if (code === '00000000') {
          resolve(data)
        } else if (code === '00000002') {
          uni.navigateTo({
            url: '/pages/login/login'
          })
          reject(msg, code)
        } else {
          if (isShowError) {
            uni.showToast({
              title: msg || '系统异常，请稍后重试！',
              icon: 'none',
              duration: 2000
            })
          }
          reject(msg, code)
        }
      })
      .catch(reson => {
        uni.hideLoading()
        uni.showToast({
          title: typeof reson === 'string' ? reson : '接口请求出错',
          icon: 'none',
          duration: 2000
        })
        reject(reson)
      })
  })
}
