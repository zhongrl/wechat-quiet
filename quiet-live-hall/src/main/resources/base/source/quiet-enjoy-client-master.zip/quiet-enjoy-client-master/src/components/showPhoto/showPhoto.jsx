import Taro, { useState } from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import './showPhoto.less'

export default function ShowPhoto(props) {
  // const [bigIndex, setBigIndex] = useState(0)
  // const [showBig, setShowBig] = useState(false)
  const { list = [] } = props
  const toShow = index => {
    // setBigIndex(index)
    // setShowBig(true)

    Taro.previewImage({
      current: list[index],
      urls: list
    })
  }

  return (
    <View>
      <View className="showPhoto">
        {list.map((item, index) =>
          item ? (
            <Image
              onClick={() => toShow(index)}
              key={`${index}`}
              className="showPhotoItem"
              src={item}
            ></Image>
          ) : null
        )}
      </View>
      {/* {showBig ? (
        <View className="bigPhoto">
          <View
            className="bigPhotoBlock"
            onClick={() => setShowBig(false)}
          ></View>
          <View className="bigPhotoContent">
            <Image
              mode="widthFix"
              className="bigPhotoItem"
              src={list[bigIndex]}
            />
          </View>
        </View>
      ) : null} */}
    </View>
  )
}
