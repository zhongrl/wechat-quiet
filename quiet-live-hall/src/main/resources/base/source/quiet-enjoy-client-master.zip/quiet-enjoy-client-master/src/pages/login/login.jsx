import Taro, { Component } from '@tarojs/taro'
// import { View, Button } from '@tarojs/components'
import http from '@/utils/http'
import Auth from '@/components/auth/auth'
import './login.less'


export default class Login extends Component {
  config = {
    navigationBarTitleText: '授权',
  }
  constructor(props) {
    super(props)
    const { couponId = '', openId = '', unionid = '', form = '' } = this.$router.params
    this.state = { 
      couponId, 
      openId,
      form,
      unionid,
      // code: '',
      showAuth: false
    }
  }
  componentDidMount() {
    this.getCode()
  }

  saveTokenInfo(info) {
    const {couponId, openId, unionid, form} = this.state
    const { mobile, token } = info
    Taro.setStorageSync('token', token)
    Taro.setStorageSync('mobile', mobile)
    if(couponId){
      Taro.navigateTo({
        url: `/pages/getShare/getShare?couponId=${couponId}&openId=${openId}&unionid=${unionid}`
      })
    }else if(form === 'share'){
      Taro.navigateTo({
        url: `/pages/share/share`
      })
    } else if(form === 'pay'){
      Taro.navigateTo({
        url: `/pages/paySucc/paySucc`
      })
    } else if(form === 'comment'){
      Taro.navigateTo({
        url: `/pages/editComment/editComment`
      })
    } else {
      Taro.switchTab({
        url: '/pages/index/index'
      })
    }
  }

  async authLogin(info){
    const { userInfo, ...other } = info
    // const {code} = this.state
    const { code } = await Taro.login()
    const loginInfo = await http('custom/login', {
      ...userInfo,
      ...other,
      code
    })
    this.saveTokenInfo(loginInfo)
    this.setState({
      showAuth: false
    })
  }

  async getCode(){
    const { code } = await Taro.login()
    try {
      const info = await http('custom/login', { code }, false)
      this.saveTokenInfo(info)
    } catch (e) {
      this.setState({
        showAuth: true
      })
    }
  }

  render() {
    return this.state.showAuth ? <Auth callback={(info)=> this.authLogin(info)}></Auth> : null
  }
}
