import Taro, { Component } from '@tarojs/taro'
import { View, Text, Button } from '@tarojs/components'
import './cancleTake.less'
import http from '../../utils/http'

export default class CancleTake extends Component {
  config = {
    navigationBarTitleText: '取消排队'
  }

  constructor() {
    const { orderId } = this.$router.params
    this.state = {
      checkedIndex: -1,
      orderId,
      list: [
        '等待时间太久',
        '技师调店',
        '重新排队',
        '到店找不到技师',
        '服务态度不好',
        '选错人',
        '想换一个技师',
        '找不到门店',
        '价格贵',
        '计划有变',
        '其他'
      ]
    }
  }

  checkedItem(index) {
    this.setState({
      checkedIndex: index
    })
  }

  async submit() {
    const { checkedIndex, list, orderId } = this.state
    await http('custom/orderCancel', {
      cancelRemark: list[checkedIndex],
      // id: orderId
    })
    Taro.showToast({
      title: '取消成功',
      icon: 'none',
      duration: 2000
    })
    setTimeout(() => {
      Taro.switchTab({
        url: '/pages/index/index'
      })
    }, 2000)
  }

  render() {
    return (
      <View className="cancleTakePage">
        <View className="cancleTakeMain">
          <View className="cancleTakeLable">
            <Text>取消原因</Text>
          </View>
          <View className="cancleTakeDesc">
            <Text>请选择取消原因，我们会帮您持续优化产品体验和服务体验。</Text>
          </View>
          <View className="cancleTakeList">
            {this.state.list.map((item, index) => (
              <Text
                class={
                  this.state.checkedIndex === index
                    ? 'cancleTakeSure'
                    : 'cancleTakeItem'
                }
                key={`${index}`}
                onClick={() => this.checkedItem(index)}
              >
                {item}
              </Text>
            ))}
          </View>
          <View className="cancleTakeBottom">
            {this.state.checkedIndex === -1 ? (
              <Button className="cancleTakeDisable">确定</Button>
            ) : (
              <Button
                className="cancleTakeButton"
                onClick={() => this.submit()}
              >
                确定
              </Button>
            )}
          </View>
        </View>
      </View>
    )
  }
}
