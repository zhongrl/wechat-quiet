import Taro, {Component} from '@tarojs/taro'
import { View, Text, Image, Button } from '@tarojs/components'
import succ from '@/assets/succ.png'
import './paySucc.less'

export default class PaySucc extends Component {
  config = {
    navigationBarTitleText: '支付成功',
    // enablePullDownRefresh: true //全局
  }

  handleClick(){
    Taro.navigateTo({
      url: '/pages/editComment/editComment'
    })
  }


  render() {
    return (
    <View className="paySuccPage">
      <View className="paySuccMain">
        <View className="paySuccCenter">
          <View className="paySuccCenterImg">
            <Image className="paySuccImg" src={succ}></Image>
          </View>
          <View className="paySuccCenterText">
            <Text>支付成功</Text>
          </View>
        </View>
        <View className="payDiscount">
          <Text>本单节省10元</Text>
        </View>
        <View className="paySuccBottom">
          <View className="paySuccBottomText">
            <Text>告诉技师，你对ta的服务印象吧！</Text>
          </View>
          <View className="paySuccBottomButton">
            <Button onClick={() => this.handleClick()} className="paySuccButton">
              去评价
            </Button>
          </View>
        </View>
      </View>
    </View>
  )
  }
}
