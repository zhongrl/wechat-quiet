import React, { useContext, useEffect, useState } from 'react'
import CommTable from '@components/commTable/CommTable'
import { context } from '@components/Provider'
import { Button, Col, Row, Modal, message, Divider, Layout } from 'antd'
import { Link } from 'react-router-dom'
import CommForm from '@components/commForm/CommForm'

const { Content } = Layout

const formList = [
  {
    type: 'input',
    label: '优惠券ID',
    field: 'couponId'
  },
  {
    type: 'select',
    label: '状态',
    field: 'delFlag',
    options: [
      { value: '1', text: '已使用' },
      { value: '2', text: '待使用' },
      { value: '3', text: '已过期' }
    ]
  },
  {
    type: 'date',
    label: '结束时间',
    field: 'endTime'
  }
]

export default function Services() {
  const { $fetch, history, $utils } = useContext(context)
  const [total, setTotal] = useState(0)
  const [list, setList] = useState([])
  const [visible, setVisible] = useState(false)
  const [current, setCurrent] = useState({})
  const [searchInfo, setSearchInfo] = useState({})
  const [pageInfo, setPageInfo] = useState({
    current: 1,
    size: 15
  })

  const toEdit = record => {
    const { id } = record
    history.push({
      pathname: '/page/editCard',
      search: $utils.setQuery({ id }, true)
    })
  }

  const toDelete = record => {
    setCurrent(record)
    setVisible(true)
  }

  const columns = [
    {
      title: '优惠券ID',
      dataIndex: 'couponId'
    },
    {
      title: '创建时间',
      dataIndex: 'createTime'
    },
    {
      title: '状态',
      dataIndex: 'delFlag',
      render: record => {
        return [
          { value: '1', text: '已使用' },
          { value: '2', text: '待使用' },
          { value: '3', text: '已过期' }
        ].map(item => {if(item.value == record) return item.text})
      }
    },
    {
      title: '结束时间',
      dataIndex: 'endTime'
    },
    {
      title: '邀请人名字',
      dataIndex: 'giveUsername'
    },
    {
      title: '使用者名字',
      dataIndex: 'syUsername'
    },
    // {
    //   title: '技师名字',
    //   dataIndex: 'jcUsername'
    // },
    {
      title: '优惠券描述',
      dataIndex: 'remake'
    }
    // {
    //   title: '操作',
    //   key: 'action',
    //   render: record => (
    //     <span>
    //       <Button type="primary" onClick={() => toEdit(record)}>
    //         编辑
    //       </Button>
    //       <Divider type="vertical" />
    //       <Button type="danger" onClick={() => toDelete(record)}>
    //         删除
    //       </Button>
    //     </span>
    //   )
    // }
  ]

  const getList = async function() {
    const res = await $fetch('bi/jCouponDetail/list', { ...pageInfo, ...searchInfo })
    const { records = [], total: resTotal } = res
    setTotal(resTotal)
    setList(records)
  }

  const changePage = (current, size) => {
    setPageInfo({
      ...pageInfo,
      current,
      size
    })
  }

  useEffect(() => {
    getList()
  }, [pageInfo, searchInfo])

  const handleOk = async () => {
    setVisible(false)
    await $fetch('bi/jCoupon/delete', { ...current })
    message.success('删除成功', 2).then(() => {
      getList()
    })
  }

  const handleCancel = () => {
    setVisible(false)
  }

  const submit = values => {
    setPageInfo({
      ...pageInfo,
      current: 1
    })
    setSearchInfo(values)
  }
  // const updateValue = (changeItem, values = {}) => {
  //   // setSearchInfo(values)
  // }

  return (
    <Content style={{ padding: '40px', backgroundColor: '#fff' }}>
      <CommForm
        // updateValue={updateValue}
        list={formList}
        submit={submit}
      ></CommForm>

      <Row style={{ marginBottom: '20px', marginTop: '20px' }}>
        {/* <Col span={2} offset={2}>
          <Link to="/page/editCard">
            <Button type="primary">新增</Button>
          </Link>
        </Col> */}
      </Row>
      <CommTable
        dataSource={list}
        columns={columns}
        pagination={{
          total,
          current: pageInfo.current,
          pageSize: pageInfo.size,
          onChange: changePage,
          showSizeChanger: true,
          onShowSizeChange: changePage
        }}
      ></CommTable>

      <Modal
        title="确认操作"
        visible={visible}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <p>{`确定删除“${current.couponId}”么？`}</p>
      </Modal>
    </Content>
  )
}
