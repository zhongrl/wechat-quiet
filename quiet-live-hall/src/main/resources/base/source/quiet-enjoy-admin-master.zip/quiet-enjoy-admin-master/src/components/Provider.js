import React, { useReducer, createContext } from 'react'
import { createHashHistory } from 'history'
import { message } from 'antd'
import http, { apiHost } from '@utils/http'

const history = createHashHistory()

// 初始state
const initialState = {
  token: '',
  isLoading: false
}

const context = createContext()

// 默认错误提示语
const defaultMsg = '网络异常，请稍后重试'

const reducer = (state, action) => {
  switch (action.type) {
    case 'setToken':
      return { ...state, token: action.token }
    case 'setLoading':
      return { ...state, isLoading: action.isLoading }
    default:
      return state
  }
}

function Provider(props) {
  document.title = '静享生活馆后台管理系统 V1.0'
  const [state, origin_dispatch] = useReducer(reducer, initialState)
  const dispatch = action => {
    if (typeof action === 'function') {
      return action(origin_dispatch)
    }
    return origin_dispatch(action)
  }

  const $fetch = (api, body, method) => {
    return new Promise((resolve, reject) => {
      origin_dispatch({
        type: 'setLoading',
        isLoading: true
      })
      http(api, body, method)
        .then(res => {
          const { code, data, msg = defaultMsg } = res
          origin_dispatch({
            type: 'setLoading',
            isLoading: false
          })
          if (code === '00000000') {
            resolve(data)
          } else if (code === '00000002') {
            localStorage.removeItem('token')
            history.push('/login')
            reject(res)
          } else {
            message.error(msg)
            reject(res)
          }
        })
        .catch(reson => {
          let msg = ''
          origin_dispatch({
            type: 'setLoading',
            isLoading: false
          })
          if (reson instanceof Error) {
            msg = typeof reson.message === 'string' ? reson.message : defaultMsg
          }
          msg = typeof reson === 'string' ? reson : msg
          message.error(msg)
          reject(reson)
        })
    })
  }

  const $utils = {
    /**
     *
     * @param {Boject|String} data 需转换的数据
     * @param {Boolean} flg 是否加？
     */
    setQuery(data, flg = false) {
      if (typeof data === 'object') {
        return Object.keys(data).reduce(
          (pre, curr) => {
            const temp = `${curr}=${data[curr]}`
            return pre.includes('=') ? `${pre}&${temp}` : temp
          },
          flg ? '?' : ''
        )
      }
      if (typeof data === 'string') {
        return data
      }
      return ''
    },
    getQuery(name) {
      const href = window.location.href
      let searchArr = href.match(/\w+=\w*/g)
      let result = {}
      if (searchArr) {
        result = searchArr.reduce((pre, curr) => {
          const currArr = curr.split('=')
          pre[currArr[0]] = currArr[1] || ''
          return pre
        }, {})
      }
      if (typeof name === 'undefined') {
        return result
      }
      return result[name] || ''
    }
  }

  const $menus = [
    /*{
      text: '首页',
      type: 'home',
      path: '/page/home'
    },*/
    {
      text: '用户管理',
      type: 'user-add',
      path: '/page/user'
    },
    {
      text: '技师管理',
      type: 'team',
      path: '/page/technician'
    },
    {
      text: '门店管理',
      type: 'bank',
      path: '/page/stores'
    },
    {
      text: '运营管理',
      type: 'line-chart',
      children: [
        {
          text: '优惠券配置',
          type: 'dollar',
          path: '/page/card'
        },
        {
          text: 'banner管理',
          type: 'file-image',
          path: '/page/banner'
        },
        {
          text: '拉新奖励',
          type: 'dollar',
          path: '/page/usedCard'
        }
      ]
    },
    {
      text: '服务管理',
      type: 'solution',
      path: '/page/services'
    }
  ]

  const $info = {
    apiHost
  }

  return (
    <context.Provider
      value={{
        history,
        state,
        dispatch,
        $message: message,
        $fetch,
        $utils,
        $info,
        $menus
      }}
    >
      {props.children}
    </context.Provider>
  )
}

export { context, Provider }
