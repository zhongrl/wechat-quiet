<template>
  <view>
    <image class="starItem" v-for="i in 5" :src="i <= num ? star : grayStar" :key="i" />
  </view>
</template>

<script>
import star from '@/assets/star.png'
import grayStar from '@/assets/star_gray.png'
export default {
  props: {
    num: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      star,
      grayStar
    }
  }
}
</script>

<style>
.starItem {
  width: 28rpx;
  height: 28rpx;
  margin-right: 10rpx;
}

.starItem:last-child {
  margin: 0;
}
</style>
