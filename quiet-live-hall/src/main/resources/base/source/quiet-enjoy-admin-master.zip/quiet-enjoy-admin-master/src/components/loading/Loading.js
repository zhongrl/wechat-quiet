import React from 'react'
import { Spin } from 'antd'

export default function Loading(props) {
  const { isLoading = false } = props
  return isLoading ? (
    <div className="loading">
      <Spin size="large"></Spin>
    </div>
  ) : null
}
