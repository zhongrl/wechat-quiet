import React, { useContext, useEffect, useState } from 'react'
import CommForm from '@components/commForm/CommForm'
import { context } from '@components/Provider'
import { message, Layout, Upload, Icon } from 'antd'

const { Content } = Layout

const deafultList = [
  {
    type: 'input',
    label: '技师姓名/昵称',
    field: 'username'
  },
  {
    type: 'select',
    label: '性别',
    field: 'gender',
    options: [
      { value: '1', text: '男' },
      { value: '2', text: '女' }
    ]
  },
  {
    type: 'select',
    label: '技师等级',
    field: 'level',
    options: [
      { value: '初级', text: '初级' },
      { value: '中级', text: '中级' },
      { value: '高级', text: '高级' }
    ]
  },
  {
    type: 'input',
    label: '手机号',
    field: 'mobile'
  },
  {
    type: 'input',
    label: '原价格',
    field: 'orgPrice'
  },
  {
    type: 'input',
    label: '优惠价格',
    field: 'price'
  },
  {
    type: 'date',
    label: '入职时间',
    field: 'inJobDate'
  },
  {
    type: 'select',
    label: '服务名称',
    field: 'serviceId',
    options: []
  },
  {
    type: 'select',
    label: '门店名称',
    field: 'storeId',
    options: []
  },
  {
    type: 'select',
    label: '是否有效',
    field: 'delFlag',
    options: [{ value: '0', text: '无效' }, { value: '1', text: '有效' }]
  },
  {
    type: 'input',
    label: '账户',
    field: 'account'
  },
  {
    type: 'input',
    label: '密码',
    field: 'password'
  },
  {
    type: 'select',
    label: '用户类型',
    field: 'userType',
    options: [
      { value: '1', text: '超级管理员' },
      { value: '2', text: '门店/运营' },
      { value: '3', text: '技师' },
      { value: '4', text: '客户' }
    ]
  }
]

export default function EditServices() {
  const { $fetch, history, $utils } = useContext(context)
  const [initValue, setInitValue] = useState({})
  const [list, setList] = useState(deafultList)
  const [headImg, setHeadImg] = useState('')
  const [loading, setLoading] = useState(false)

  const id = $utils.getQuery('id')

  useEffect(() => {
    async function getDetail() {
      const res = await $fetch('bi/js/selectByJs', { id })
      const info = res || {}
      setInitValue(info)
      setHeadImg(info.headImg || '')
      setList(
        list.map(item =>
          info[item.field] ? { ...item, value: info[item.field] } : item
        )
      )
    }
    async function getOptions() {
      const storesRes = await $fetch('bi/jStore/findSores', {
        current: 1,
        size: 1000
      })
      const serviceRes = await $fetch('bi/jService/findXcxService', {
        current: 1,
        size: 1000
      })
      const storesOptions = storesRes.reduce((pre, { id, name }) => {
        pre.push({
          text: name,
          value: id
        })
        return pre
      }, [])

      const serviceOptions = serviceRes.reduce(
        (pre, { id, serviceName }) => {
          pre.push({
            text: serviceName,
            value: id
          })
          return pre
        },
        []
      )
      setList(
        list.map(item =>{
          if (item.field === 'storeId') {
            return {
              ...item,
              options: storesOptions
            }
          }
          if (item.field === 'serviceId') {
            return {
              ...item,
              options: serviceOptions
            }
          }
          return { ...item }
        })
      )
    }
    getOptions()
    if (id) {
      getDetail()
    }
  }, [id])

  async function toEdit(values) {
    await $fetch('bi/jUser/save', {
      ...initValue,
      ...values,
      headImg
    })
    message.success('操作成功', 2).then(() => {
      history.replace('/page/technician')
    })
  }

  const submit = values => {
    toEdit(values)
  }

  const uploadButton = (
    <div>
      <Icon type={loading ? 'loading' : 'plus'} />
      <div className="ant-upload-text">Upload</div>
    </div>
  )

  const customRequest = async info => {
    const formData = new FormData()
    formData.append('file', info.file)
    setLoading(true)
    const res = await $fetch('file/fileUpload', formData)
    setLoading(false)
    setHeadImg(res)
  }

  const handlePreview = () => {}

  return (
    <Content style={{ padding: '100px', backgroundColor: '#fff' }}>
      上传技师头像：
      <Upload
        name="file"
        listType="picture-card"
        className="avatar-uploader"
        showUploadList={false}
        onPreview={handlePreview}
        customRequest={customRequest}
      >
        {headImg ? (
          <img src={headImg} alt="avatar" style={{ width: '100%' }} />
        ) : (
          uploadButton
        )}
      </Upload>
      <CommForm list={list} layout="vertical" submit={submit} buttonText="提交"></CommForm>
    </Content>
  )
}
