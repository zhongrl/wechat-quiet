import React, { useContext, useEffect, useState } from 'react'
import CommTable from '@components/commTable/CommTable'
import { context } from '@components/Provider'
import { Button, Col, Row, Modal, message, Divider, Layout } from 'antd'
import { Link } from 'react-router-dom'
import CommForm from '@components/commForm/CommForm'

const { Content } = Layout

const formList = [
  {
    type: 'input',
    label: '服务名称',
    field: 'serviceName'
  },
  {
    type: 'input',
    label: '服务时长',
    field: 'serviceTime'
  }
]

export default function Services() {
  const { $fetch, history, $utils } = useContext(context)
  const [total, setTotal] = useState(0)
  const [list, setList] = useState([])
  const [visible, setVisible] = useState(false)
  const [current, setCurrent] = useState({})
  const [searchInfo, setSearchInfo] = useState({})
  const [pageInfo, setPageInfo] = useState({
    current: 1,
    size: 15
  })

  const toEdit = record => {
    const { id } = record
    history.push({
      pathname: '/page/editServices',
      search: $utils.setQuery({ id }, true)
    })
  }

  const toDelete = record => {
    setCurrent(record)
    setVisible(true)
  }

  const columns = [
    {
      title: '服务名称',
      dataIndex: 'serviceName'
    },
    {
      title: '服务时长',
      dataIndex: 'serviceTime'
    },
    {
      title: '创建时间',
      dataIndex: 'createTime'
    },
    {
      title: '操作人',
      dataIndex: 'oper'
    },
    {
      title: '修改时间',
      dataIndex: 'updateTime'
    },
    {
      title: '操作',
      key: 'action',
      render: record => (
        <span>
          <Button type="primary" onClick={() => toEdit(record)}>
            编辑
          </Button>
          <Divider type="vertical" />
          <Button type="danger" onClick={() => toDelete(record)}>
            删除
          </Button>
        </span>
      )
    }
  ]

  const getList = async function() {
    const res = await $fetch('bi/jService/list', { ...pageInfo, ...searchInfo })
    const { records = [], total: resTotal } = res
    setTotal(resTotal)
    setList(records)
  }

  const changePage = (current, size) => {
    setPageInfo({
      ...pageInfo,
      current,
      size
    })
  }

  useEffect(() => {
    getList()
  }, [pageInfo, searchInfo])

  const handleOk = async () => {
    setVisible(false)
    await $fetch('bi/jService/delete', { ...current })
    message.success('删除成功', 2).then(() => {
      getList()
    })
  }

  const handleCancel = () => {
    setVisible(false)
  }

  const submit = values => {
    setPageInfo({
      ...pageInfo,
      current: 1
    })
    setSearchInfo(values)
  }
  // const updateValue = (changeItem, values = {}) => {
  //   // setSearchInfo(values)
  // }

  return (
    <Content style={{ padding: '40px', backgroundColor: '#fff' }}>
      <CommForm
        // updateValue={updateValue}
        list={formList}
        submit={submit}
        layout="inline"
      ></CommForm>

      <Row style={{ marginBottom: '20px', marginTop: '20px' }}>
        <Col span={2} offset={2}>
          <Link to="/page/editServices">
            <Button type="primary">新增</Button>
          </Link>
        </Col>
      </Row>
      <CommTable
        dataSource={list}
        columns={columns}
        pagination={{
          total,
          current: pageInfo.current,
          pageSize: pageInfo.size,
          onChange: changePage,
          showSizeChanger: true,
          onShowSizeChange: changePage
        }}
      ></CommTable>

      <Modal
        title="确认操作"
        visible={visible}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <p>{`确定删除“${current.serviceName}”么？`}</p>
      </Modal>
    </Content>
  )
}
