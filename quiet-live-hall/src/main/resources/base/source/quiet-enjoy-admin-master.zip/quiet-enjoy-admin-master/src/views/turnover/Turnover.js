import React, { useContext, useEffect, useState } from 'react'
// import CommTable from '@components/commTable/CommTable'
import { context } from '@components/Provider'
import {
  Col,
  Row,
  Layout,
  Radio
} from 'antd'
import CommForm from '@components/commForm/CommForm'

const { Content } = Layout

const formList = [
  {
    type: 'rangeDate',
    label: '选择时间',
    field: 'rangeDate',
  }
]

export default function Services() {
  const { $fetch, history, $utils } = useContext(context)
  // const [total, setTotal] = useState(0)
  // const [list, setList] = useState([])
  // const [visible, setVisible] = useState(false)
  // const [reson, setReson] = useState('')
  const [detail, setDetail] = useState({
    totalOrderNum: '',
    totalSalar: 0
  })
  const [searchInfo, setSearchInfo] = useState({})
  // const [pageInfo, setPageInfo] = useState({
  //   current: 1,
  //   size: 15
  // })

  const storeId = $utils.getQuery('storeId')


  // const columns = [
  //   {
  //     title: '订单量',
  //     dataIndex: 'orderNumber'
  //   },
  //   {
  //     title: '营业额',
  //     dataIndex: 'storeName'
  //   }
  // ]

  const getInfo = async function() {
    const res = await $fetch(
      'bi/jOrder/orderYingYee',
      storeId
        ? {
            // ...pageInfo,
            ...searchInfo,
            storeId
          }
        : {
            // ...pageInfo,
            ...searchInfo
          }
    )
    // const { totalOrderNum, totalSalar } = res
    setDetail(res)
    // setTotal(resTotal)
    // setList(records)
  }

  // const changePage = (current, size) => {
  //   setPageInfo({
  //     ...pageInfo,
  //     current,
  //     size
  //   })
  // }

  useEffect(() => {
    getInfo()
  }, [searchInfo])

  const submit = values => {
    // setPageInfo({
    //   ...pageInfo,
    //   current: 1
    // })
    const arr = values.rangeDate

    setSearchInfo({
      startTime: arr[0],
      endTime: arr[1],
    })
  }

  const changeTab = e => {
    history.push({
      pathname: `/page/${e.target.value}`,
      search: $utils.setQuery({ storeId: storeId }, true)
    })
  }

  return (
    <Content style={{ padding: '40px', backgroundColor: '#fff' }}>
      {storeId ? (
        <div
          style={{
            marginBottom: '20px',
            marginTop: '20px',
            textAlign: 'center'
          }}
        >
          <Radio.Group
            defaultValue="turnover"
            onChange={changeTab}
            buttonStyle="solid"
          >
            <Radio.Button value="turnover">营业额</Radio.Button>
            <Radio.Button value="order">订单列表</Radio.Button>
            <Radio.Button value="technician">技师列表</Radio.Button>
          </Radio.Group>
        </div>
      ) : (
        ''
      )}
      <CommForm
        list={formList}
        submit={submit}
      ></CommForm>
      <Row style={{ marginBottom: '20px', marginTop: '20px' }}>
        <Col span={4}>
        </Col>
      </Row>

      <Row style={{ marginBottom: '20px', marginTop: '20px' }}>
        <Col span={4}>
        </Col>
      </Row>
      <Row>
        <Col span={4}>
          订单数：{detail.totalOrderNum}笔
        </Col>
        <Col span={4}>
          营业额：{Number(detail.totalSalar).toFixed(2)}元
        </Col>
      </Row>
      {/* {totalOrderNum, totalSalar} */}
      {/* <CommTable
        dataSource={list}
        columns={columns}
        pagination={{
          total,
          current: pageInfo.current,
          pageSize: pageInfo.size,
          onChange: changePage,
          showSizeChanger: true,
          onShowSizeChange: changePage
        }}
      ></CommTable> */}
    </Content>
  )
}
