import React, { useContext, useEffect, useState } from 'react'
import CommTable from '@components/commTable/CommTable'
import { context } from '@components/Provider'
import {
  Button,
  Col,
  Row,
  Modal,
  message,
  Layout,
  Divider,
  Avatar,
  Radio,
  Tag,
  Rate
} from 'antd'
import { Link } from 'react-router-dom'
import CommForm from '@components/commForm/CommForm'

const { Content } = Layout

const defaultFormList = [
  {
    type: 'input',
    label: '技师姓名/昵称',
    field: 'username'
  },
  {
    type: 'input',
    label: '手机号',
    field: 'mobile'
  }
  /*{
    type: 'select',
    label: '技师等级',
    field: 'level',
    options: [
      { value: '初级', text: '初级' },
      { value: '中级', text: '中级' },
      { value: '高级', text: '高级' }
    ]
  },
  {
    type: 'input',
    label: '价格',
    field: 'price'
  },
  {
    type: 'select',
    label: '服务',
    field: 'serviceId',
    options: []
  },
  {
    type: 'select',
    label: '门店',
    field: 'storeId',
    options: []
  },
  {
    type: 'select',
    label: '服务名称',
    field: 'userType',
    options: [
      { value: '1', text: '超级管理员' },
      { value: '2', text: '门店/运营' },
      { value: '3', text: '技师' },
      { value: '4', text: '客户' }
    ]
  }*/
]
const restPwdList = [
  {
    type: 'input',
    label: '密码',
    field: 'restPwd',
    rules: [{ required: true, message: '请输入密码' }]
  }
]

export default function Services() {
  const { $fetch, history, $utils } = useContext(context)
  const [total, setTotal] = useState(0)
  const [list, setList] = useState([])
  const [visible, setVisible] = useState(false)
  const [visiblePwd, setVisiblePwd] = useState(false)
  const [current, setCurrent] = useState({})
  const [searchInfo, setSearchInfo] = useState({})
  const [formList, setFormList] = useState(defaultFormList)
  const [pageInfo, setPageInfo] = useState({
    current: 1,
    size: 15
  })
  const storeId = $utils.getQuery('storeId')
  const storeArr = JSON.parse(sessionStorage.getItem('storeList'))
  let storeName = ''
  storeArr.map(item => {
    if (item.id == storeId) storeName = item.name
  })

  const toEdit = record => {
    const { id } = record
    history.push({
      pathname: '/page/editTechnician',
      search: $utils.setQuery({ id }, true)
    })
  }

  useEffect(() => {
    async function getOptions() {
      const storesRes = await $fetch('bi/jStore/list', {
        current: 1,
        size: 1000
      })
      const serviceRes = await $fetch('bi/jService/list', {
        current: 1,
        size: 1000
      })
      const { records: storesRecords } = storesRes
      const { records: serviceRecords } = serviceRes
      const storesOptions = storesRecords.reduce((pre, { id, name }) => {
        pre.push({
          text: name,
          value: id
        })
        return pre
      }, [])

      const serviceOptions = serviceRecords.reduce(
        (pre, { id, serviceName }) => {
          pre.push({
            text: serviceName,
            value: id
          })
          return pre
        },
        []
      )

      setFormList(
        formList.map(item => {
          if (item.field === 'storeId') {
            return {
              ...item,
              value: storeId ? storeId : item.value || '',
              options: storesOptions
            }
          }
          if (item.field === 'serviceId') {
            return {
              ...item,
              options: serviceOptions
            }
          }
          return { ...item }
        })
      )
    }

    getOptions()
  }, [])

  const toDelete = record => {
    setCurrent(record)
    setVisible(true)
  }

  const toRestPwd = record => {
    setCurrent(record)
    setVisiblePwd(true)
  }

  const columns = [
    {
      title: '头像',
      width: 60,
      dataIndex: 'headImg',
      render: record =>
        record ? <Avatar src={record} /> : <Avatar icon="user" />
    },
    {
      title: '技师姓名/昵称',
      width: 120,
      dataIndex: 'username'
    },
    {
      title: '门店',
      dataIndex: 'storeName'
    },
    {
      title: '服务',
      dataIndex: 'service'
    },
    {
      title: '级别',
      width: 100,
      dataIndex: 'level'
    },
    {
      title: '价格',
      width: 100,
      dataIndex: 'price'
    },
    {
      title: '手机',
      width: 150,
      dataIndex: 'mobile'
    },
    {
      title: '入职时间',
      width: 180,
      dataIndex: 'inJobDate',
      render: record =>
        record.split(" ")[0]
    },
    // {
    //   title: '综合评分',
    //   width: 80,
    //   dataIndex: 'jstotlfen'
    // },


    {
      title: '综合评分',
      dataIndex: 'jstotlfen',
      width: 200,
      render: (num, record) => {
        // const content = (
        //   <div>
        //     <p>技师满意度：<Rate disabled defaultValue={record.jsManyi} /></p>
        //     <p>沟通满意度：<Rate disabled defaultValue={record.gtDw} /></p>
        //     <p>服务满意度：<Rate disabled defaultValue={record.serviceYx} /></p>
        //   </div>
        // )
        return (
          // <Popover content={content}>
          //   <span><Rate disabled defaultValue={num} /></span>
          // </Popover>
          <Rate disabled defaultValue={num} />
        )
      }
    },


    // {
    //   title: '工作状态',
    //   width: 100,
    //   dataIndex: 'jsStatus',
    //   render: record => {
    //     return [
    //       { value: '1', text: '可接单' },
    //       { value: '2', text: '停止接单' },
    //       { value: '3', text: '休息中' }
    //     ].map(item => {
    //       if (item.value == record) return item.text
    //     })
    //   }
    // },

    {
      title: '工作状态',
      width: 120,
      dataIndex: 'jsStatus',
      render: status => {
        const statusText = {
          '1': '接单中',
          '2': '停止接单',
          '3': '休息中'
        }
        const colors = {
          '1': '#87d068',
          '2': '#666',
          '3': '#666'
        }
        return (
          <Tag color={colors[status || '1']}>{statusText[status] || ''}</Tag>
        )
      }
    },

    {
      title: '操作',
      key: 'action',
      width: storeId ? 100 : 280,
      fixed: 'right',
      render: record =>
        storeId ? (
          <span>
            <Link to={`/page/comment?userId=${record.id}`}>评论列表</Link>
            {/*<Divider type="vertical" />
                        <Link to={`/page/order?userId=${record.id}`}>订单列表</Link>*/}
          </span>
        ) : (
          <span>
            <Button type="primary" onClick={() => toEdit(record)}>
              编辑
            </Button>
            <Divider type="vertical" />
            <Button type="danger" onClick={() => toDelete(record)}>
              删除
            </Button>
            <Divider type="vertical" />
            <Button type="danger" onClick={() => toRestPwd(record)}>
              修改密码
            </Button>
          </span>
        )
    }
  ]

  const getList = async function() {
    const res = await $fetch(
      'bi/findJs',
      storeId
        ? { ...pageInfo, ...searchInfo, storeId }
        : { ...pageInfo, ...searchInfo }
    )
    const { records = [], total: resTotal } = res
    setTotal(resTotal)
    setList(records)
  }

  const changePage = (current, size) => {
    setPageInfo({
      ...pageInfo,
      current,
      size
    })
  }

  useEffect(() => {
    getList()
  }, [pageInfo, searchInfo])

  const handleOk = async () => {
    setVisible(false)
    await $fetch('bi/delete', { ...current })
    message.success('删除成功', 2).then(() => {
      getList()
    })
  }

  const handleCancel = () => {
    setVisible(false)
  }

  const handleOkPwd = async values => {
    setVisiblePwd(false)
    await $fetch('bi/jUser/restPwd', {
      id: current.id,
      password: values.restPwd
    })
    message.success('修改成功', 2)
  }

  const handleCancelPwd = () => {
    setVisiblePwd(false)
  }

  const submit = values => {
    setPageInfo({
      ...pageInfo,
      current: 1
    })
    setSearchInfo(values)
  }
  // const updateValue = (changeItem, values = {}) => {
  //   // setSearchInfo(values)
  // }
  const changeTab = e => {
    console.log(`radio checked:${e.target.value}`)
    history.push({
      pathname: `/page/${e.target.value}`,
      search: $utils.setQuery({ storeId: storeId }, true)
    })
  }

  return (
    <Content style={{ padding: '40px', backgroundColor: '#fff' }}>
      {storeId ? (
        <div
          style={{
            marginBottom: '20px',
            textAlign: 'center'
          }}
        >
          <h1 style={{ marginBottom: '20px',fontSize: '28px'}}>{storeName}</h1>
          <Radio.Group
            defaultValue="technician"
            onChange={changeTab}
            buttonStyle="solid"
          >
            <Radio.Button value="order">营业额</Radio.Button>
            <Radio.Button value="technician">技师列表</Radio.Button>
          </Radio.Group>
        </div>
      ) : (
        ''
      )}
      <CommForm list={formList} submit={submit}></CommForm>

      <Row style={{ marginBottom: '20px', marginTop: '20px' }}>
        <Col span={4}>
          <Link to="/page/editTechnician">
            <Button type="primary" icon="plus">
              新增
            </Button>
          </Link>
        </Col>
      </Row>
      <CommTable
        dataSource={list}
        columns={columns}
        pagination={{
          total,
          current: pageInfo.current,
          pageSize: pageInfo.size,
          onChange: changePage,
          showSizeChanger: true,
          onShowSizeChange: changePage
        }}
      ></CommTable>

      <Modal
        title="确认操作"
        visible={visible}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <p>{`确定删除“${current.username}”么？`}</p>
      </Modal>
      <Modal
        title={`修改“${current.username}”密码`}
        visible={visiblePwd}
        onOk={handleOkPwd}
        onCancel={handleCancelPwd}
        footer={null}
      >
        <CommForm
          list={restPwdList}
          isShowReset={false}
          submit={handleOkPwd}
          buttonText="提交"
        ></CommForm>
      </Modal>
    </Content>
  )
}
