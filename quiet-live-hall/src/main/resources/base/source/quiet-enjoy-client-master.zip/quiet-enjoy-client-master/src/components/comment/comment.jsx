import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import Star from '@/components/star/star'
import ShowPhoto from '@/components/showPhoto/showPhoto'
import './comment.less'

export default function Comment(props) {
  const { list = [] } = props
  return (
    <View className="comment">
      {list.map(item => (
        <View className="commentItem" key={item.id}>
          <Image className="commentPhoto" src={item.wxHeadImg}></Image>
          <View className="commentMain">
            <View className="commentTop">
              <Text>{item.wxUserName}</Text>
              <View className="commentStar">
                <Star num={item.avgNum}></Star>
              </View>
            </View>
            <View className="commentDesc">
              <Text>
                {item.remark}
              </Text>
            </View>
            <ShowPhoto list={[item.img1, item.img2, item.img3]}></ShowPhoto>
            <View className="commentBottom">
              <Text>技师：{item.userName}</Text>
              <Text>{item.createTime.split(' ')[0]}</Text>
            </View>
          </View>
          
        </View>
      ))}
    </View>
  )
}
