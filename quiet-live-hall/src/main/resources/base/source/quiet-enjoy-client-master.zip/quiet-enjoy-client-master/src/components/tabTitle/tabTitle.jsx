import Taro from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import './tabTitle.less'

export default function TabTitle(props) {
  const { list = [], changeTab } = props
  return (
    <View className="tabTitle">
      {list.map((item, index) => (
        <View
          className="titleItem"
          key={`${index}`}
          onClick={() => changeTab(index)}
        >
          <Text>{item.text}</Text>
          {item.isChecked ? <View className="tabLine"></View> : null}
        </View>
      ))}
    </View>
  )
}
