import React, { useContext, useEffect, useState } from 'react'
import CommForm from '@components/commForm/CommForm'
import { context } from '@components/Provider'
import { message, Layout } from 'antd'

const { Content } = Layout

const deafultList = [
  {
    type: 'input',
    label: '优惠券类型',
    field: 'couponType'
  },
  {
    type: 'input',
    label: '主题',
    field: 'title'
  },
  {
    type: 'input',
    label: '优惠券金额',
    field: 'price'
  },
  {
    type: 'input',
    label: '优惠券描述',
    field: 'remake'
  },
  {
    type: 'select',
    label: '状态',
    field: 'delFlag',
    options: [
      { value: '1', text: '已使用' },
      { value: '2', text: '待使用' },
      { value: '3', text: '已过期' }
    ],
    value: '2'
  },
  {
    type: 'date',
    label: '开始时间',
    field: 'startTime'
  },
  {
    type: 'date',
    label: '结束时间',
    field: 'endTime'
  }
]

export default function EditServices() {
  const { $fetch, history, $utils } = useContext(context)
  const [initValue, setInitValue] = useState({})
  const [list, setList] = useState(deafultList)
  const id = $utils.getQuery('id')

  useEffect(() => {
    async function getDetail() {
      const res = await $fetch('bi/jCoupon/selectById', { id })
      const info = res || {}
      setInitValue(info)
      setList(
        list.map(item =>
          info[item.field] ? { ...item, value: info[item.field] } : item
        )
      )
    }
    if (id) {
      getDetail()
    }
  }, [id])

  async function toEdit(values) {
    await $fetch('bi/jCoupon/save', { ...initValue, ...values })
    message.success('操作成功', 2).then(() => {
      history.replace('/page/card')
    })
  }

  const submit = values => {
    toEdit(values)
  }

  return (
    <Content style={{ padding: '100px', backgroundColor: '#fff' }}>
      <CommForm list={list} layout="vertical" submit={submit} buttonText="提交"></CommForm>
    </Content>
  )
}
