<template>
  <view>
    <top-tab :tabIndex="tabIndex" :list="tabList" @changeTab="changeTab"></top-tab>
    <empty-list v-if="list.length === 0 && loadingStatus === 2"></empty-list>
    <view v-for="item in list" :key="item.id">
      <navigator :url="`/pages/orderDetail/orderDetail?id=${item.id}`" class="mineListItem">
        <text class="mineListLeft">订单号：{{item.orderNumber}}</text>
        <text>{{item.payTime|showDate}}</text>
      </navigator>
    </view>
    <uni-loadmore v-if="list.length >= size" :status="list.length < total ? 'loading' : 'noMore'"></uni-loadmore>
    <uni-calendar
      :endDate="today"
      ref="calendar"
      :insert="false"
      :range="true"
      @confirm="selectDate"
    />
  </view>
</template>
<script>
import { uniCalendar, uniLoadMore } from '@dcloudio/uni-ui'
import moment from 'moment'
import http from '@/utils/http'
import topTab from '@/components/topTab'
import emptyList from '@/components/emptyList'

const today = moment().format('YYYY-MM-DD')
export default {
  components: {
    'uni-loadmore': uniLoadMore,
    'uni-calendar': uniCalendar,
    'top-tab': topTab,
    'empty-list': emptyList
  },
  data() {
    return {
      tabIndex: 0,
      tabList: [
        { text: '今天', total: 0 },
        { text: `${new Date().getMonth() + 1}月`, total: 0 },
        { text: '选择', total: 0 }
      ],
      size: 15,
      current: 1,
      startTime: '',
      endTime: '',
      endDate: '',
      timeConf: {
        start: '00:00:00',
        end: '23:59:59'
      },
      loadingStatus: 0, // 0 未开始，1请求中，2请求完成
      today,
      list: []
    }
  },
  filters: {
    showDate(val) {
      return val ? moment(val).format('YYYY-MM-DD hh:mm') : ''
    }
  },
  onLoad() {
    // 日期选择有bug
    this.setDate()
    this.getList()
  },
  onReachBottom() {
    const { list, total, current } = this
    if (list.length < total) {
      this.getList(current + 1)
    }
  },
  onPullDownRefresh() {
    this.getList(1)
  },
  methods: {
    setDate(flg = 0) {
      const { timeConf } = this
      const { start, end } = timeConf
      if (flg === 0) {
        this.startTime = `${today} ${start}`
        this.endTime = `${today} ${end}`
      }
      if (flg === 1) {
        const pre = moment().format('YYYY-MM')
        const lastDay = new Date(
          pre.split('-')[0],
          parseInt(pre.split('-')[1]),
          0
        ).getDate()
        this.startTime = `${pre}-01 ${start}`
        this.endTime = `${pre}-${lastDay} ${end}`
      }
    },
    async getList(page = 1) {
      const {
        loadingStatus,
        size,
        current,
        startTime,
        endTime,
        list,
        tabIndex,
        tabList
      } = this
      if (loadingStatus === 1) {
        return false
      }
      this.loadingStatus = 1
      uni.stopPullDownRefresh()
      const { records, total } = await http('js/list', {
        current: page,
        size,
        startTime,
        endTime
      })
      this.loadingStatus = 2
      this.current = page
      this.list = page > 1 ? [...list, ...records] : [...records]
      this.total = total
      this.$set(tabList, tabIndex, { ...tabList[tabIndex], total })
    },
    changeTab(index) {
      const { tabIndex } = this
      if (tabIndex === index && index !== 2) {
        return false
      }
      if (index === 2) {
        this.$refs.calendar.open()
      } else {
        if (tabIndex !== index) {
          this.setDate(index)
          this.current = 1
          this.tabIndex = index
          this.getList()
        }
      }
    },
    selectDate(e) {
      const { timeConf } = this
      const { start, end } = timeConf
      const { begin, end: endDate } = e.range
      this.startTime = `${begin} ${start}`
      this.endTime = `${endDate} ${end}`
      this.current = 1
      this.tabIndex = 2
      this.getList()
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
}
.mineList {
  padding-top: 20rpx;
}
.mineListItem {
  display: flex;
  justify-content: space-between;
  padding: 24rpx 20rpx;
  margin-bottom: 10rpx;
  font-size: 28rpx;
  color: #000000;
  line-height: 40rpx;
  background: #ffffff;
  border-radius: 8rpx;
}
</style>
