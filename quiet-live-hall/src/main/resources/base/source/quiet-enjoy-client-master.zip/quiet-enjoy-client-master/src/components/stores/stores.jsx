import Taro, { useEffect, useState } from '@tarojs/taro'
import { View, Text, Image, Navigator } from '@tarojs/components'
import usePosition from '@/utils/usePosition'
import local from '@/assets/local.png'
import './stores.less'
import http from '../../utils/http'

export default function Stores(props) {
  const [list, setList] = useState([])
  const positions = usePosition(list, getList)
  useEffect(() => {
    getList()
  }, [])
// console.log(positions)
  async function getList() {
    const res = await http('custom/findXcxJStore')
    setList(res)
  }

  const toLocation = (item) => {
    const {jwDu, address = '', name = ''} = item
    const [lat, lng] = jwDu ? jwDu.split(',') : ['', '']
    if(lat){
      Taro.openLocation({
        latitude: Number(lat),
        longitude: Number(lng),
        name,
        address,
        scale: 18
      })
    }
  }

  return (
    <View className="stores">
      {list.map((item, index) => (
        <View className="storesItem" key={item.id}>
          <View className="storesTitle">
            <Navigator
              url={`/pages/technician/technician?id=${item.id}`}
              className="storesName"
            >
              {item.name}
            </Navigator>
            <Text className="storesDistance">
              {positions[index] || ''}
            </Text>
          </View>
          <View className="storesService">{item.storetitle}</View>
          <View className="storesGift">
            <Text className="storesJiang">奖</Text>
            <Text>邀请好友奖励20元</Text>
          </View>
          <View className="storesBottom">
            <View onClick={()=> toLocation(item)} className="storesAddress">
              <Image src={local} className="localIcon"></Image>
              <Text className="storeAddressText">{item.address}</Text>
            </View>
            <Navigator
              url={`/pages/technician/technician?id=${item.id}`}
              className="storesButton"
            >
              预约
            </Navigator>
          </View>
        </View>
      ))}
    </View>
  )
}
