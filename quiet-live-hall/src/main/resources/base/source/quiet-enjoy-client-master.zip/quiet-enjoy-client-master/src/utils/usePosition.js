import Taro, { useEffect, useState } from '@tarojs/taro'
import { View, Text, Image, Navigator } from '@tarojs/components'
import local from '@/assets/local.png'
import './stores.less'
import http from '@/utils/http'
const QQMapWX = require('@/utils/qqmap-wx-jssdk.js')

const qqmapsdk = new QQMapWX({
  key: '34DBZ-VYM6F-ICAJY-N75RJ-56SKJ-7BFEU'
})

export default function usePosition(records, getList) {
  const [positions, setPositions] = useState([])
  
  useEffect(()=> {
    const arr = Array.isArray(records) ? [...records] : [records]
    const initLocal = async (latitude, longitude)=> {
      const unknowArr = arr.reduce((pre,curr)=> {
        const {address, jwDu, id, storeId} = curr
        if(!jwDu){
          pre.push({address, id: storeId ? storeId : id})
        }
        return pre
      }, [])
      if(unknowArr.length > 0){
        const jwDuArr = await Promise.all(unknowArr.map((item, index)=> getPosition(item, index)))
        updatePosition(jwDuArr)
      }else{
        getDistance(arr, latitude, longitude)
      }
    }

    if(arr.length > 0){
      Taro.getLocation({
        type: 'wgs84',
        success: res => {
          const {latitude, longitude} = res
          initLocal(latitude, longitude)
        }
      })
    }
  }, [records])

  const getPosition = (item, index)=> {
    return new Promise((resolve, reject)=> {
      const {address, id} = item
      setTimeout(()=> {
        // 并发数：5次 / key / 秒
        qqmapsdk.geocoder({
          address,
          success: (res)=> {
            const {lat, lng} = res.result.location
            resolve({
              id,
              jwDu: `${lat}, ${lng}`
            })
          },
          fail: (error)=> {
            // Taro.showToast({
            //   title: error.message,
            //   icon: 'none',
            //   duration: 2000
            // })
          },
        })
      }, 300 * index)
    })
  }

  const updatePosition = async (jwDuArr)=> {
    const res = await http('custom/updateJwDu', jwDuArr)
    getList()
  }

  const getDistance = async (arr, userLat, userLng) => {
    if(!userLat){
      return false
    }
    const toArr = arr.map(({jwDu})=> ({latitude: Number(jwDu.split(',')[0]), longitude: Number(jwDu.split(',')[1])}))
    qqmapsdk.calculateDistance({
      from: {
        latitude: userLat,
        longitude: userLng
      },
      to: toArr,
      success: res=> {
        const {elements} = res.result
        setPositions(elements.map(item=> item.distance > 1000 ? '1.0km' : `${item.distance}m`))
      },
      fail: error=> {
        // Taro.showToast({
        //   title: error.message,
        //   icon: 'none',
        //   duration: 2000
        // })
      }
    })
  }
  return positions
}
