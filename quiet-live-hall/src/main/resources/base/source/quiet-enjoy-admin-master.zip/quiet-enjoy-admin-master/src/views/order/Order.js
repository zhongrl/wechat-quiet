import React, { useContext, useEffect, useState } from 'react'
import CommTable from '@components/commTable/CommTable'
import { context } from '@components/Provider'
import {
  Button,
  Tag,
  Col,
  Row,
  Modal,
  message,
  Layout,
  Radio
} from 'antd'
import CommForm from '@components/commForm/CommForm'

const { Content } = Layout

const formList = [
  {
    type: 'rangeDate',
    label: '选择时间',
    field: 'rangeDate',
  },
  {
    type: 'select',
    label: '订单状态',
    field: 'status',
    options: [
      { value: '1', text: '已完成' },
      { value: '2', text: '未支付' },
      { value: '3', text: '服务中' },
      { value: '4', text: '排队中' },
      { value: '5', text: '已取消' }
    ]
  },
  {
    type: 'select',
    label: '支付来源',
    field: 'optSource',
    options: [
      { value: '平台支付', text: '平台支付' },
      { value: '第三方支付', text: '第三方支付' }
    ]
  }
]

export default function Services() {
  const { $fetch, history, $utils } = useContext(context)
  const [total, setTotal] = useState(0)
  const [list, setList] = useState([])
  const [visible, setVisible] = useState(false)
  const [reson, setReson] = useState('')
  const [searchInfo, setSearchInfo] = useState({})
  const [pageInfo, setPageInfo] = useState({
    current: 1,
    size: 15
  })

  const [detail, setDetail] = useState({
    totalOrderNum: '',
    totalSalar: 0
  })

  const storeId = $utils.getQuery('storeId')
  const storeArr = JSON.parse(sessionStorage.getItem('storeList'))
  let storeName = ''
  storeArr.map(item => {
    if (item.id == storeId) storeName = item.name
  })

  const showReson = msg => {
    setReson(msg)
    setVisible(true)
  }

  const tipUser = async id => {
    await $fetch('bi/msg/cuiCuService', { id })
    message.success('成功', 2).then(() => {
      // getList()
    })
  }

  // const toDelete = record => {
  //   setCurrent(record)
  //   setVisible(true)
  // }

  const columns = [
    {
      title: '支付流水号',
      dataIndex: 'orderNumber'
    },
    {
      title: '门店名称',
      dataIndex: 'storeName'
    },
    {
      title: '技师名称',
      dataIndex: 'jsUsername'
    },
    // {
    //   title: '优惠券名称',
    //   dataIndex: 'couponName'
    // },
    // {
    //   title: '优惠金额',
    //   dataIndex: 'couponPrice'
    // },
    {
      title: '客户名称',
      dataIndex: 'custUsername'
    },
    {
      title: '客户手机号',
      dataIndex: 'custMobile'
    },
    {
      title: '支付金额',
      dataIndex: 'price'
    },
    // {
    //   title: '节约金额',
    //   dataIndex: 'jyPrice',
    // },
    // {
    //   title: '原价',
    //   dataIndex: 'orgPrice',
    // },
    {
      title: '支付时间',
      dataIndex: 'payTime'
    },
    // {
    //   title: '服务名称',
    //   dataIndex: 'serviceName',
    // },
    // {
    //   title: '服务时长',
    //   dataIndex: 'serviceTime',
    // },
    {
      title: '订单状态',
      dataIndex: 'status',
      render: status => {
        const statusText = {
          '1': '已完成',
          '2': '未支付',
          '3': '服务中',
          '4': '排队中',
          '5': '已取消'
        }
        const colors = {
          '1': '#666',
          '2': '#f50',
          '3': 'orange',
          '4': '#87d068',
          '5': '#999'
        }
        return (
          <Tag color={colors[status || '1']}>{statusText[status] || ''}</Tag>
        )
      }
    },
    {
      title: '',
      key: 'action',
      render: record => {
        return Number(record.status) === 2 ? (
          <Button type="danger" onClick={() => tipUser(record.id)}>
            提醒支付
          </Button>
        ) : Number(record.status) === 5 ? (
          <Button type="primary" onClick={() => showReson(record.cancelRemark)}>
            取消原因
          </Button>
        ) : null
      }
    }
  ]

  const getList = async function() {
    const res = await $fetch(
      'bi/jOrder/list',
      storeId
        ? {
            ...pageInfo,
            ...searchInfo,
            storeId
          }
        : {
            ...pageInfo,
            ...searchInfo
          }
    )
    const { records = [], total: resTotal } = res
    setTotal(resTotal)
    setList(records)
  }

  const changePage = (current, size) => {
    setPageInfo({
      ...pageInfo,
      current,
      size
    })
  }

  useEffect(() => {
    getList()
  }, [pageInfo, searchInfo])

  const getInfo = async function() {
    const res = await $fetch(
      'bi/jOrder/orderYingYee',
      storeId
        ? {
            ...searchInfo,
            storeId
          }
        : {
            ...searchInfo
          }
    )
    setDetail(res)
  }
  useEffect(() => {
    getInfo()
  }, [searchInfo])

  // const handleOk = async () => {
  //   setVisible(false)
  //   await $fetch('bi/jEvaluate/delete', { ...current })
  //   message.success('删除成功', 2).then(() => {
  //     getList()
  //   })
  // }

  // const handleCancel = () => {
  //   setVisible(false)
  // }

  const submit = values => {
    setPageInfo({
      ...pageInfo,
      current: 1
    })
    const arr = values.rangeDate

    setSearchInfo({
      startTime: arr[0],
      endTime: arr[1],
      optSource: values.optSource,
      status: values.status
    })
    // getList(values)
  }
  // const updateValue = (changeItem, values = {}) => {
  //   // setSearchInfo(values)
  // }
  const changeTab = e => {
    history.push({
      pathname: `/page/${e.target.value}`,
      search: $utils.setQuery({ storeId: storeId }, true)
    })
  }

  return (
    <Content style={{ padding: '40px', backgroundColor: '#fff' }}>
      {storeId ? (
        <div
          style={{
            marginBottom: '20px',
            textAlign: 'center'
          }}
        >
          <h1 style={{ marginBottom: '20px',fontSize: '28px'}}>{storeName}</h1>
          <Radio.Group
            defaultValue="order"
            onChange={changeTab}
            buttonStyle="solid"
          >
            <Radio.Button value="order">营业额</Radio.Button>
            <Radio.Button value="technician">技师列表</Radio.Button>
          </Radio.Group>
        </div>
      ) : (
        ''
      )}
      <CommForm
        list={formList}
        submit={submit}
      ></CommForm>
      <Row style={{ marginBottom: '20px', marginTop: '20px' }}>
        <Col span={4}>
        </Col>
      </Row>
      <Row>
        <Col span={4}>
          订单数：{detail.totalOrderNum}笔
        </Col>
        <Col span={4}>
          营业额：{Number(detail.totalSalar).toFixed(2)}元
        </Col>
      </Row>
      <Row style={{ marginBottom: '20px', marginTop: '20px' }}>
        <Col span={4}>
        </Col>
      </Row>
      <CommTable
        dataSource={list}
        columns={columns}
        pagination={{
          total,
          current: pageInfo.current,
          pageSize: pageInfo.size,
          onChange: changePage,
          showSizeChanger: true,
          onShowSizeChange: changePage
        }}
      ></CommTable>

      <Modal
        title="取消原因"
        visible={visible}
        onOk={() => setVisible(false)}
        onCancel={() => setVisible(false)}
      >
        <p>{reson}</p>
      </Modal>
    </Content>
  )
}
