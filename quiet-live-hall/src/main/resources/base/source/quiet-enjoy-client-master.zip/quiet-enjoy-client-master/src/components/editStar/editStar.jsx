import Taro from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import starImg from '@/assets/big_star.png'
import starImgGray from '@/assets/big_star_gray.png'
import './editStar.less'

export default function EditStar(props) {
  const { num, handleClick } = props
  let list = []
  for (let i = 0; i < 5; i++) {
    list.push(i < num)
  }
  return (
    <View>
      {list.map((item, index) => (
        <Image
          className="editStarItem"
          key={`edit${index}`}
          src={item ? starImg : starImgGray}
          onClick={()=> typeof handleClick === 'function' ? handleClick(index) : ''}
        ></Image>
      ))}
    </View>
  )
}
