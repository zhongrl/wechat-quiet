<template>
  <view class="login-page">
    <view class="login">
      <view class="logo">
        <image :src="logo" class="loginImg" />
      </view>
      <comm-form buttonText="登陆" :formList="formList" @submit="submit"></comm-form>
    </view>
  </view>
</template>

<script>
import commForm from '@/components/commForm'
import logo from '@/assets/logo.png'
import http from '@/utils/http'
// import wxAuth from '@/utils/wx'
// 15112639969/111111
export default {
  components: {
    'comm-form': commForm
  },
  data() {
    return {
      logo,
      formList: [
        {
          type: 'input',
          label: '用户名',
          name: 'account',
          rules: ['required'],
          attrs: {
            maxLength: 11
          }
        },
        {
          type: 'password',
          label: '密码',
          name: 'password',
          rules: ['required']
        }
      ],
      code: '',
      openId: ''
    }
  },
  onLoad(option) {
    // if(wxAuth.isWechat() && !uni.getStorageSync('token')){
    //   wxAuth.wxAuthorize('wx0a45b143e43cfb37',async code => {
    //     const reso = await http('js/code', {
    //       code: code,
    //     })
    //     this.openId = reso
    //     this.submit({}, (msg, errCode)=>{
    //       console.log(msg, errCode, code)
    //       // if(errCode == "00000001"){

    //       // }
    //     })
    //   })
    // }else if (uni.getStorageSync('token')) {
    //   uni.switchTab({
    //     url: '/pages/order/order'
    //   })
    // }
    const { code = '' } = option
    const token = uni.getStorageSync('token')
    if (token) {
      this.toOrder()
    } else {
      this.code = code
    }
  },
  methods: {
    async submit(values) {
      const { code } = this
      const res = await http('js/jslogin', { ...values, code })
      if (res) {
        uni.setStorageSync('token', res)
        this.toOrder()
      }
    },
    toOrder() {
      uni.switchTab({
        url: '/pages/order/order'
      })
    }
  }
}
</script>

<style>
page {
  background: #fff;
}
.login {
  width: 500rpx;
  margin: auto;
  padding-top: 123rpx;
}
.logo {
  text-align: center;
  margin-bottom: 119rpx;
}
.loginImg {
  width: 256rpx;
  height: 91rpx;
}
</style>
