import Taro from '@tarojs/taro'
import { View, Button } from '@tarojs/components'

export default function Auth(props) {
  const { callback } = props

  const getPhoneNumber = async info => {
    const { detail = {} } = info
    const { encryptedData } = detail
    if (typeof encryptedData !== 'undefined') {
      callback({
        ...detail
      })
    }
  }

  return (
    <View class="headView">
      <View>申请获取以下权限</View>
      <View class="titleText">申请获取以下权限</View>
      <View class="contentText">获得你的公开信息(昵称,头像,手机等)</View>
      <Button
        class="authBtn"
        type="primary"
        openType="getPhoneNumber"
        onGetPhoneNumber={getPhoneNumber}
      >
        授权登录
      </Button>
    </View>
  )
}
