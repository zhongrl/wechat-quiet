
export default {
  //判断是否在微信中
  isWechat: function(){
    var ua = window.navigator.userAgent.toLowerCase()
    if(ua.match(/micromessenger/i) == 'micromessenger'){
      return true
    }else{
      return false
    }
  },
  _getUrlParams(url) {
    // 获取url中"?"符后的字串 
    url = url || window.location.search;
    var theRequest = {};
    if (url.indexOf("?") != -1) {
      var str = url.substring(url.indexOf("?")+1);
      // var str = url.substr(1);
      var strs = str.split("&");
      for(var i = 0; i < strs.length; i ++) {
        theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
      }
    }
    return theRequest;
  },
  // 微信公众号授权
  wxAuthorize: function(appid, callback ) {
    let link = window.location.href
    let params = this._getUrlParams(link)  // 地址解析

    // 已经授权登录过的就不用再授权了
    // if (store.state.token) return

    // 如果拿到code，调用授权接口，没有拿到就跳转微信授权链接获取
    if (params.code) {
      callback(params.code) // 调用后台接口，授权
    } else {
      let uri = encodeURIComponent(link);
      let state = 'state'
      let authURL = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appid}&redirect_uri=${uri}&response_type=code&scope=snsapi_userinfo&state=${state}#wechat_redirect`
      window.location.href = authURL
    }
  }

}