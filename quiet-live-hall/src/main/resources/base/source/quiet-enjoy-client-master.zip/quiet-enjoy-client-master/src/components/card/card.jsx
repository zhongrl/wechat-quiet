import Taro, { useEffect, useState } from '@tarojs/taro'
import { View, Text, Button, Image } from '@tarojs/components'
import EmptyList from '@/components/emptyList/emptyList'
import http from '../../utils/http'
// import local from '@/assets/local_hight.png'
import './card.less'

export default function Card() {
  const [list, setList] = useState([])

  useEffect(() => {
    async function getList() {
      const res = await http('custom/findUserJCouponDetail')
      setList(res)
    }
    getList()
  }, [])

  const handleClick = (delFlag, id) => {
    if (delFlag == 4) {
      Taro.navigateTo({
        url: `/pages/share/share?id=${id}`
      })
    }
  }
  return list.length > 0 ? (
    <View className="cardList">
      {/* 1,已使用，2，待使用，3，已过期，空的为待领取，4 为待分享 */}
      {list.map(item => (
        <View
          onClick={() => handleClick(item.delFlag, item.id)}
          className={`cardItem${item.delFlag}`}
          key={item.id}
        >
          <Text className="cardMoney">{item.price}元</Text>
          <View className="cardDesc">
            <View>
              <Text>{item.remake}</Text>
            </View>
            {item.delFlag != 4 ? (
              <View class="cardEndTime">
                <Text>有效期：{item.endTime.split(' ')[0]}</Text>
              </View>
            ) : null}
          </View>
        </View>
      ))}
    </View>
    ) : <EmptyList></EmptyList>

  
}
