<template>
  <view class="paySuccPage">
    <view class="paySuccMain">
      <view class="paySuccCenter">
        <view class="paySuccCenterImg">
          <image class="paySuccImg" :src="succ" />
        </view>
        <view class="paySuccCenterText">
          <text>支付成功</text>
        </view>
      </view>
      <view class="payDiscount">
        <text>本单节省{{price}}元</text>
      </view>
      <view class="paySuccBottom">
        <view class="paySuccBottomtext">
          <text>告诉技师，你对ta的服务印象吧！</text>
        </view>
        <view class="paySuccBottomButton">
          <view @click="toComment" class="paySuccButton">去评价</view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import http from '@/utils/http'
import succ from '@/assets/succ.png'
// const wx = require('weixin-js-sdk')

export default {
  data() {
    return {
      succ,
      price: 0,
      token: ''
    }
  },
  onLoad(option) {
    const { price = '', token } = option
    this.price = price
    this.token = token
    // this.getConf()
  },
  methods: {
    // async getConf() {
    //   const { token } = this
    //   const conf = await http(
    //     'custom/shareConfig',
    //     {
    //       url: location.href
    //     },
    //     { token }
    //   )
    //   wx.config({
    //     debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
    //     appId: conf.appId, // 必填，公众号的唯一标识
    //     timestamp: conf.timestamp, // 必填，生成签名的时间戳
    //     nonceStr: conf.nonceStr, // 必填，生成签名的随机串
    //     signature: conf.signature, // 必填，签名
    //     jsApiList: ['checkJsApi', 'invokeMiniProgramAP']
    //   })
    // },
    async toComment() {
      const { token } = this
      uni.navigateTo({
        url: `/pages/comment/comment?token=${token}`
      })
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
}
.paySuccPage {
  background: #f9f9f9;
  min-height: 100vh;
}

.paySuccMain {
  padding: 189rpx;
  text-align: center;
}

.paySuccCenter {
  width: 300rpx;
  height: 300rpx;
  background: #ffffff;
  border-radius: 20rpx;
  font-size: 36rpx;
  color: #b09e85;
  line-height: 50rpx;
  margin: auto;
}

.paySuccCenterImg {
  padding: 34rpx 0 30rpx 0;
}

.paySuccImg {
  width: 146rpx;
  height: 146rpx;
}

.payDiscount {
  font-size: 28rpx;
  color: #9b9b9b;
  line-height: 40rpx;
  margin-top: 20rpx;
}

.paySuccBottomText {
  font-size: 24rpx;
  color: #9b9b9b;
  line-height: 33rpx;
  margin-bottom: 40rpx;
}
.paySuccBottom {
  margin-top: 200rpx;
}
.paySuccButton {
  background: #b09e85;
  border-radius: 40rpx;
  font-size: 32rpx;
  color: #ffffff;
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
}
.paySuccBottomButton {
  margin-top: 40rpx;
}
</style>
