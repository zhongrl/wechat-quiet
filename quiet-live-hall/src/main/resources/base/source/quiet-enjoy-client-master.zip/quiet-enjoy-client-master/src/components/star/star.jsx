import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import starImg from '@/assets/star.png'
import starImgGray from '@/assets/star_gray.png'
import './star.less'

export default function TabTitle(props) {
  const { num } = props
  let list = []
  for (let i = 0; i < 5; i++) {
    list.push(i < num)
  }
  return (
    <View>
      {list.map((item, index) => (
        <Image
          className="starItem"
          key={index}
          src={item ? starImg : starImgGray}
        ></Image>
      ))}
    </View>
  )
}
