import Taro, { Component } from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import TechnicianDesc from '@/components/technicianDesc/technicianDesc'
import Comment from '@/components/comment/comment'
import Price from '@/components/price/price'
import EmptyList from '@/components/emptyList/emptyList'
import http from '../../utils/http'
import './technicianDetail.less'

export default class TechnicianDetail extends Component {
  config = {
    navigationBarTitleText: '技师详情',
    enablePullDownRefresh: true //全局
  }

  constructor(props) {
    super(props)
    const { id, storeId } = this.$router.params
    this.state = {
      id,
      storeId,
      info: {},
      numberInfo: {},
      list: [],

      current: 1,
      size: 20,
      total: 0,
      isInit: false,
      isFetch: false
    }
  }

  componentDidMount() {
    this.getDeatail()
    this.getNumber()
    this.getList()
  }

  async getDeatail() {
    const { id } = this.state
    const info = await http('custom/findJsSelectById', {
      id
    })
    this.setState({
      info
    })
  }

  async getNumber() {
    const { id } = this.state
    const info = await http('custom/jEvaluate/statiats', {
      userId: id
    })
    this.setState({
      numberInfo: info
    })
  }

  getList(page = 1) {
    this.setState(
      {
        isFetch: true
      },
      async () => {
        const { id, size, list } = this.state
        const { records, total } = await http('custom/jEvaluate/list', {
          size,
          current: page,
          userId: id
        })
        Taro.stopPullDownRefresh()
        this.setState({
          current: page,
          total,
          isInit: true,
          isFetch: false,
          list: page > 1 ? [...list, ...records] : records
        })
      }
    )
  }

  onPullDownRefresh() {
    this.getList()
  }

  onReachBottom() {
    const { current, total, list, isFetch } = this.state
    if (list.length < total && !isFetch) {
      this.getList(current + 1)
    }
  }

  handleClick() {
    const { id, storeId } = this.state
    Taro.navigateTo({
      url: `/pages/takeNumber/takeNumber?id=${id}&storeId=${storeId}`
    })
  }

  render() {
    return (
      <View className="technicianDetailPage">
        <TechnicianDesc
          info={this.state.info}
          numberInfo={this.state.numberInfo}
          handleClick={()=> this.getList()}
        ></TechnicianDesc>
        <Comment list={this.state.list}></Comment>
        {this.state.isInit && this.state.list.length === 0 ? (
          <EmptyList></EmptyList>
        ) : null}
        <Price
          price={this.state.info.price}
          handleClick={() => this.handleClick()}
          time={this.state.info.serviceTime}
          text="取号"
        ></Price>
      </View>
    )
  }

  // enablePullDownRefresh
}
