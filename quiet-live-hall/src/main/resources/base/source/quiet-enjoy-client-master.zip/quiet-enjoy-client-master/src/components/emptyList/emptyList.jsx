import Taro from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import './emptyList.less'

export default function EmptyList(props) {
  return (
  <View class="empty-list">
    <Text>暂无数据</Text>
  </View>
  )
}



