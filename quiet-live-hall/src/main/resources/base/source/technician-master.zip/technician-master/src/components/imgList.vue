<template>
  <view>
    <view class="img-list">
      <view v-for="(url, index) in list" :key="index" class="img-list-item">
        <image class="img-item" v-if="url" :src="url" @click="showImg(list, index)" />
      </view>
    </view>
    <!-- <uni-popup ref="popup" type="center" :custom="true">
      <view class="big-img"><image class="img-big-item" :src="bigUrl" /></view>
    </uni-popup>-->

    <view class="big-img" v-if="isShowBig">
      <view class="big-img-block" @click="isShowBig = false"></view>
      <view class="big-img-content">
        <view class="big-img-item" v-for="(url, index) in imgList" :key="index">
          <view>
            <image v-if="index === current" class="img-item-inner" :src="url" />
          </view>
        </view>
        <view class="big-img-dot">
          <text
            :class="index === current ? 'big-img-dot-current' : 'big-img-dot-inner'"
            v-for="(url, index) in imgList"
            :key="index"
            @click="current = index"
          >{{index + 1}}</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { uniPopup, uniSwiperDot } from '@dcloudio/uni-ui'
export default {
  components: {
    'uni-popup': uniPopup,
    'uni-swiper-dot': uniSwiperDot
  },
  props: {
    list: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      bigUrl: '',
      isShowBig: false,
      imgList: [],
      current: 0,
      mode: 'indexes'
    }
  },
  methods: {
    showImg(list, index) {
      this.imgList = list.filter(url => url)
      this.current = index
      this.isShowBig = true
    },
    openPopup(bigUrl) {
      this.bigUrl = bigUrl
      this.isShowBig = true
      // this.$refs.popup.open()
    }
  }
}
</script>

<style>
.img-list {
  margin-top: 20rpx;
  display: flex;
}
.img-list-item {
  width: 80rpx;
  height: 80rpx;
  margin-right: 10rpx;
}
.img-item {
  width: 80rpx;
  height: 80rpx;
}

.big-img-block {
  position: fixed;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  background: rgba(0, 0, 0, 0.1);
  z-index: 998;
}
.big-img-content {
  position: fixed;
  width: 100%;
  left: 0;
  top: 200rpx;
  z-index: 999;
}
.big-img-item {
  text-align: center;
}
.img-item-inner {
  max-width: 100%;
  max-height: 900rpx;
}

.swiper-item {
  background: green;
}

.big-img-dot {
  display: flex;
  justify-content: center;
  margin-top: 50rpx;
  padding-left: 20rpx;
}
.big-img-dot-inner {
  width: 50rpx;
  height: 50rpx;
  border-radius: 50%;
  text-align: center;
  line-height: 50rpx;
  background: #fff;
  margin-right: 20rpx;
  color: #4a4a4a;
}
.big-img-dot-current {
  width: 50rpx;
  height: 50rpx;
  border-radius: 50%;
  text-align: center;
  line-height: 50rpx;
  background: #fff;
  margin-right: 20rpx;
  color: #b09e85;
}
</style>
