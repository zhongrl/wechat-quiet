<template>
  <view class="sharePage">
    <view class="shareMain">
      <view class="shareLogoItem">
        <image class="shareLogo" :src="shareLogo" />
      </view>
      <view class="shareEmailItem">
        <image :src="email" class="shareEmail" />
      </view>
      <view class="shareText">
        <view class="shareTextRow">
          <text>为你的好友送上</text>
          <text class="shareTextBold">20元</text>
          <text>抵扣券</text>
        </view>
        <view class="shareTextTip">
          <text>好友首次消费后</text>
        </view>
        <view class="shareTextRow">
          <text>你将获得</text>
          <text class="shareTextBold">20元</text>
          <text>奖励</text>
        </view>
      </view>
      <view class="shareButtonRow">
        <button class="shareButton" @click="showModal = true">分享给好友</button>
      </view>
      <view class="shareBottomText">
        <text>邀请越多 奖励越多</text>
      </view>
      <view class="shareCompText">
        <text>静享生活体验馆</text>
      </view>
    </view>
    <modal v-if="showModal" title="请点击右上角去分享" buttonText="知道了" @handleClick="showModal = false"></modal>
  </view>
</template>

<script>
import http from '@/utils/http'
import shareLogo from '@/assets/share_logo.png'
import shareIcon from '@/assets/share_icon.jpeg'
import email from '@/assets/email.png'
import modal from '@/components/modal'

const wx = require('weixin-js-sdk')

export default {
  components: {
    modal
  },
  data() {
    return {
      showModal: false,
      shareLogo,
      shareIcon,
      email,
      price: 0,
      couponId: '',
      openId: '',
      unionid: '',
      token: ''
    }
  },
  onLoad(option) {
    const { token } = option
    this.token = token
    this.getDetail()
  },
  methods: {
    async getDetail() {
      const { token } = this
      const { couponId, openId, unionid } = await http(
        'custom/selectUserDetail',
        {},
        { token }
      )
      this.couponId = couponId
      this.openId = openId
      this.unionid = unionid
      this.setShare()
    },

    async setShare() {
      const { token, couponId, openId, shareIcon, unionid } = this
      const authUrl = `${location.origin}/technician/pages/auth/auth`
      const redirect_uri = `${location.origin}/technician/pages/getShare/getShare?isWxWp=wxmp&giveOpenid=${openId}&couponId=${couponId}&unionid=${unionid}`
      const link = `${authUrl}?redirect_uri=${encodeURIComponent(redirect_uri)}`
      const conf = await http(
        'custom/shareConfig',
        {
          url: location.href
        },
        { token }
      )
      wx.config({
        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        appId: conf.appId, // 必填，公众号的唯一标识
        timestamp: conf.timestamp, // 必填，生成签名的时间戳
        nonceStr: conf.nonceStr, // 必填，生成签名的随机串
        signature: conf.signature, // 必填，签名
        jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData']
      })

      wx.ready(function() {
        //需在用户可能点击分享按钮前就先调用
        wx.updateAppMessageShareData(
          {
            title: '为你的好友送上20元抵扣券', // 分享标题
            desc: '静享一刻现代推拿生活馆', // 分享描述
            link,
            imgUrl: shareIcon // 分享图标
          },
          function(res) {
            // success
          }
        )
        wx.updateTimelineShareData(
          {
            title: '为你的好友送上20元抵扣券', // 分享标题
            link,
            imgUrl: shareIcon // 分享图标
          },
          function(res) {
            // success
          }
        )
      })
    }
  }
}
</script>

<style>
page {
  background: #f9f9f9;
  background-image: linear-gradient(-132deg, #d8cdbb 0%, #b09e85 100%);
}
.sharePage {
  padding: 70rpx 0 20rpx 0;
}

.shareMain {
  background: #ffffff;
  border-radius: 10rpx;
  margin: 0 45rpx 0 45rpx;
  padding: 181rpx 0 89rpx 0;
  text-align: center;
  font-size: 20rpx;
  color: #9b9b9b;
}

.shareEmailItem {
  padding: 121rpx 0 10rpx 0;
}

.shareTextBold {
  font-size: 42rpx;
  color: #000000;
}

.shareText {
  font-size: 36rpx;
  color: #000000;
}

.shareTextTip {
  font-size: 24rpx;
}

.shareTextRow {
  margin-bottom: 10rpx;
}

.shareLogo {
  width: 332rpx;
  height: 116rpx;
}

.shareEmail {
  width: 74rpx;
  height: 58rpx;
}

.shareButtonRow {
  margin: 120rpx 0 20rpx 0;
}

.shareButton {
  background: #b09e85;
  border-radius: 40rpx;
  font-size: 32rpx;
  color: #ffffff;
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
}

.shareBottomText {
  font-size: 24rpx;
  color: #9b9b9b;
  line-height: 33rpx;
}

.shareCompText {
  font-size: 20rpx;
  color: #9b9b9b;
  letter-spacing: 20rpx;
  margin-top: 60rpx;
}
</style>
