<template>
  <view class="commForm">
    <form>
      <view class="formItem" :key="item.name" v-for="item in formList">

        <view class="textareaItem" v-if="item.type === 'textarea'">
          <textarea
            class="textarea"
            :placeholder="`请输入${item.label}`"
            :name="item.name"
            v-model="values[item.name]"
            @blur="blurInput(item.name)"
          />
        </view>
        <view class="inputItem" v-else>
          <input
            class="input"
            :placeholder="`请输入${item.label}`"
            :name="item.name"
            v-model="values[item.name]"
            @blur="blurInput(item.name)"
            :type="item.type || 'text'"
          />
        </view>
        <view
          v-if="getErrorMsg(item.name)"
          class="formError"
        >{{getErrorMsg(item.name)}}</view>
      </view>

      <view class="buttonItem">
        <view v-if="isDisabled" class="disabledButton">{{buttonText}}</view>
        <view v-else class="submitButton" @click="formSubmit">{{buttonText}}</view>
      </view>
    </form>
  </view>
</template>

<script>
export default {
  props: {
    formList: {
      type: Array,
      default: () => []
    },
    initValues: {
      type: Object,
      default: () => ({})
    },
    buttonText: {
      type: String,
      default: '提交'
    }
  },
  data() {
    return {
      values: {},
      rules: {}
    }
  },
  created() {
    this.init()
    console.log('0000')
  },
  methods: {
    getErrorMsg(name) {
      const { rules } = this
      const ruleArr = rules[name] || []
      const errorRule = ruleArr.find(({ status }) => status === 2)
      return errorRule ? errorRule.message : ''
    },
    init() {
      const { formList, initValues } = this
      let tempValues = {}
      let tempRules = {}
      formList.forEach(item => {
        const { name, label, value = '', rules: itemRules } = item
        tempValues[name] = value
        tempRules[name] = this.madeRules(itemRules, label)
      })
      this.values = { ...tempValues, ...initValues }
      this.rules = tempRules
    },

    madeRules(itemRules = [], label) {
      const defaultRequiredMsg = `${label}必填`
      return itemRules.map(ruleItem => {
        if (typeof ruleItem === 'string') {
          if (ruleItem === 'required') {
            return {
              required: true,
              message: defaultRequiredMsg,
              status: 0 // 0初始，1校验成功，2校验失败
            }
          }
        }

        if (typeof ruleItem === 'object') {
          const defaultMessage = ruleItem.required
            ? defaultRequiredMsg
            : `${label}输入`
          return {
            message: defaultMessage,
            ...ruleItem,
            status: 0
          }
        }
        return {}
      })
    },

    blurInput(name) {
      const { values, rules } = this
      const value = values[name] || ''
      const ruleArr = rules[name] || []
      this.rules[name] = this.getCheckedRule(ruleArr, value)
    },

    getCheckedRule(ruleArr = [], value) {
      return ruleArr.map(rule => {
        return { ...rule, status: this.getStatus(rule, value) }
      })
    },

    getStatus(rule, value) {
      return rule.required && value === '' ? 2 : 1
    },

    inputItem(value, name) {
      this.values[name] = value
    },
    formSubmit() {
      const { disabled, values } = this
      if (!disabled) {
        this.$emit('submit', values)
      }
    }
  },
  computed: {
    isDisabled() {
      const { rules, values } = this
      let isDisabled = false
      Object.keys(rules).forEach(key => {
        const ruleArr = rules[key] || []
        ruleArr.forEach(ruleItem => {
          if (this.getStatus(ruleItem, values[key]) === 2) {
            isDisabled = true
          }
        })
      })
      return isDisabled
    }
  }
}
</script>

<style>
.commForm {
}

.formItem {
  margin-bottom: 30rpx;
}

.inputItem {
  background: #f9f9f9;
  border-radius: 10rpx;
  height: 80rpx;
  display: flex;
  align-items: center;
}

.input {
  /*height: 45rpx;*/
  font-size: 30rpx;
  color: #4a4a4a;
  flex: 1;
  padding: 0 20rpx;
  background: none;
  border: none;
  outline: none;
  line-height: normal;
}
.textareaItem {
  background: #f9f9f9;
  border-radius: 10rpx;
  display: flex;
  align-items: center;
}

.textarea {
  font-size: 32rpx;
  color: #4a4a4a;
  flex: 1;
  padding: 0 20rpx;
  background: none;
  border: none;
  outline: none;
}

.formError {
  color: red;
}
.buttonItem {
  margin-top: 193rpx;
  display: flex;
  justify-content: center;
}

.submitButton {
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
  border-radius: 40rpx;
  border: none;
  font-size: 32rpx;
  text-align: center;
  background: #b09e85;
  color: #ffffff;
}

.disabledButton {
  width: 400rpx;
  height: 80rpx;
  line-height: 80rpx;
  border-radius: 40rpx;
  border: none;
  font-size: 32rpx;
  text-align: center;
  background: rgba(176, 158, 133, 0.3);
  color: #ffffff;
}
</style>
