# 静享客户端

## 开发及打包说明

1. 安装依赖

   `cnpm install`

2. 启动项目（以小程序方式）

   `npm run dev:weapp`

3. 项目打包

   `npm run build:weapp`

## 注意事项

- npm 安装 tarojs 过程很慢，或安装多次出错，可使用淘宝 NPM 镜像（cnpm）进行安装

- 本项目统一使用cnpm安装（包括 @tarojs/cli）

- 开发环境屏蔽接口地址校验（修改project.config.json）中的setting.urlCheck项为false

- 项目中安装包需要使用cnpm，否则报错

- 不能在 class 里面使用 Hooks，这样一来不能使用 Class 的话,就没办法使用 config.

## 淘宝 NPM 镜像（cnpm）安装方法

1. 安装 cnpm

   `npm install -g cnpm --registry=https://registry.npm.taobao.org`

2. 常用命令
   支持 npm 除了 publish 之外的所有命令

3. 如 cnpm 安装 taro 如下

   `cnpm install -g @tarojs/cli`